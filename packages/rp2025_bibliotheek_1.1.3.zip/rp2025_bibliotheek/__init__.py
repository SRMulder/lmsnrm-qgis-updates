def classFactory(iface):
    from pathlib import Path
    from .updates import apply_pending
    try:
        apply_pending(Path(__file__).resolve().parent)
    except Exception as error:
        from qgis.core import QgsMessageLog
        QgsMessageLog.logMessage(str(error), "LMSNRM updates")
    from .plugin import LibraryPlugin
    return LibraryPlugin(iface)
