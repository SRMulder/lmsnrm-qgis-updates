"""Local conversion, independent of the RWS toolbar and current QGIS project."""
import json
import re
import sqlite3
import zipfile
from pathlib import Path

from qgis.core import QgsCoordinateTransformContext, QgsFeature, QgsField, QgsFields, QgsVectorFileWriter, QgsVectorLayer
from qgis.PyQt.QtCore import QVariant

REGIONS = ('LMS', 'Noord', 'Oost', 'West', 'Zuid')
PERIODS = ('RD', 'OC', 'AV')


def inventory(path):
    networks = {}
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        for name in names:
            match = re.fullmatch(r'CUBE_(RD|OC|AV)_(\d{4})_(LMS|NOORD|OOST|WEST|ZUID)\.shp', Path(name).name, re.I)
            if match:
                period, year, region = match.groups()
                region = next(r for r in REGIONS if r.upper() == region.upper())
                stem = name[:-4]
                missing = [suffix for suffix in ('.dbf', '.shx', '.prj') if stem + suffix not in names]
                if missing:
                    raise ValueError(f'{name}: ontbreekt {", ".join(missing)}')
                key = (region, int(year), period.upper())
                if key in networks:
                    raise ValueError(f'Dubbel netwerk: {key}')
                networks[key] = name
    if not networks:
        raise ValueError('Geen CUBE-invoernetwerken gevonden in deze ZIP.')
    return networks


def write_layer(layer, path, name, cancelled, progress):
    fields = QgsFields(layer.fields())
    lookup = {f.name().casefold(): f.name() for f in fields}
    a_source = next((lookup[k] for k in ('knoopa', 'a') if k in lookup), None)
    b_source = next((lookup[k] for k in ('knoopb', 'b') if k in lookup), None)
    if a_source is None or b_source is None:
        raise ValueError(f'{name}: knoopvelden ontbreken.')
    added = []
    for alias, source_name in [('A', a_source), ('B', b_source)]:
        if alias.casefold() not in lookup:
            fields.append(QgsField(alias, QVariant.LongLong))
            added.append(source_name)
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = 'GPKG'
    options.layerName = name
    options.fileEncoding = 'UTF-8'
    options.layerOptions = ['SPATIAL_INDEX=YES']
    if path.exists():
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
    writer = QgsVectorFileWriter.create(str(path), fields, layer.wkbType(), layer.crs(), QgsCoordinateTransformContext(), options)
    if writer.hasError() != QgsVectorFileWriter.NoError:
        raise RuntimeError(writer.errorMessage())
    count, total = 0, layer.featureCount()
    try:
        for feature in layer.getFeatures():
            if count % 1000 == 0:
                if cancelled():
                    raise InterruptedError('Verwerking geannuleerd.')
                progress(count / max(total, 1))
            for source_name in (a_source, b_source):
                raw = feature[source_name]
                try:
                    node = int(raw)
                except (TypeError, ValueError):
                    raise ValueError(f'{name}: ongeldig knoopnummer in {source_name}.')
                if node <= 0 or node != raw:
                    raise ValueError(f'{name}: ongeldig knoopnummer in {source_name}.')
            target = QgsFeature(fields)
            target.setGeometry(feature.geometry())
            target.setAttributes(feature.attributes() + [int(feature[n]) for n in added])
            if not writer.addFeature(target):
                raise RuntimeError(writer.lastError())
            count += 1
        if not writer.flushBuffer():
            raise RuntimeError(writer.lastError())
    finally:
        del writer
    check = QgsVectorLayer(f'{path}|layername={name}', name, 'ogr')
    if not check.isValid() or check.featureCount() != total:
        raise RuntimeError(f'Controle uitvoer mislukt: {name}')
    return count


def convert(archive_path, stage, regions, years, cancelled=lambda: False, progress=lambda value: None):
    networks = inventory(archive_path)
    pairs = [(r, y) for r in regions for y in years]
    if not pairs:
        raise ValueError('Selecteer minstens één regio en jaar.')
    for region, year in pairs:
        for period in PERIODS:
            if (region, year, period) not in networks:
                raise ValueError(f'Netwerk ontbreekt: {region} {year} {period}')
    report = {'source_zip': Path(archive_path).name, 'library': 'RP2025 v2', 'project_crs': 'EPSG:3857', 'data_crs': 'EPSG:28992', 'networks': []}
    for pair_index, (region, year) in enumerate(pairs):
        folder = stage / region
        folder.mkdir(parents=True, exist_ok=True)
        output = folder / f'RP25v2_{region}.gpkg'
        for period_index, period in enumerate(PERIODS):
            if cancelled():
                raise InterruptedError('Verwerking geannuleerd.')
            base = (pair_index * 3 + period_index) / (len(pairs) * 3)
            span = 1 / (len(pairs) * 3)
            member = networks[(region, year, period)]
            source = QgsVectorLayer(f'/vsizip/{Path(archive_path).resolve()}/{member}', period, 'ogr')
            if not source.isValid() or source.crs().authid() != 'EPSG:28992':
                raise ValueError(f'Netwerk ongeldig of onverwachte CRS: {member}')
            layer_name = f'netwerk_{year}_{period}'
            count = write_layer(source, output, layer_name, cancelled, lambda f: progress(100 * (base + span * f)))
            with sqlite3.connect(output) as connection:
                connection.execute(f'CREATE INDEX "idx_{layer_name}_ab" ON "{layer_name}" ("A", "B")')
                duplicates = connection.execute(f'SELECT COALESCE(SUM(n-1),0) FROM (SELECT COUNT(*) n FROM "{layer_name}" GROUP BY "A","B" HAVING COUNT(*)>1)').fetchone()[0]
            report['networks'].append({'region': region, 'year': year, 'period': period, 'layer': layer_name, 'links': count, 'duplicate_ab_pairs': duplicates})
            progress(100 * (base + span))
    (stage / 'verwerkingsrapport.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return report
