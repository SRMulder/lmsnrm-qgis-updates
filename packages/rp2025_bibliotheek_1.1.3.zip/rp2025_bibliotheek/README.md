# RP2025 v2 Netwerkbibliotheek 1.1.0

Zelfstandige QGIS-verwerkingsplugin. Kies de RP25v2-netwerklevering-ZIP, de bovenliggende uitvoermap, regio’s en jaren. De plugin maakt een nieuwe map **RP2025 v2**. Netwerkshapes worden rechtstreeks uit de ZIP gelezen.

Per regio één GeoPackage en één QGIS-project, bijvoorbeeld `Noord/RP25v2_Noord.gpkg` en `Noord/Noord.qgz`.

Het GeoPackage bevat afzonderlijke lagen `netwerk_2022_RD`, `netwerk_2022_OC`, `netwerk_2022_AV`, enzovoort voor de gekozen jaren. GeoPackage kent geen geneste groepen: het QGIS-project groepeert als **zichtjaar → dagdelen**. Er wordt geen extra vierde jaarbasislaag gekopieerd; ieder dagdeel is het oorspronkelijke netwerk.

De projecten tonen eenvoudige grijze lijnen, zonder thematische klassen of internetachtergrond. Alleen het vroegste gekozen jaar met dagdeel RD staat standaard aan. Alle bronattributen en geometrieën blijven behouden.

## .NET koppelen

KnoopA/KnoopB blijven behouden. De plugin voegt echte numerieke velden **A/B** toe met exact dezelfde knoopnummers. Geen hernummering, samenvoeging of omkering. Iedere geometrische laag krijgt een ruimtelijke index en een niet-unieke attribuutindex op `(A,B)`. Eventuele dubbele knoopparen worden gerapporteerd en blijven behouden.

De RWS-toolbar herkent deze A/B-velden voor .NET-koppeling. Kies het .NET-bestand van dezelfde regio, hetzelfde jaar en dagdeel. Andere exports kunnen afwijkende knoopnummers hebben. De nieuwe GM-zips bevatten geen .NET-bestanden; in de RP25v2-netwerklevering staan wel corresponderende CUBE .NET-bestanden voor controle.

## Gebruik

Installeer `rp2025_bibliotheek_1.1.0.zip` via Plugins > Plugins beheren en installeren > Installeren vanuit ZIP. Open Plugins > RP2025 v2 Netwerkbibliotheek > RP2025 v2 bibliotheek maken… Kies bron en uitvoermap, selecteer regio’s/jaren en klik Bibliotheek maken. Collega’s kopiëren hun volledige regiomap en openen het regioproject.

Data blijft RD New / EPSG:28992; projecten gebruiken EPSG:3857 zoals eerder afgesproken voor aansluiting op OSM. QGIS projecteert tijdens weergave. Er is geen achtergrondkaart toegevoegd.

Bestaande uitvoer wordt niet overschreven. Kies een nieuwe bovenliggende uitvoermap wanneer RP2025 v2 al bestaat. Bij fouten of annulering wordt tijdelijke uitvoer verwijderd. Een volledige conversie vraagt extra schijfruimte voor de regio-GeoPackages. `verwerkingsrapport.json` geeft aantallen per regio, jaar en dagdeel.
