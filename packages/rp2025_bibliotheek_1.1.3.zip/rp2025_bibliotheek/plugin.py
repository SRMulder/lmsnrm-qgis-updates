import shutil
import uuid
from pathlib import Path

from qgis.core import QgsApplication, QgsTask
from qgis.PyQt.QtWidgets import (QAction, QCheckBox, QDialog, QFileDialog, QGridLayout,
    QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton)
from .processing import REGIONS, inventory, convert
from .projects import create_projects


class ConversionTask(QgsTask):
    def __init__(self, dialog, archive, parent, regions, years):
        super().__init__('RP2025 v2 bibliotheek maken', QgsTask.CanCancel)
        self.dialog, self.archive = dialog, archive
        self.target = parent / 'RP2025 v2'
        self.stage = parent / f'.RP2025-v2-{uuid.uuid4().hex}'
        self.regions, self.years = regions, years
        self.error = None

    def run(self):
        try:
            self.stage.mkdir()
            self.report = convert(self.archive, self.stage, self.regions, self.years, self.isCanceled, self.setProgress)
            return not self.isCanceled()
        except Exception as error:
            self.error = str(error)
            return False

    def finished(self, success):
        try:
            if not success or self.isCanceled():
                raise RuntimeError(self.error or 'Verwerking geannuleerd.')
            self.dialog.status.setText('QGIS-projecten maken…')
            create_projects(self.stage, self.regions, self.years)
            if self.target.exists():
                raise RuntimeError('Doelmap bestaat inmiddels. Er is niets overschreven.')
            self.stage.rename(self.target)
            self.dialog.status.setText(f'Klaar: {self.target}')
            QMessageBox.information(self.dialog, 'Bibliotheek gemaakt', f'{self.target}\n\nEén GeoPackage per regio, met zichtjaren en dagdelen.\nDe netwerken bevatten A/B-knoopvelden voor .NET-koppeling.')
        except Exception as error:
            self.dialog.status.setText(str(error))
            QMessageBox.warning(self.dialog, 'Verwerking gestopt', str(error))
        finally:
            if self.stage.exists():
                shutil.rmtree(self.stage)
            self.dialog.task = None
            self.dialog.start.setEnabled(True)
            self.dialog.cancel_button.setEnabled(False)


class LibraryDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle('RP2025 v2 Netwerkbibliotheek')
        self.resize(650, 350)
        self.task = None
        layout = QGridLayout(self)
        self.archive, self.destination = QLineEdit(), QLineEdit()
        layout.addWidget(QLabel('Levering-ZIP'), 0, 0)
        layout.addWidget(self.archive, 0, 1)
        choose_zip = QPushButton('Kiezen…')
        choose_zip.clicked.connect(self.choose_archive)
        layout.addWidget(choose_zip, 0, 2)
        layout.addWidget(QLabel('Bovenliggende uitvoermap'), 1, 0)
        layout.addWidget(self.destination, 1, 1)
        choose_folder = QPushButton('Kiezen…')
        choose_folder.clicked.connect(self.choose_destination)
        layout.addWidget(choose_folder, 1, 2)
        layout.addWidget(QLabel('Hierin wordt de map “RP2025 v2” gemaakt. Bestaande uitvoer wordt niet overschreven.'), 2, 0, 1, 3)
        self.regions, self.years = {}, {}
        for row, (choices, container) in enumerate([(REGIONS, self.regions), ((2022, 2031, 2040, 2050), self.years)], 3):
            from qgis.PyQt.QtWidgets import QHBoxLayout
            strip = QHBoxLayout()
            for value in choices:
                box = QCheckBox(str(value))
                box.setChecked(True)
                container[value] = box
                strip.addWidget(box)
            layout.addLayout(strip, row, 0, 1, 3)
        layout.addWidget(QLabel('Project-CRS: EPSG:3857. Data: RD New / EPSG:28992.\nEén GeoPackage per regio. Zichtjaren met RD/OC/AV.\nEenvoudige lijnen; originele attributen plus A/B-knoopvelden.'), 5, 0, 1, 3)
        self.status, self.bar = QLabel('Kies bron en uitvoermap.'), QProgressBar()
        layout.addWidget(self.status, 6, 0, 1, 3)
        layout.addWidget(self.bar, 7, 0, 1, 3)
        self.start, self.cancel_button = QPushButton('Bibliotheek maken'), QPushButton('Annuleren')
        self.start.clicked.connect(self.process)
        self.cancel_button.clicked.connect(self.cancel)
        self.cancel_button.setEnabled(False)
        layout.addWidget(self.start, 8, 1)
        layout.addWidget(self.cancel_button, 8, 2)

    def choose_archive(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Kies netwerklevering', '', 'ZIP (*.zip)')
        if path:
            self.archive.setText(path)

    def choose_destination(self):
        path = QFileDialog.getExistingDirectory(self, 'Kies bovenliggende uitvoermap')
        if path:
            self.destination.setText(path)

    def process(self):
        try:
            archive = Path(self.archive.text())
            parent = Path(self.destination.text())
            if not archive.is_file() or not self.destination.text() or not parent.is_dir():
                raise ValueError('Kies een bestaande ZIP en uitvoermap.')
            if (parent / 'RP2025 v2').exists():
                raise ValueError('De map RP2025 v2 bestaat al. Kies een andere bovenliggende map.')
            regions = [r for r, box in self.regions.items() if box.isChecked()]
            years = [y for y, box in self.years.items() if box.isChecked()]
            if not regions or not years:
                raise ValueError('Selecteer minstens één regio en jaar.')
            networks = inventory(archive)
            for r in regions:
                for y in years:
                    if any((r, y, p) not in networks for p in ('RD', 'OC', 'AV')):
                        raise ValueError(f'Onvolledige levering: {r} {y}.')
            self.task = ConversionTask(self, archive, parent, regions, years)
            self.task.progressChanged.connect(lambda value: self.bar.setValue(int(value)))
            self.start.setEnabled(False)
            self.cancel_button.setEnabled(True)
            self.status.setText('Netwerken verwerken…')
            QgsApplication.taskManager().addTask(self.task)
        except Exception as error:
            QMessageBox.warning(self, 'Controle invoer', str(error))

    def cancel(self):
        if self.task:
            self.task.cancel()
            self.status.setText('Annuleren…')

    def reject(self):
        if self.task:
            self.cancel()
        else:
            super().reject()

    def closeEvent(self, event):
        if self.task:
            self.cancel()
            event.ignore()
        else:
            event.accept()


class LibraryPlugin:
    def __init__(self, iface):
        self.iface, self.dialog = iface, None

    def initGui(self):
        from .updates import UpdateManager
        self.updates = UpdateManager(self.iface, Path(__file__).resolve().parent)
        self.update_action = QAction('Updates instellen / controleren…', self.iface.mainWindow())
        self.update_action.triggered.connect(self.updates.configure)
        self.iface.addPluginToMenu('&RP2025 v2 Netwerkbibliotheek', self.update_action)
        self.action = QAction('RP2025 v2 bibliotheek maken…', self.iface.mainWindow())
        self.action.triggered.connect(self.open)
        self.iface.addPluginToMenu('&RP2025 v2 Netwerkbibliotheek', self.action)

    def open(self):
        if self.dialog is None:
            self.dialog = LibraryDialog(self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()

    def unload(self):
        self.updates.unload()
        self.iface.removePluginMenu('&RP2025 v2 Netwerkbibliotheek', self.update_action)
        if self.dialog and self.dialog.task:
            self.dialog.task.cancel()
        self.iface.removePluginMenu('&RP2025 v2 Netwerkbibliotheek', self.action)
