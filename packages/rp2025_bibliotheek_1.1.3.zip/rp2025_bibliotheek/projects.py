"""Create a plain regional project with year groups and daypart layers."""
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsLineSymbol, QgsProject, QgsReferencedRectangle, QgsSingleSymbolRenderer, QgsVectorLayer)


def create_projects(stage, regions, years):
    for region in regions:
        project = QgsProject()
        project.setTitle(f'RP2025 v2 — {region}')
        project.setCrs(QgsCoordinateReferenceSystem('EPSG:3857'))
        project.setFileName(str(stage / region / f'{region}.qgz'))
        project.writeEntry('Paths', '/Absolute', False)
        root = project.layerTreeRoot()
        first_year = min(years)
        extent = None
        path = stage / region / f'RP25v2_{region}.gpkg'
        for year in sorted(years):
            year_group = root.addGroup(str(year))
            year_group.setExpanded(year == first_year)
            for period in ('RD', 'OC', 'AV'):
                name = f'netwerk_{year}_{period}'
                layer = QgsVectorLayer(f'{path}|layername={name}', f'{year} — {period}', 'ogr')
                if not layer.isValid():
                    raise RuntimeError(f'Uitvoerlaag ontbreekt: {path.name}/{name}')
                layer.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple({'line_color': '#606060', 'line_width': '0.3'})))
                layer.setDisplayExpression("concat('A: ', \"A\", ' → B: ', \"B\")")
                project.addMapLayer(layer, False)
                year_group.addLayer(layer).setItemVisibilityChecked(year == first_year and period == 'RD')
                if year == first_year and period == 'RD':
                    extent = QgsCoordinateTransform(layer.crs(), project.crs(), project).transformBoundingBox(layer.extent())
        if extent is not None:
            extent.scale(1.1)
            project.viewSettings().setDefaultViewExtent(QgsReferencedRectangle(extent, project.crs()))
        if not project.write():
            raise RuntimeError(f'Project opslaan mislukt: {region}')
        project.clear()
