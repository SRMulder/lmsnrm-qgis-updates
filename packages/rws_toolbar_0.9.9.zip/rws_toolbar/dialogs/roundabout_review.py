"""Small review dialog for accepting or rejecting roundabout candidates."""

from qgis.PyQt.QtWidgets import (
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)


class RoundaboutReviewDialog(QDialog):
    """Popup with one-click controls for reviewing roundabout candidates."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.choice = None
        self.setWindowTitle("Rotonde kandidaat controleren")
        self.resize(560, 210)

        layout = QVBoxLayout(self)
        self.title_label = QLabel("Geen kandidaat geselecteerd", self)
        self.title_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.title_label)

        grid = QGridLayout()
        self.score_label = QLabel("-", self)
        self.diameter_label = QLabel("-", self)
        self.attachments_label = QLabel("-", self)
        self.advice_label = QLabel("-", self)
        self.shape_label = QLabel("-", self)
        grid.addWidget(QLabel("Score", self), 0, 0)
        grid.addWidget(self.score_label, 0, 1)
        grid.addWidget(QLabel("Diameter", self), 1, 0)
        grid.addWidget(self.diameter_label, 1, 1)
        grid.addWidget(QLabel("Aansluitingen", self), 2, 0)
        grid.addWidget(self.attachments_label, 2, 1)
        grid.addWidget(QLabel("Advies", self), 3, 0)
        grid.addWidget(self.advice_label, 3, 1)
        grid.addWidget(QLabel("Vorm", self), 4, 0)
        grid.addWidget(self.shape_label, 4, 1)
        layout.addLayout(grid)

        view_buttons = QHBoxLayout()
        self.context_button = QPushButton("Toon omgeving", self)
        self.zoom_out_button = QPushButton("Uitzoomen", self)
        self.zoom_in_button = QPushButton("Inzoomen", self)
        view_buttons.addWidget(self.context_button)
        view_buttons.addWidget(self.zoom_out_button)
        view_buttons.addWidget(self.zoom_in_button)
        layout.addLayout(view_buttons)

        buttons = QHBoxLayout()
        self.yes_button = QPushButton("Ja, rotonde", self)
        self.no_button = QPushButton("Nee", self)
        self.unsure_button = QPushButton("Twijfel", self)
        self.skip_button = QPushButton("Overslaan", self)
        self.stop_button = QPushButton("Stoppen", self)
        buttons.addWidget(self.yes_button)
        buttons.addWidget(self.no_button)
        buttons.addWidget(self.unsure_button)
        buttons.addWidget(self.skip_button)
        buttons.addWidget(self.stop_button)
        layout.addLayout(buttons)

        self.yes_button.clicked.connect(lambda: self._finish("ja"))
        self.no_button.clicked.connect(lambda: self._finish("nee"))
        self.unsure_button.clicked.connect(lambda: self._finish("twijfel"))
        self.skip_button.clicked.connect(lambda: self._finish("overslaan"))
        self.stop_button.clicked.connect(lambda: self._finish("stop"))

    def set_candidate(self, feature, current_index, total):
        roundabout_id = _value(feature, "rotonde_id", "?")
        self.title_label.setText(f"{current_index} van {total}: {roundabout_id}")
        self.score_label.setText(str(_value(feature, "score", "-")))
        diameter = _value(feature, "diam_m", None)
        if diameter is None:
            self.diameter_label.setText("-")
        else:
            self.diameter_label.setText(f"{float(diameter):.1f} m")
        self.attachments_label.setText(str(_value(feature, "takknopen", _value(feature, "takken", "-"))))
        self.advice_label.setText(str(_value(feature, "advies", "-")))
        shape = _value(feature, "vorm", None)
        max_turn = _value(feature, "hoek_max", None)
        sharp_turns = _value(feature, "scherp", None)
        parts = []
        if shape is not None:
            parts.append(f"score {float(shape):.2f}")
        if max_turn is not None:
            parts.append(f"hoek {float(max_turn):.0f} gr")
        if sharp_turns is not None:
            parts.append(f"scherp {int(sharp_turns)}")
        self.shape_label.setText(", ".join(parts) if parts else "-")

    def _finish(self, choice):
        self.choice = choice
        self.accept()


def _value(feature, field_name, default=None):
    if feature.fields().indexFromName(field_name) < 0:
        return default
    value = feature[field_name]
    if value is None:
        return default
    return value
