"""Project selection dialog for project-code based layers."""

from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from ..utils.qgis_compat import (
    DIALOG_CANCEL,
    DIALOG_OK,
    HEADER_RESIZE_TO_CONTENTS,
    HEADER_STRETCH,
    QT_USER_ROLE,
    VIEW_EXTENDED_SELECTION,
    VIEW_NO_EDIT_TRIGGERS,
    VIEW_SELECT_ROWS,
)


class ProjectSelectionDialog(QDialog):
    """Small project picker for project codes present in the active network layer."""

    def __init__(self, projects, catalog_meta, parent=None):
        super().__init__(parent)
        self.projects = projects
        self.setWindowTitle("Projecten kiezen")
        self.resize(1120, 620)

        layout = QVBoxLayout(self)
        meta_text = (
            f"{len(projects)} projectcode(s) in actieve shape"
            f" - lijst {catalog_meta.get('round', 'RP2026')}"
            f" uit {catalog_meta.get('source_file', 'projectenlijst')}"
        )
        layout.addWidget(QLabel(meta_text))

        self.search = QLineEdit(self)
        self.search.setPlaceholderText("Zoek op projectnummer, naam, omschrijving, wegnummer of provincie")
        self.search.textChanged.connect(self._filter_rows)
        layout.addWidget(self.search)

        self.table = QTableWidget(len(projects), 7, self)
        self.table.setHorizontalHeaderLabels(
            ["Projectnr", "Type", "Projectnaam", "Omschrijving", "Weg", "Provincie", "Jaar NRM"]
        )
        self.table.setSelectionBehavior(VIEW_SELECT_ROWS)
        self.table.setSelectionMode(VIEW_EXTENDED_SELECTION)
        self.table.setEditTriggers(VIEW_NO_EDIT_TRIGGERS)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(1, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(2, HEADER_STRETCH)
        self.table.horizontalHeader().setSectionResizeMode(3, HEADER_STRETCH)
        self.table.horizontalHeader().setSectionResizeMode(4, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(5, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(6, HEADER_RESIZE_TO_CONTENTS)
        self._populate_table()
        layout.addWidget(self.table)

        helper_buttons = QHBoxLayout()
        select_visible = QPushButton("Selecteer zichtbare", self)
        select_visible.clicked.connect(self._select_visible_rows)
        clear_selection = QPushButton("Wis selectie", self)
        clear_selection.clicked.connect(self.table.clearSelection)
        helper_buttons.addWidget(select_visible)
        helper_buttons.addWidget(clear_selection)
        helper_buttons.addStretch(1)
        layout.addLayout(helper_buttons)

        buttons = QDialogButtonBox(DIALOG_OK | DIALOG_CANCEL, self)
        buttons.button(DIALOG_OK).setText("Maak lagen")
        buttons.button(DIALOG_CANCEL).setText("Annuleren")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_project_codes(self):
        codes = []
        for index in self.table.selectionModel().selectedRows():
            item = self.table.item(index.row(), 0)
            if item is not None:
                codes.append(item.data(QT_USER_ROLE))
        return sorted(set(codes))

    def _populate_table(self):
        for row, project in enumerate(self.projects):
            values = [
                project["code"],
                project.get("network_type", ""),
                project.get("projectnaam", ""),
                project.get("projectomschrijving", ""),
                project.get("wegnummer", ""),
                project.get("provincie", ""),
                project.get("jaar_nrm", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem("" if value is None else str(value))
                if column == 0:
                    item.setData(QT_USER_ROLE, int(project["code"]))
                self.table.setItem(row, column, item)

    def _filter_rows(self, text):
        terms = [term.casefold() for term in text.split() if term.strip()]
        for row in range(self.table.rowCount()):
            haystack = " ".join(
                self.table.item(row, column).text()
                for column in range(self.table.columnCount())
                if self.table.item(row, column) is not None
            ).casefold()
            self.table.setRowHidden(row, not all(term in haystack for term in terms))

    def _select_visible_rows(self):
        self.table.clearSelection()
        for row in range(self.table.rowCount()):
            if self.table.isRowHidden(row):
                continue
            for column in range(self.table.columnCount()):
                item = self.table.item(row, column)
                if item is not None:
                    item.setSelected(True)
