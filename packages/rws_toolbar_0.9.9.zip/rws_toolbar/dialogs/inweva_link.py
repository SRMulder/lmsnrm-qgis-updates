"""Dialog for joining an INWEVA layer to a loaded network layer."""

from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QVBoxLayout,
)

from ..utils.qgis_compat import DIALOG_CANCEL, DIALOG_OK


class InwevaLinkDialog(QDialog):
    """Picker for joining an INWEVA 2025 layer to an open network layer."""

    PREFERRED_ID_FIELDS = ("WVK_ID", "LINK_ID", "ID")

    def __init__(self, network_layers, inweva_layers, parent=None):
        super().__init__(parent)
        self.network_layers = {layer.id(): layer for layer in network_layers}
        self.inweva_layers = inweva_layers
        self.setWindowTitle("INWEVA 2025 koppelen (bèta)")
        self.resize(620, 220)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.network_layer = QComboBox(self)
        for layer in network_layers:
            self.network_layer.addItem(layer.name(), layer.id())
        self.network_layer.currentIndexChanged.connect(self._update_id_fields)
        form.addRow("Netwerklaag", self.network_layer)

        self.network_id_field = QComboBox(self)
        form.addRow("ID-veld netwerk", self.network_id_field)

        self.inweva_layer = QComboBox(self)
        for inweva_key, definition in inweva_layers.items():
            self.inweva_layer.addItem(definition["label"], inweva_key)
        form.addRow("INWEVA 2025-laag", self.inweva_layer)

        layout.addLayout(form)
        layout.addWidget(
            QLabel(
                "Gebruik bij voorkeur WVK_ID: dit wordt vergeleken met WVK_IDS in INWEVA. "
                "LINK_ID, SEGMENT_ID en knoopnummers zijn andere sleutels. "
                "WVK_IDS mag meerdere IDs bevatten. Rijrichting wordt geometrisch gecontroleerd. "
                "Bij een lange modellink zijn de waarden van één gekoppeld INWEVA-segment afkomstig, "
                "niet van de hele keten. Zie INW_koppeling en INW_dekking_pct. "
                "Alleen netwerklinks met een INWEVA-match worden in de nieuwe laag opgenomen."
            )
        )

        buttons = QDialogButtonBox(DIALOG_OK | DIALOG_CANCEL, self)
        buttons.button(DIALOG_OK).setText("Koppel lagen")
        buttons.button(DIALOG_CANCEL).setText("Annuleren")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._update_id_fields()

    def selected_network_layer_id(self):
        return self.network_layer.currentData()

    def selected_network_id_field(self):
        return self.network_id_field.currentData()

    def selected_inweva_key(self):
        return self.inweva_layer.currentData()

    def _update_id_fields(self):
        self.network_id_field.clear()
        layer = self.network_layers.get(self.network_layer.currentData())
        if layer is None:
            return

        preferred_index = None
        preferred_rank = len(self.PREFERRED_ID_FIELDS)
        field_priority = {
            field_name: index
            for index, field_name in enumerate(self.PREFERRED_ID_FIELDS)
        }
        field_names = layer.fields().names()
        for index, field_name in enumerate(field_names):
            self.network_id_field.addItem(field_name, field_name)
            field_upper = field_name.upper()
            field_rank = field_priority.get(field_upper)
            if field_rank is not None and field_rank < preferred_rank:
                preferred_index = index
                preferred_rank = field_rank

        if self.network_id_field.count() > 0:
            self.network_id_field.setCurrentIndex(preferred_index or 0)
