"""Dialog for creating a difference network from two loaded networks."""

from pathlib import Path
import sqlite3
from qgis.core import QgsProject
from qgis.PyQt.QtCore import Qt

from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from ..utils.qgis_compat import DIALOG_CANCEL, DIALOG_OK, enum_value


class DifferenceNetworkDialog(QDialog):
    """Choose network 1, network 2 and the output GeoPackage."""

    def __init__(self, network_layers, parent=None):
        super().__init__(parent)
        self.network_layers = {layer.id(): layer for layer in network_layers}
        self.setWindowTitle("Verschilnetwerk maken")
        self.resize(1050, 480)

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                "Uitkomst = netwerk 1 - netwerk 2. Links die niet matchen blijven "
                "met hun eigen geometrie in het verschilnetwerk staan."
            )
        )

        self.network_1 = _NetworkPicker(
            "Netwerk 1",
            network_layers,
            "Variant / nieuwe situatie: hiervan wordt netwerk 2 afgetrokken.",
            self,
        )
        self.network_2 = _NetworkPicker(
            "Netwerk 2",
            network_layers,
            "Referentie / oude situatie: dit netwerk wordt afgetrokken van netwerk 1.",
            self,
        )
        layout.addWidget(self.network_1)
        layout.addWidget(self.network_2)
        layout.addWidget(QLabel("Kies voor vergelijking van alle dagdelen bij beide netwerken de laag ‘Alle dagdelen’."))
        layout.addWidget(QLabel("Attributen in de uitvoer: N1_ = netwerk 1, N2_ = netwerk 2, D_ = verschil (1 − 2)."))

        output_box = QGroupBox("Uitvoer", self)
        output_layout = QHBoxLayout(output_box)
        self.output_path = QLineEdit(self)
        self.output_path.setPlaceholderText("verschilnetwerk.gpkg")
        output_button = QPushButton("Bestand...", self)
        output_button.clicked.connect(self._choose_output)
        output_layout.addWidget(self.output_path, 1)
        output_layout.addWidget(output_button)
        layout.addWidget(output_box)

        buttons = QDialogButtonBox(DIALOG_OK | DIALOG_CANCEL, self)
        buttons.button(DIALOG_OK).setText("Maak verschilnetwerk")
        buttons.button(DIALOG_CANCEL).setText("Annuleren")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_network_1(self):
        return self.network_1.selection()

    def selected_network_2(self):
        return self.network_2.selection()

    def selected_output_path(self):
        text = self.output_path.text().strip()
        if not text:
            return None
        path = Path(text)
        if path.suffix.casefold() != ".gpkg":
            path = path.with_suffix(".gpkg")
        return path

    def _choose_output(self):
        path, _selected_filter = QFileDialog.getSaveFileName(
            self,
            "Sla verschilnetwerk op",
            self.output_path.text().strip() or str(Path.home() / "verschilnetwerk.gpkg"),
            "GeoPackage (*.gpkg)",
        )
        if path:
            self.output_path.setText(path)


class _NetworkPicker(QGroupBox):
    """One network input: either an open layer or a layer in a file."""

    def __init__(self, title, network_layers, hint, parent=None):
        super().__init__(title, parent)
        self.file_layers = []

        layout = QFormLayout(self)
        layout.addRow(QLabel(hint))
        self.source_combo = QComboBox(self)
        self.source_combo.addItem("Geopende laag in dit QGIS-project", "layer")
        self.source_combo.addItem("Bestand vanaf schijf", "file")
        layout.addRow("Bron kiezen", self.source_combo)
        self.layer_combo = QComboBox(self)
        self.layer_combo.addItem("Kies een geopende QGIS-laag…", "")
        labels = set()
        for layer in network_layers:
            label = layer_label(layer)
            if label in labels:
                label += f" [{layer.id()[-8:]}]"
            labels.add(label)
            self.layer_combo.addItem(label, layer.id())
            self.layer_combo.setItemData(self.layer_combo.count()-1, layer.source(), enum_value(Qt, "ItemDataRole", "ToolTipRole"))
        self.layer_combo.setMinimumContentsLength(55)
        layout.addRow("Geopende QGIS-laag", self.layer_combo)

        file_row = QHBoxLayout()
        self.file_path = QLineEdit(self)
        self.file_path.setReadOnly(True)
        self.file_path.setPlaceholderText("Geen bestand gekozen")
        file_button = self.file_button = QPushButton("Bestand kiezen...", self)
        file_button.clicked.connect(self._choose_file)
        file_row.addWidget(self.file_path, 1)
        file_row.addWidget(file_button)
        layout.addRow("Bestand", file_row)

        self.file_layer_combo = QComboBox(self)
        self.file_layer_combo.setEnabled(False)
        layout.addRow("Laag in bestand", self.file_layer_combo)
        self.source_combo.currentIndexChanged.connect(self._source_changed)
        if not network_layers:
            self.source_combo.setCurrentIndex(1)
        self._source_changed()

    def _source_changed(self):
        from_file = self.source_combo.currentData() == "file"
        self.layer_combo.setEnabled(not from_file)
        self.file_path.setEnabled(from_file)
        self.file_button.setEnabled(from_file)
        self.file_layer_combo.setEnabled(from_file and bool(self.file_layers))

    def selection(self):
        file_path = self.file_path.text().strip()
        if self.source_combo.currentData() == "file":
            if not file_path:
                return None
            layer_name = self.file_layer_combo.currentData()
            return {
                "kind": "file",
                "path": Path(file_path),
                "layer_name": layer_name,
                "label": _file_label(file_path, layer_name),
            }

        layer_id = self.layer_combo.currentData()
        if layer_id:
            return {
                "kind": "layer",
                "layer_id": layer_id,
                "label": self.layer_combo.currentText(),
            }
        return None

    def _choose_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Kies geladen netwerk",
            str(Path.home()),
            "GIS-bestanden (*.gpkg *.shp);;GeoPackage (*.gpkg);;Shapefile (*.shp);;Alle bestanden (*.*)",
        )
        if not path:
            return

        self.file_path.setText(path)
        self.source_combo.setCurrentIndex(1)
        self.file_layers = _layers_in_file(Path(path))
        self.file_layer_combo.clear()
        for layer_name in self.file_layers:
            self.file_layer_combo.addItem(layer_name or Path(path).stem, layer_name)
        self._source_changed()


def network_label(zip_path, fallback=""):
    stem = Path(str(zip_path)).stem if zip_path else fallback
    if stem.casefold().startswith('gm-zipfile_'):
        stem = stem[len('gm-zipfile_'):]
    return stem.replace('_', ' ')


def layer_label(layer):
    node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
    groups = []
    parent = node.parent() if node is not None else None
    root = QgsProject.instance().layerTreeRoot()
    while parent is not None and parent is not root:
        if parent.name():
            groups.insert(0, parent.name())
        parent = parent.parent()
    identity = network_label(layer.customProperty('rws_toolbar/gmzip_path', ''))
    context = ' / '.join(groups)
    name = layer.name()
    details = identity if identity and identity not in name else ''
    if context:
        details += (' · ' if details else '') + context
    if not details:
        details = Path(layer.source().split('|')[0]).name
    return f'{name} — {details}' if details and details != name else name


def _layers_in_file(path):
    if path.suffix.casefold() == ".gpkg":
        try:
            connection = sqlite3.connect(path)
            rows = connection.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type = 'features'
                ORDER BY CASE WHEN table_name = 'geladen_netwerk' THEN 0 ELSE 1 END,
                         table_name
                """
            ).fetchall()
            connection.close()
            layers = [row[0] for row in rows]
            if layers:
                return layers
        except sqlite3.Error:
            pass
    return [None]


def _file_label(path, layer_name):
    stem = Path(path).stem
    if layer_name:
        return f"{stem}:{layer_name}"
    return stem
