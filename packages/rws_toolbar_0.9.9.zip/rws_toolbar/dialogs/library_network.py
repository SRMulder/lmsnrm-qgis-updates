import re
import sqlite3
from qgis.PyQt.QtWidgets import QDialog, QComboBox, QDialogButtonBox, QFormLayout, QLabel
from ..utils.qgis_compat import DIALOG_OK, DIALOG_CANCEL


class LibraryNetworkDialog(QDialog):
    def __init__(self, path, region, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f'RP 2026 — {region}')
        self.resize(520, 220)
        with sqlite3.connect(path) as connection:
            tables = [row[0] for row in connection.execute("SELECT table_name FROM gpkg_contents WHERE data_type='features'")]
        self.layers = {}
        for table in tables:
            match = re.fullmatch(r'netwerk_(\d{4})_(RD|OC|AV)', table, re.I)
            if match:
                self.layers[(match[1], match[2].upper())] = table
        if not self.layers:
            raise ValueError('Dit GeoPackage bevat geen bibliotheeklagen met zichtjaar en dagdeel.')
        layout = QFormLayout(self)
        layout.addRow(QLabel(f'Bibliotheek: {path.parent.parent.name}\n{path.name}'))
        self.year, self.period = QComboBox(), QComboBox()
        self.year.addItems(sorted({year for year, period in self.layers}))
        self.year.currentTextChanged.connect(self.update_periods)
        layout.addRow('Zichtjaar', self.year)
        layout.addRow('Dagdeel', self.period)
        self.update_periods()
        buttons = QDialogButtonBox(DIALOG_OK | DIALOG_CANCEL)
        buttons.button(DIALOG_OK).setText('Netwerk laden')
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def update_periods(self):
        self.period.clear()
        for key, label in [('RD','RD — restdag'), ('OC','OC — ochtendspits'), ('AV','AV — avondspits')]:
            if (self.year.currentText(), key) in self.layers:
                self.period.addItem(label, key)

    def selection(self):
        return self.layers[(self.year.currentText(), self.period.currentData())]
