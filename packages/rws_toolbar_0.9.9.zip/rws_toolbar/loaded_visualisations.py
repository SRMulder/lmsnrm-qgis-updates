"""Fixed, comparable legends for loaded network results."""


def bands(edges, unit, colors=None):
    colors = colors or ['#c7e9b4', '#7fcdbb', '#41b6c4', '#2c7fb8', '#253494', '#6a3d9a', '#d52b1e']
    result = [{'values': [0], 'label': f'0 {unit}', 'color': '#bdbdbd', 'width': .35}]
    lower = 0
    for i, upper in enumerate([*edges, None]):
        category = {'min': lower, 'label': f'>{lower:g} {unit}' if upper is None else f'>{lower:g} t/m {upper:g} {unit}',
                    'color': colors[min(i, len(colors)-1)], 'width': .55 + .2 * i}
        if upper is not None:
            category['max'] = upper
        result.append(category)
        lower = upper
    return result


def metric(title, suffix, edges, unit, et_suffix=None, et_edges=None, colors=None):
    groups = [{'label': p, 'field_names': [f'{p}_{suffix}', f'{alias}_{suffix}']}
              for p, alias in [('RD', 'RD'), ('OS', 'OC'), ('AS', 'AV')]]
    definition = {'group_name': title, 'field_names': [n for g in groups for n in g['field_names']],
                  'field_groups': groups, 'categories': bands(edges, unit, colors),
                  'empty_message': f'Geen waarden voor {title.lower()}. Maak voor nieuwe resultaatvelden het geladen netwerk opnieuw vanuit GMZIP.'}
    if et_suffix:
        et = {'label': 'Etmaal', 'field_names': [f'ET_{et_suffix}'],
              'categories': bands(et_edges or edges, 'mvt/etmaal' if unit == 'mvt/u' else unit, colors)}
        groups.append(et)
        definition['field_names'].append(f'ET_{et_suffix}')
    return definition


def definitions():
    hot = ['#ffffb2', '#fed976', '#feb24c', '#fd8d3c', '#f03b20', '#bd0026', '#800026']
    out = {
        'vehicle_flow': metric('Intensiteit motorvoertuigen', 'VTG', [250, 500, 1000, 2000, 4000, 8000], 'mvt/u', 'L123', [2500, 5000, 10000, 25000, 50000, 100000]),
        'pae_flow': metric('Intensiteit pae', 'FLOW', [250, 500, 1000, 2000, 4000, 8000], 'pae/u'),
        'driven_speed': metric('Gereden snelheid', 'SPEED', [30, 50, 60, 80, 100, 120], 'km/u', colors=['#bd0026', '#f03b20', '#fd8d3c', '#feb24c', '#a1d76a', '#4d9221', '#276419']),
        'speed_loss': metric('Snelheidsverlies', 'SPEED_LOSS', [5, 10, 20, 40, 60], 'km/u', colors=hot),
        'extra_time': metric('Extra reistijd', 'EXTRA_TIME', [10, 30, 60, 120, 300, 600], 'sec/link', colors=hot),
        'waiting_time': metric('Wachttijd', 'WCST', [10, 30, 60, 120, 300, 600], 'sec', colors=hot),
        'vvu100_absolute': metric('VVU100 absoluut (HWN)', 'VVU100', [1, 5, 10, 25, 50, 100], 'voertuiguren', 'VVU100', [1, 5, 10, 25, 50, 100], hot),
        'offered_load': metric('Aangeboden belasting (FLOW/FLCPW)', 'OFFERED_LOAD', [.5, .7, .9, 1, 1.1, 1.5], 'pae/pae', colors=hot),
        'file_duration': metric('Fileduur', 'FILED', [60, 300, 900, 1800, 3600, 7200], 'sec', colors=hot),
        'freight_share': metric('Vrachtaandeel (exclusief bestel)', 'FREIGHT_SHARE', [2, 5, 10, 20, 30, 50], '%'),
        'queue': metric('Wachtrij', 'NBB', [10, 50, 100, 250, 500, 1000], 'pae', colors=hot),
        'unprocessed_flow': metric('Onafgewikkelde stroom', 'NEK', [10, 50, 100, 250, 500, 1000], 'pae/u', colors=hot),
    }
    for cls in ('L1', 'L2', 'L3'):
        label = {'L1': 'Personenauto en Bestel L1', 'L2': 'Vracht en Bestel L2', 'L3': 'Vracht L3'}[cls]
        out[f'class_{cls.lower()}'] = metric(f'Intensiteit {cls} — {label}', cls, [100, 250, 500, 1000, 2000, 4000], 'mvt/u', cls, [1000, 2500, 5000, 10000, 25000, 50000])
    return out


def delta_bands(edges, unit, increase_good=False):
    negative, positive = ('#d52b1e', '#39870c') if increase_good else ('#007bc7', '#d52b1e')
    thresholds = [-x for x in reversed(edges)] + list(edges)
    result = []
    for i in range(len(thresholds)+1):
        lower = thresholds[i-1] if i else None
        upper = thresholds[i] if i < len(thresholds) else None
        near_zero = lower == -edges[0] and upper == edges[0]
        color = '#bdbdbd' if near_zero else negative if upper is not None and upper < 0 else positive
        strength = max(abs(lower or 0), abs(upper or 0)) / edges[-1]
        category = {'label': f'≤{upper:g} {unit}' if lower is None else f'>{lower:g} {unit}' if upper is None else f'>{lower:g} t/m {upper:g} {unit}',
                    'color': color, 'width': .4 if near_zero else .6 + min(strength, 1)*1.4}
        if lower is not None:
            category['min'] = lower
        if upper is not None:
            category['max'] = upper
        result.append(category)
    return result


def difference_definitions():
    settings = [
        ('driven_speed', 'Gereden snelheid', 'SPEED', [1, 5, 10, 20], 'km/u', True),
        ('waiting_time', 'Wachttijd', 'WCST', [1, 10, 30, 120], 'sec', False),
        ('travel_time', 'Totale reistijd', 'TCST', [1, 10, 30, 120], 'sec/link', False),
        ('speed_loss', 'Snelheidsverlies', 'SPEED_LOSS', [1, 5, 10, 20], 'km/u', False),
        ('extra_time', 'Extra reistijd', 'EXTRA_TIME', [1, 10, 30, 120], 'sec/link', False),
        ('offered_load', 'Aangeboden belasting', 'OFFERED_LOAD', [.01, .05, .1, .2], 'verhouding', False),
        ('file_duration', 'Fileduur', 'FILED', [1, 60, 300, 900], 'sec', False),
        ('freight_share', 'Vrachtaandeel', 'FREIGHT_SHARE', [.1, 1, 5, 10], 'procentpunt', False),
        ('vehicle_flow', 'Intensiteit motorvoertuigen', 'VTG', [10, 100, 500, 2500], 'mvt/u', False),
        ('queue', 'Wachtrij', 'NBB', [1, 10, 50, 250], 'pae', False),
    ]
    settings.extend((f'class_{c.lower()}', f'Intensiteit {c}', c, [10, 100, 500, 2500], 'mvt/u', False) for c in ('L1', 'L2', 'L3'))
    out = {}
    for key, title, suffix, edges, unit, good in settings:
        d = metric(f'Verschil {title.lower()}', suffix, edges, unit)
        d['categories'] = delta_bands(edges, unit, good)
        for group in d['field_groups']:
            group['field_names'] = ['D_' + name for name in group['field_names']]
        d['field_names'] = [name for g in d['field_groups'] for name in g['field_names']]
        if key.startswith('class_') or key == 'vehicle_flow':
            et = suffix if key.startswith('class_') else 'L123'
            d['field_groups'].append({'label': 'Etmaal', 'field_names': [f'D_ET_{et}'], 'categories': delta_bands([100, 1000, 5000, 25000], 'mvt/etmaal')})
            d['field_names'].append(f'D_ET_{et}')
        d['difference_result'] = True
        d['empty_message'] = 'Deze verschilvelden ontbreken. Maak zo nodig de geladen netwerken opnieuw vanuit GMZIP en daarna het verschilnetwerk.'
        out[key + '_delta'] = d
    out['network_changes'] = {'group_name': 'Netwerkveranderingen / koppeling', 'field_names': ['CMPFLAG'],
        'difference_result': True, 'empty_message': 'Selecteer een verschilnetwerk met CMPFLAG.',
        'categories': [
            {'values': [-2], 'label': 'Alleen netwerk 1', 'color': '#39870c', 'width': 1.2},
            {'values': [-1], 'label': 'Alleen netwerk 2', 'color': '#d52b1e', 'width': 1.2},
            {'values': [0], 'label': 'Gematcht — gelijke numerieke attributen', 'color': '#bdbdbd', 'width': .4},
            {'min': 0, 'label': 'Gematcht — gewijzigde numerieke attributen', 'color': '#007bc7', 'width': .9},
        ]}
    return out
