"""Create a loaded-network difference GeoPackage."""

from dataclasses import dataclass
from pathlib import Path

from qgis.core import QgsWkbTypes


KEY_FIELD_CANDIDATES = (
    ("KnoopA", "KnoopB"),
    ("KNOOPA", "KNOOPB"),
    ("A", "B"),
)

PREFERRED_DIFFERENCE_FIELDS = (
    "DISTANCE",
    "NRM_TYPE",
    "WEGSOORT",
    "HWN",
    "GEB_C",
    "OS_TYPE",
    "RD_TYPE",
    "AS_TYPE",
    "OS_CAP",
    "RD_CAP",
    "AS_CAP",
    "OS_LANES",
    "RD_LANES",
    "AS_LANES",
    "OS_TSVA",
    "RD_TSVA",
    "AS_TSVA",
    "OS_SNEL_WET",
    "RD_SNEL_WET",
    "AS_SNEL_WET",
    "OS_FLCPW",
    "RD_FLCPW",
    "AS_FLCPW",
    "ET_L123",
    "ET_L23",
    "ET_L1",
    "OS_FLOW",
    "RD_FLOW",
    "AS_FLOW",
    "OS_SPEED",
    "RD_SPEED",
    "AS_SPEED",
    "OS_TCST",
    "RD_TCST",
    "AS_TCST",
    "OS_WCST",
    "RD_WCST",
    "AS_WCST",
    "OS_FRGTIM",
    "RD_FRGTIM",
    "AS_FRGTIM",
    "OS_NEK",
    "RD_NEK",
    "AS_NEK",
    "OS_VVU100",
    "RD_VVU100",
    "AS_VVU100",
    "ET_VVU100",
)


class DifferenceNetworkError(RuntimeError):
    """Raised when a difference network cannot be created."""


class DifferenceNetworkCancelled(RuntimeError):
    """Raised when the user cancels processing."""


@dataclass
class _FeatureSnapshot:
    feature_id: int
    key: tuple[int, int]
    attributes: tuple
    geometry: object


@dataclass(frozen=True)
class _FieldPair:
    output_name: str
    index_1: int
    index_2: int
    output_aliases: tuple[str, ...] = ()


DIFFERENCE_FIELD_ALIASES = {
    "OS_SNEL_WET": ("OS_SNEL_WET", "OS_SNELW"),
    "RD_SNEL_WET": ("RD_SNEL_WET", "RD_SNELW"),
    "AS_SNEL_WET": ("AS_SNEL_WET", "AS_SNELW"),
}

DIFFERENCE_OUTPUT_ALIASES = {
    "ET_L123": ("ET_VTG",),
    "ET_L23": ("ET_FRGT",),
    "ET_L1": ("ET_Cardr",),
}


def create_difference_geopackage(
    layer_1,
    layer_2,
    output_path,
    name_1,
    name_2,
    layer_name="verschilnetwerk",
    progress_callback=None,
    cancel_callback=None,
):
    """Write network 1 minus network 2 as a GeoPackage layer."""

    from osgeo import ogr, osr

    key_fields_1 = _key_fields(layer_1)
    key_fields_2 = _key_fields(layer_2)
    field_pairs = _difference_field_pairs(layer_1, layer_2)
    if not field_pairs:
        raise DifferenceNetworkError("Geen gemeenschappelijke numerieke velden gevonden om af te trekken.")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    _remove_geopackage_files(output_path)

    total = max(0, layer_1.featureCount()) + max(0, layer_2.featureCount())
    processed = 0

    index_2 = {}
    duplicate_keys_2 = 0
    for feature in layer_2.getFeatures():
        if cancel_callback and cancel_callback():
            raise DifferenceNetworkCancelled()
        snapshot = _snapshot(feature, key_fields_2)
        if snapshot is None:
            continue
        bucket = index_2.setdefault(snapshot.key, [])
        if bucket:
            duplicate_keys_2 += 1
        bucket.append(snapshot)
        processed += 1
        if progress_callback and processed % 1000 == 0:
            progress_callback("Netwerk 2 indexeren...", processed, total)

    driver = ogr.GetDriverByName("GPKG")
    dataset = driver.CreateDataSource(str(output_path))
    if dataset is None:
        raise DifferenceNetworkError(f"GeoPackage kon niet worden gemaakt: {output_path}")

    spatial_ref = _spatial_ref(layer_1, layer_2, osr)
    output_layer = dataset.CreateLayer(
        layer_name,
        spatial_ref,
        _output_geometry_type(layer_1, layer_2, ogr),
        options=["GEOMETRY_NAME=geom", "FID=fid", "SPATIAL_INDEX=YES"],
    )
    if output_layer is None:
        dataset = None
        raise DifferenceNetworkError("De verschilnetwerklaag kon niet worden gemaakt.")

    output_fields = _output_fields(field_pairs)
    for name, field_type in output_fields:
        field_def = ogr.FieldDefn(name, field_type)
        if field_type == ogr.OFTString:
            field_def.SetWidth(254)
        output_layer.CreateField(field_def)

    definition = output_layer.GetLayerDefn()
    stats = {
        "matched": 0,
        "only_1": 0,
        "only_2": 0,
        "identical": 0,
        "duplicate_keys_1": 0,
        "duplicate_keys_2": duplicate_keys_2,
        "field_count": len(field_pairs),
    }
    seen_1 = set()

    output_layer.StartTransaction()
    try:
        for feature_1 in layer_1.getFeatures():
            if cancel_callback and cancel_callback():
                raise DifferenceNetworkCancelled()
            snapshot_1 = _snapshot(feature_1, key_fields_1)
            if snapshot_1 is None:
                continue
            if snapshot_1.key in seen_1:
                stats["duplicate_keys_1"] += 1
            seen_1.add(snapshot_1.key)

            bucket = index_2.get(snapshot_1.key)
            snapshot_2 = bucket.pop(0) if bucket else None
            if bucket == []:
                index_2.pop(snapshot_1.key, None)

            if snapshot_2 is None:
                stats["only_1"] += 1
                _write_output_feature(
                    output_layer,
                    definition,
                    output_fields,
                    field_pairs,
                    snapshot_1,
                    None,
                    -2,
                    "alleen_netwerk_1",
                    name_1,
                    name_2,
                    ogr,
                )
            else:
                difference_count = _difference_count(snapshot_1, snapshot_2, field_pairs)
                stats["matched"] += 1
                if difference_count == 0:
                    stats["identical"] += 1
                _write_output_feature(
                    output_layer,
                    definition,
                    output_fields,
                    field_pairs,
                    snapshot_1,
                    snapshot_2,
                    difference_count,
                    "beide",
                    name_1,
                    name_2,
                    ogr,
                )

            processed += 1
            if progress_callback and processed % 1000 == 0:
                progress_callback("Verschillen schrijven...", processed, total)

        for bucket in list(index_2.values()):
            for snapshot_2 in bucket:
                if cancel_callback and cancel_callback():
                    raise DifferenceNetworkCancelled()
                stats["only_2"] += 1
                _write_output_feature(
                    output_layer,
                    definition,
                    output_fields,
                    field_pairs,
                    None,
                    snapshot_2,
                    -1,
                    "alleen_netwerk_2",
                    name_1,
                    name_2,
                    ogr,
                )
                processed += 1
                if progress_callback and processed % 1000 == 0:
                    progress_callback("Alleen-netwerk-2 links schrijven...", processed, total)

        output_layer.CommitTransaction()
    except Exception:
        output_layer.RollbackTransaction()
        dataset = None
        _remove_geopackage_files(output_path)
        raise

    dataset = None
    if progress_callback:
        progress_callback("Verschilnetwerk afronden...", total, total)

    stats["output_path"] = output_path
    stats["layer_name"] = layer_name
    stats["total"] = stats["matched"] + stats["only_1"] + stats["only_2"]
    return stats


def _difference_field_pairs(layer_1, layer_2):
    fields_1 = {field.name().casefold(): field for field in layer_1.fields()}
    fields_2 = {field.name().casefold(): field for field in layer_2.fields()}
    common_keys = set(fields_1) & set(fields_2)
    key_names = {name.casefold() for pair in KEY_FIELD_CANDIDATES for name in pair}
    common_numeric = {
        key
        for key in common_keys
        if key not in key_names and _is_numeric(fields_1[key]) and _is_numeric(fields_2[key])
    }

    pairs = []
    used_1 = set()
    used_2 = set()
    used_outputs = set()
    for wanted in PREFERRED_DIFFERENCE_FIELDS:
        pair = _preferred_field_pair(layer_1, layer_2, fields_1, fields_2, wanted, key_names)
        if pair is None:
            continue
        key_1 = layer_1.fields()[pair.index_1].name().casefold()
        key_2 = layer_2.fields()[pair.index_2].name().casefold()
        output_key = pair.output_name.casefold()
        if key_1 in used_1 or key_2 in used_2 or output_key in used_outputs:
            continue
        pairs.append(pair)
        used_1.add(key_1)
        used_2.add(key_2)
        used_outputs.add(output_key)

    for key in sorted(common_numeric):
        if key in used_1 or key in used_2 or key in used_outputs:
            continue
        output_name = fields_1[key].name()
        pairs.append(
            _FieldPair(
                output_name,
                layer_1.fields().lookupField(fields_1[key].name()),
                layer_2.fields().lookupField(fields_2[key].name()),
                _output_aliases(output_name),
            )
        )
        used_1.add(key)
        used_2.add(key)
        used_outputs.add(key)

    return pairs


def _preferred_field_pair(layer_1, layer_2, fields_1, fields_2, wanted, key_names):
    aliases = DIFFERENCE_FIELD_ALIASES.get(wanted, (wanted,))
    field_1 = _first_numeric_field(fields_1, aliases, key_names)
    field_2 = _first_numeric_field(fields_2, aliases, key_names)
    if field_1 is None or field_2 is None:
        return None
    return _FieldPair(
        wanted,
        layer_1.fields().lookupField(field_1.name()),
        layer_2.fields().lookupField(field_2.name()),
        _output_aliases(wanted),
    )


def _first_numeric_field(fields, aliases, key_names):
    for alias in aliases:
        field = fields.get(alias.casefold())
        if field is not None and field.name().casefold() not in key_names and _is_numeric(field):
            return field
    return None


def _output_aliases(field_name):
    return DIFFERENCE_OUTPUT_ALIASES.get(field_name.upper(), ())


def _is_numeric(field):
    type_name = field.typeName().casefold()
    return any(
        token in type_name
        for token in ("int", "real", "double", "float", "numeric", "decimal")
    )


def _key_fields(layer):
    fields = {name.casefold(): name for name in layer.fields().names()}
    for a_name, b_name in KEY_FIELD_CANDIDATES:
        a_field = fields.get(a_name.casefold())
        b_field = fields.get(b_name.casefold())
        if a_field is not None and b_field is not None:
            return a_field, b_field
    raise DifferenceNetworkError(
        f"Laag '{layer.name()}' heeft geen KnoopA/KnoopB-, KNOOPA/KNOOPB- of A/B-velden."
    )


def _snapshot(feature, key_fields):
    try:
        key = (int(feature[key_fields[0]]), int(feature[key_fields[1]]))
    except (TypeError, ValueError):
        return None
    return _FeatureSnapshot(
        feature_id=int(feature.id()),
        key=key,
        attributes=tuple(feature.attributes()),
        geometry=feature.geometry(),
    )


def _output_fields(field_pairs):
    fields = [
        ("CMPFLAG", None),
        ("D_COUNT", None),
        ("MATCHSTAT", "string"),
        ("KEY_A", None),
        ("KEY_B", None),
        ("FID_1", None),
        ("FID_2", None),
        ("NETWERK_1", "string"),
        ("NETWERK_2", "string"),
    ]
    existing = {name.casefold() for name, _type in fields}
    for pair in field_pairs:
        for prefix in ("N1_", "N2_", "D_"):
            output_name = _unique_name(f"{prefix}{pair.output_name}", existing)
            fields.append((output_name, "real"))
            existing.add(output_name.casefold())
        for alias in pair.output_aliases:
            output_name = _unique_name(f"D_{alias}", existing)
            fields.append((output_name, "real"))
            existing.add(output_name.casefold())

    from osgeo import ogr

    return [
        (name, ogr.OFTString if field_type == "string" else ogr.OFTReal if field_type == "real" else ogr.OFTInteger64)
        for name, field_type in fields
    ]


def _write_output_feature(
    output_layer,
    definition,
    output_fields,
    field_pairs,
    snapshot_1,
    snapshot_2,
    compare_flag,
    match_status,
    name_1,
    name_2,
    ogr,
):
    feature = ogr.Feature(definition)
    geometry = snapshot_1.geometry if snapshot_1 is not None else snapshot_2.geometry
    if geometry is not None and not geometry.isEmpty():
        ogr_geometry = ogr.CreateGeometryFromWkb(bytes(geometry.asWkb()))
        if ogr_geometry is not None:
            ogr_geometry = _force_multiline(ogr_geometry, ogr)
            feature.SetGeometry(ogr_geometry)

    key = snapshot_1.key if snapshot_1 is not None else snapshot_2.key
    difference_count = compare_flag if compare_flag > 0 else 0
    fid_1 = snapshot_1.feature_id if snapshot_1 is not None else None
    fid_2 = snapshot_2.feature_id if snapshot_2 is not None else None

    values = [
        compare_flag,
        difference_count,
        match_status,
        key[0],
        key[1],
        fid_1,
        fid_2,
        name_1,
        name_2,
    ]

    for pair in field_pairs:
        value_1 = _numeric(snapshot_1.attributes[pair.index_1]) if snapshot_1 is not None else None
        value_2 = _numeric(snapshot_2.attributes[pair.index_2]) if snapshot_2 is not None else None
        difference = (value_1 or 0.0) - (value_2 or 0.0)
        values.extend((value_1, value_2, difference))
        for _alias in pair.output_aliases:
            values.append(difference)

    for field_index, value in enumerate(values):
        if value is None:
            continue
        feature.SetField(field_index, value)

    if output_layer.CreateFeature(feature) != ogr.OGRERR_NONE:
        raise DifferenceNetworkError("Een verschilrecord kon niet worden geschreven.")


def _difference_count(snapshot_1, snapshot_2, field_pairs):
    count = 0
    for pair in field_pairs:
        value_1 = _numeric(snapshot_1.attributes[pair.index_1])
        value_2 = _numeric(snapshot_2.attributes[pair.index_2])
        if abs((value_1 or 0.0) - (value_2 or 0.0)) > 1e-9:
            count += 1
    return count


def _numeric(value):
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _spatial_ref(layer_1, layer_2, osr):
    crs = layer_1.crs() if layer_1.crs().isValid() else layer_2.crs()
    if not crs.isValid():
        return None
    spatial_ref = osr.SpatialReference()
    spatial_ref.ImportFromWkt(crs.toWkt())
    return spatial_ref


def _output_geometry_type(layer_1, layer_2, ogr):
    if (
        QgsWkbTypes.geometryType(layer_1.wkbType()) != QgsWkbTypes.LineGeometry
        or QgsWkbTypes.geometryType(layer_2.wkbType()) != QgsWkbTypes.LineGeometry
    ):
        raise DifferenceNetworkError("Beide netwerken moeten lijnlagen zijn.")
    return ogr.wkbMultiLineString


def _force_multiline(geometry, ogr):
    name = geometry.GetGeometryName().upper()
    if name == "LINESTRING":
        multi = ogr.Geometry(ogr.wkbMultiLineString)
        multi.AddGeometry(geometry)
        return multi
    return geometry


def _unique_name(base_name, existing):
    candidate = base_name
    counter = 2
    while candidate.casefold() in existing:
        candidate = f"{base_name}_{counter}"
        counter += 1
    return candidate


def _remove_geopackage_files(path):
    for candidate in (
        Path(path),
        Path(f"{path}-wal"),
        Path(f"{path}-shm"),
        Path(f"{path}-journal"),
    ):
        try:
            candidate.unlink()
        except FileNotFoundError:
            pass
