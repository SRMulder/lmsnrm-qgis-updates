"""Local RWS Viewer package export from a QGIS vector layer.

This deliberately prepares a reviewable package only. A future uploader uses the
Viewer API and must not contain a Cloudflare account token.
"""
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path


class ViewerPublicationError(RuntimeError):
    pass


def _blocks(records, id_field, target=250):
    amount = max(1, (len(records) + target - 1) // target)
    blocks, index = ([{} for _ in range(amount)], {})
    for record in records:
        value = record[id_field]
        if value in (None, ""):
            raise ViewerPublicationError("Elk object heeft een niet-lege publicatie-ID nodig.")
        object_id = str(value)
        if object_id in index:
            raise ViewerPublicationError("Het gekozen ID-veld is niet uniek: %s." % object_id)
        number = int.from_bytes(hashlib.sha256(object_id.encode("utf-8")).digest()[:8], "big") % amount
        index[object_id] = number
        blocks[number][object_id] = record
    return blocks, index


def prepare_package(layer, destination, object_id_field, tile_fields, *, minzoom=6, maxzoom=14):
    """Export one QGIS layer and all its attributes to a local viewer package."""
    if not layer or not layer.isValid() or not layer.isSpatial():
        raise ViewerPublicationError("Selecteer eerst een geldige ruimtelijke laag.")
    fields = [field.name() for field in layer.fields()]
    generated_id = object_id_field == "rws_fid"
    if object_id_field not in fields and not generated_id:
        raise ViewerPublicationError("Het gekozen ID-veld bestaat niet in de actieve laag.")
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    records = [{name: feature[name] for name in fields} for feature in layer.getFeatures()]
    if generated_id:
        for number, record in enumerate(records):
            record[object_id_field] = str(number)
    blocks, index = _blocks(records, object_id_field)
    attrdir = destination / "attributes"
    attrdir.mkdir(exist_ok=True)
    for number, values in enumerate(blocks):
        (attrdir / (str(number) + ".json")).write_text(json.dumps({"records": values}, ensure_ascii=False, default=str, separators=(",", ":")), encoding="utf-8")
    source = layer.source().split("|")[0]
    layer_name = layer.name()
    source_crs = layer.crs().authid()
    if not source_crs:
        raise ViewerPublicationError("De laag heeft geen CRS. Stel die eerst expliciet in.")
    selected = list(dict.fromkeys([object_id_field] + list(tile_fields)))
    qgis_root = Path(os.environ.get("QGIS_PREFIX_PATH", "/Applications/QGIS-final-4_0_2.app/Contents/MacOS"))
    ogr2ogr = qgis_root / "ogr2ogr"
    if not ogr2ogr.exists():
        raise ViewerPublicationError("QGIS GDAL is niet gevonden. Stel QGIS_PREFIX_PATH in.")
    command = [str(ogr2ogr), "-f", "PMTiles", str(destination / "network.pmtiles"), source, layer_name, "-s_srs", source_crs, "-t_srs", "EPSG:3857", "-select", ",".join(selected), "-dsco", "MINZOOM=" + str(minzoom), "-dsco", "MAXZOOM=" + str(maxzoom)]
    if generated_id:
        command = command[:5] + ["-sql", "SELECT FID AS rws_fid, * FROM \"%s\"" % layer_name] + command[6:]
    result = subprocess.run(command, text=True, capture_output=True)
    if result.returncode:
        raise ViewerPublicationError(result.stderr.strip() or "PMTiles kon niet worden gemaakt.")
    extent = layer.extent()
    manifest = {"format_version": 1, "publication_id": destination.name, "layer": {"id": layer_name}, "object_id_field": object_id_field, "source_crs": source_crs, "bounds": [extent.xMinimum(), extent.yMinimum(), extent.xMaximum(), extent.yMaximum()], "minzoom": minzoom, "maxzoom": maxzoom, "feature_count": len(records), "fields": {name: {"name": name, "type": "unknown"} for name in fields + ([object_id_field] if generated_id else [])}, "tile_fields": selected, "files": {"tiles": "network.pmtiles", "attributes": "attributes/{block}.json"}, "attribute_blocks": {"count": len(blocks), "index": index}, "created_at": datetime.now(timezone.utc).isoformat()}
    (destination / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest
