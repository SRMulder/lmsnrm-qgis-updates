"""Read CUBE turn-penalty files and create QGIS visualisation layers."""

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import re

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsLineSymbol,
    QgsMarkerLineSymbolLayer,
    QgsMarkerSymbol,
    QgsPointXY,
    QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
)


class TurnPenaltyCancelled(Exception):
    """Raised when the user cancels turn-penalty processing."""


@dataclass(frozen=True)
class TurnPenaltyRecord:
    sequence: int
    source_line: int
    node_from: int
    node_via: int
    node_to: int
    penalty: float
    comment: str


@dataclass(frozen=True)
class ParsedTurnPenalty:
    path: Path
    declared_count: int | None
    records: list[TurnPenaltyRecord]
    malformed_lines: list[int]
    year: int | None
    parcel: str | None


@dataclass
class TurnPenaltyResult:
    movement_layer: QgsVectorLayer
    junction_layer: QgsVectorLayer
    unmatched_layer: QgsVectorLayer | None
    parsed: ParsedTurnPenalty
    matched_count: int
    unmatched_count: int
    ambiguous_count: int
    missing_incoming: int
    missing_outgoing: int


@dataclass(frozen=True)
class _LinkCandidate:
    feature_id: int
    geometry: QgsGeometry
    reverse: bool
    score: tuple


def parse_pen_file(path):
    """Parse a CUBE .pen file with A-B-C-penalty records."""
    pen_path = Path(path)
    text = _read_text(pen_path)
    lines = text.splitlines()
    if not lines:
        raise ValueError("Het geselecteerde .pen-bestand is leeg.")

    declared_count = None
    first_data_index = 0
    for index, raw_line in enumerate(lines):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith(";"):
            continue
        try:
            declared_count = int(stripped)
            first_data_index = index + 1
        except ValueError:
            first_data_index = index
        break

    records = []
    malformed_lines = []
    for index, raw_line in enumerate(lines[first_data_index:], first_data_index + 1):
        data, _separator, comment = raw_line.partition(";")
        values = data.split()
        if not values:
            continue
        if len(values) < 4:
            malformed_lines.append(index)
            continue
        try:
            node_from = int(float(values[0]))
            node_via = int(float(values[1]))
            node_to = int(float(values[2]))
            penalty = float(values[3].replace(",", "."))
        except ValueError:
            malformed_lines.append(index)
            continue
        records.append(
            TurnPenaltyRecord(
                sequence=len(records) + 1,
                source_line=index,
                node_from=node_from,
                node_via=node_via,
                node_to=node_to,
                penalty=penalty,
                comment=comment.strip(),
            )
        )

    if not records:
        raise ValueError("Geen geldige afslagverboden gevonden in het .pen-bestand.")

    year, parcel = _metadata_from_filename(pen_path.stem)
    return ParsedTurnPenalty(
        path=pen_path,
        declared_count=declared_count,
        records=records,
        malformed_lines=malformed_lines,
        year=year,
        parcel=parcel,
    )


def build_turn_penalty_layers(source_layer, parsed, progress_callback=None):
    """Match parsed penalties to a line layer and build map/table layers."""
    node_a_field = _find_field(source_layer, ("KNOOPA", "KnoopA", "A"))
    node_b_field = _find_field(source_layer, ("KNOOPB", "KnoopB", "B"))
    if node_a_field is None or node_b_field is None:
        raise ValueError(
            "De actieve laag heeft geen knoopvelden. Verwacht KNOOPA/KNOOPB, KnoopA/KnoopB of A/B."
        )

    required_pairs = set()
    for record in parsed.records:
        required_pairs.add((record.node_from, record.node_via))
        required_pairs.add((record.node_via, record.node_to))

    index = _build_link_index(
        source_layer,
        node_a_field,
        node_b_field,
        required_pairs,
        parsed,
        progress_callback,
    )
    movement_layer, junction_layer, unmatched_layer = _new_result_layers(source_layer)

    movement_features = []
    junction_features = []
    unmatched_features = []
    ambiguous_count = 0
    missing_incoming = 0
    missing_outgoing = 0
    source_count = int(source_layer.featureCount())
    total = source_count + len(parsed.records)

    for record_index, record in enumerate(parsed.records, 1):
        incoming_candidates = index.get((record.node_from, record.node_via), [])
        outgoing_candidates = index.get((record.node_via, record.node_to), [])
        incoming = max(incoming_candidates, key=lambda item: item.score) if incoming_candidates else None
        outgoing = max(outgoing_candidates, key=lambda item: item.score) if outgoing_candidates else None

        if incoming is None or outgoing is None:
            if incoming is None:
                missing_incoming += 1
            if outgoing is None:
                missing_outgoing += 1
            unmatched_features.append(
                _unmatched_feature(
                    unmatched_layer.fields(),
                    record,
                    _missing_reason(incoming is None, outgoing is None),
                )
            )
        else:
            ambiguous = int(len(incoming_candidates) > 1 or len(outgoing_candidates) > 1)
            ambiguous_count += ambiguous
            turn_geometry, junction_point = _turn_geometry(incoming, outgoing)
            if turn_geometry is None or junction_point is None:
                unmatched_features.append(
                    _unmatched_feature(
                        unmatched_layer.fields(),
                        record,
                        "Ongeldige of lege linkgeometrie",
                    )
                )
            else:
                attributes = _result_attributes(record, incoming, outgoing, ambiguous)
                movement = QgsFeature(movement_layer.fields())
                movement.setGeometry(turn_geometry)
                movement.setAttributes(attributes)
                movement_features.append(movement)

                junction = QgsFeature(junction_layer.fields())
                junction.setGeometry(QgsGeometry.fromPointXY(junction_point))
                junction.setAttributes(attributes)
                junction_features.append(junction)

        if progress_callback and (record_index % 100 == 0 or record_index == len(parsed.records)):
            progress_callback(
                "Afslagverboden tekenen...",
                source_count + record_index,
                total,
            )

    movement_layer.dataProvider().addFeatures(movement_features)
    junction_layer.dataProvider().addFeatures(junction_features)
    movement_layer.updateExtents()
    junction_layer.updateExtents()

    if unmatched_features:
        unmatched_layer.dataProvider().addFeatures(unmatched_features)
    else:
        unmatched_layer = None

    matched_count = len(movement_features)
    return TurnPenaltyResult(
        movement_layer=movement_layer,
        junction_layer=junction_layer,
        unmatched_layer=unmatched_layer,
        parsed=parsed,
        matched_count=matched_count,
        unmatched_count=len(parsed.records) - matched_count,
        ambiguous_count=ambiguous_count,
        missing_incoming=missing_incoming,
        missing_outgoing=missing_outgoing,
    )


def _read_text(path):
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Kan tekstcodering van {path.name} niet lezen.")


def _metadata_from_filename(stem):
    match = re.search(
        r"(?:turn|pen)[_-]?(lms|noord|oost|west|zuid)?[_-]?(\d{4})?",
        stem,
        re.IGNORECASE,
    )
    parcel = match.group(1).casefold() if match and match.group(1) else None
    year = int(match.group(2)) if match and match.group(2) else None
    if year is None:
        year_match = re.search(r"(?:19|20)\d{2}", stem)
        year = int(year_match.group(0)) if year_match else None
    return year, parcel


def _find_field(layer, candidates):
    fields = {field.name().casefold(): field.name() for field in layer.fields()}
    for candidate in candidates:
        name = fields.get(candidate.casefold())
        if name is not None:
            return name
    return None


def _build_link_index(
    source_layer,
    node_a_field,
    node_b_field,
    required_pairs,
    parsed,
    progress_callback,
):
    index = defaultdict(list)
    h_sel_field = _find_field(source_layer, ("H_SEL",))
    t_sel_field = _find_field(source_layer, ("T_SEL",))
    year_field = _find_field(source_layer, ("JAAR", "Jaar"))
    pause_field = _find_field(source_layer, ("PAUZE", "Pauze"))
    parcel_field = _parcel_field(source_layer, parsed.parcel)
    source_feature_count = int(source_layer.featureCount())
    total = source_feature_count + len(parsed.records)

    for feature_index, feature in enumerate(source_layer.getFeatures(), 1):
        node_a = _as_int(feature[node_a_field])
        node_b = _as_int(feature[node_b_field])
        if node_a is None or node_b is None:
            continue

        if h_sel_field is None and t_sel_field is None:
            direct_open = True
            return_open = False
        else:
            direct_open = h_sel_field is not None and (_as_int(feature[h_sel_field]) or 0) > 0
            return_open = t_sel_field is not None and (_as_int(feature[t_sel_field]) or 0) > 0

        score = _candidate_score(
            feature,
            parsed,
            year_field,
            pause_field,
            parcel_field,
        )
        if direct_open and (node_a, node_b) in required_pairs:
            index[(node_a, node_b)].append(
                _LinkCandidate(
                    feature_id=feature.id(),
                    geometry=QgsGeometry(feature.geometry()),
                    reverse=False,
                    score=score,
                )
            )
        if return_open and (node_b, node_a) in required_pairs:
            index[(node_b, node_a)].append(
                _LinkCandidate(
                    feature_id=feature.id(),
                    geometry=QgsGeometry(feature.geometry()),
                    reverse=True,
                    score=score,
                )
            )

        if progress_callback and (
            feature_index % 2500 == 0 or feature_index == source_feature_count
        ):
            progress_callback("Netwerklinks koppelen...", feature_index, total)

    return index


def _parcel_field(layer, parcel):
    if parcel is None:
        return None
    candidates = {
        "lms": ("GEB_LMS", "GEB_CODE"),
        "noord": ("GEB_NOORD", "GEB_N", "GEB_CODE"),
        "oost": ("GEB_OOST", "GEB_O", "GEB_CODE"),
        "west": ("GEB_WEST", "GEB_W", "GEB_CODE"),
        "zuid": ("GEB_ZUID", "GEB_Z", "GEB_CODE"),
    }
    return _find_field(layer, candidates.get(parcel, ()))


def _candidate_score(feature, parsed, year_field, pause_field, parcel_field):
    region_score = 1
    if parcel_field is not None:
        region_score = int((_as_int(feature[parcel_field]) or 0) > 0)

    pause_score = 1
    if pause_field is not None:
        pause_score = int((_as_int(feature[pause_field]) or 0) == 0)

    year_bucket = 1
    year_value = 0
    if year_field is not None and parsed.year is not None:
        feature_year = _as_int(feature[year_field])
        if feature_year is not None:
            if feature_year <= parsed.year:
                year_bucket = 2
                year_value = feature_year
            else:
                year_bucket = 0
                year_value = -abs(feature_year - parsed.year)

    return region_score, pause_score, year_bucket, year_value, -int(feature.id())


def _new_result_layers(source_layer):
    crs_text = source_layer.crs().authid() if source_layer.crs().isValid() else ""
    crs_text = crs_text or "EPSG:28992"
    movement_layer = QgsVectorLayer(
        f"LineString?crs={crs_text}",
        "Verboden afslagbewegingen",
        "memory",
    )
    junction_layer = QgsVectorLayer(
        f"Point?crs={crs_text}",
        "Draaipunten",
        "memory",
    )
    unmatched_layer = QgsVectorLayer("None", "Niet gekoppeld", "memory")

    result_fields = _result_fields()
    movement_layer.dataProvider().addAttributes(result_fields)
    junction_layer.dataProvider().addAttributes(result_fields)
    unmatched_layer.dataProvider().addAttributes(
        [
            QgsField("nr", QVariant.Int),
            QgsField("regel", QVariant.Int),
            QgsField("van", QVariant.LongLong),
            QgsField("via", QVariant.LongLong),
            QgsField("naar", QVariant.LongLong),
            QgsField("penalty", QVariant.Double),
            QgsField("opmerking", QVariant.String, len=254),
            QgsField("reden", QVariant.String, len=120),
        ]
    )
    movement_layer.updateFields()
    junction_layer.updateFields()
    unmatched_layer.updateFields()

    movement_layer.setRenderer(_movement_renderer())
    junction_layer.setRenderer(_junction_renderer())
    movement_layer.setDisplayExpression(
        "concat(\"van\", ' -> ', \"via\", ' -> ', \"naar\")"
    )
    junction_layer.setDisplayExpression(
        "concat(\"van\", ' -> ', \"via\", ' -> ', \"naar\")"
    )
    return movement_layer, junction_layer, unmatched_layer


def _result_fields():
    return [
        QgsField("nr", QVariant.Int),
        QgsField("regel", QVariant.Int),
        QgsField("van", QVariant.LongLong),
        QgsField("via", QVariant.LongLong),
        QgsField("naar", QVariant.LongLong),
        QgsField("penalty", QVariant.Double),
        QgsField("opmerking", QVariant.String, len=254),
        QgsField("in_fid", QVariant.LongLong),
        QgsField("uit_fid", QVariant.LongLong),
        QgsField("ambigu", QVariant.Int),
    ]


def _result_attributes(record, incoming, outgoing, ambiguous):
    return [
        record.sequence,
        record.source_line,
        record.node_from,
        record.node_via,
        record.node_to,
        record.penalty,
        record.comment,
        incoming.feature_id,
        outgoing.feature_id,
        ambiguous,
    ]


def _unmatched_feature(fields, record, reason):
    feature = QgsFeature(fields)
    feature.setAttributes(
        [
            record.sequence,
            record.source_line,
            record.node_from,
            record.node_via,
            record.node_to,
            record.penalty,
            record.comment,
            reason,
        ]
    )
    return feature


def _missing_reason(incoming_missing, outgoing_missing):
    if incoming_missing and outgoing_missing:
        return "Inkomende en uitgaande link ontbreken"
    if incoming_missing:
        return "Inkomende link ontbreekt"
    return "Uitgaande link ontbreekt"


def _turn_geometry(incoming, outgoing):
    incoming_points = _sample_directed_link(incoming, incoming_tail=True)
    outgoing_points = _sample_directed_link(outgoing, incoming_tail=False)
    if len(incoming_points) < 2 or len(outgoing_points) < 2:
        return None, None

    incoming_junction = incoming_points[-1]
    outgoing_junction = outgoing_points[0]
    junction = QgsPointXY(
        (incoming_junction.x() + outgoing_junction.x()) / 2.0,
        (incoming_junction.y() + outgoing_junction.y()) / 2.0,
    )
    incoming_points[-1] = junction
    outgoing_points[0] = junction
    points = incoming_points + outgoing_points[1:]
    return QgsGeometry.fromPolylineXY(points), junction


def _sample_directed_link(candidate, incoming_tail):
    geometry = candidate.geometry
    if geometry is None or geometry.isEmpty():
        return []
    length = geometry.length()
    if length <= 0:
        return []

    span = min(length, max(12.0, min(80.0, length * 0.45)))
    samples = max(3, min(10, int(span / 10.0) + 2))
    if incoming_tail:
        directed_distances = [
            length - span + span * index / (samples - 1)
            for index in range(samples)
        ]
    else:
        directed_distances = [
            span * index / (samples - 1)
            for index in range(samples)
        ]

    points = []
    for directed_distance in directed_distances:
        source_distance = (
            length - directed_distance if candidate.reverse else directed_distance
        )
        point_geometry = geometry.interpolate(max(0.0, min(length, source_distance)))
        if point_geometry is None or point_geometry.isEmpty():
            continue
        point = QgsPointXY(point_geometry.asPoint())
        if not points or point != points[-1]:
            points.append(point)
    return points


def _movement_renderer():
    symbol = QgsLineSymbol.createSimple(
        {
            "color": "#ffffff",
            "width": "2.6",
            "capstyle": "round",
            "joinstyle": "round",
        }
    )
    red_line = QgsSimpleLineSymbolLayer.create(
        {
            "color": "#e4032e",
            "width": "1.35",
            "capstyle": "round",
            "joinstyle": "round",
        }
    )
    symbol.appendSymbolLayer(red_line)

    arrow_layer = QgsMarkerLineSymbolLayer.create(
        {
            "placement": "lastvertex",
            "rotate": "1",
        }
    )
    arrow = QgsMarkerSymbol.createSimple(
        {
            "name": "filled_arrowhead",
            "color": "#e4032e",
            "outline_color": "#ffffff",
            "outline_width": "0.45",
            "size": "4.5",
        }
    )
    arrow_layer.setSubSymbol(arrow)
    symbol.appendSymbolLayer(arrow_layer)
    return QgsSingleSymbolRenderer(symbol)


def _junction_renderer():
    marker = QgsMarkerSymbol.createSimple(
        {
            "name": "cross2",
            "color": "#e4032e",
            "outline_color": "#ffffff",
            "outline_width": "0.7",
            "size": "4.2",
        }
    )
    return QgsSingleSymbolRenderer(marker)


def _as_int(value):
    if value is None:
        return None
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        return None
