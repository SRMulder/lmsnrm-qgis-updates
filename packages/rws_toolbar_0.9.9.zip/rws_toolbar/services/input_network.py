"""Extract just the network layer to a local GeoPackage with explicit A/B keys."""
import os
import uuid
import tempfile
import shutil
from pathlib import Path
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransformContext,
    QgsFeature, QgsField, QgsFields, QgsVectorFileWriter, QgsVectorLayer)
from qgis.PyQt.QtCore import QVariant
from .gmzip_loadnet import _normalise_member
from zipfile import ZipFile


def write_input_network(archive_path, output, cancelled=lambda: False, progress=lambda v: None):
    output = Path(output)
    # Windows GMZIPs store backslashes in member names; OGR /vsizip cannot
    # reliably resolve their SHP/DBF/SHX sidecars. Copy only this shape locally.
    with tempfile.TemporaryDirectory(prefix='lmsnrm-input-') as temporary:
        with ZipFile(archive_path) as archive:
            normalised = {_normalise_member(n).casefold():n for n in archive.namelist() if not n.endswith(('/', '\\'))}
            candidates = [original for key, original in normalised.items()
                          if key.endswith('.shp') and 'input' in key.split('/')[:-1]]
            if not candidates:
                raise ValueError('Geen .shp-netwerk gevonden in de map Input van deze GMZIP.')
            if len(candidates) != 1:
                raise ValueError('Meerdere .shp-bestanden in Input gevonden: ' + ', '.join(candidates) + '. Het invoernetwerk is niet eenduidig.')
            member = candidates[0]
            shape = Path(_normalise_member(member))
            for extension in ('.shp', '.shx', '.dbf', '.prj', '.cpg'):
                original = normalised.get(shape.with_suffix(extension).as_posix().casefold())
                if original is None:
                    if extension in ('.shp', '.shx', '.dbf'):
                        raise ValueError(f'Netwerkbestand {extension} ontbreekt in de GMZIP.')
                    continue
                if cancelled():
                    raise InterruptedError()
                with archive.open(original) as incoming, (Path(temporary)/shape.with_suffix(extension).name).open('wb') as outgoing:
                    shutil.copyfileobj(incoming, outgoing)
        return _write_shape(Path(temporary)/shape.name, archive_path, output, cancelled, progress)


def _write_shape(shape_path, archive_path, output, cancelled, progress):
    output = Path(output)
    stage = output.with_name('.' + output.stem + '-' + uuid.uuid4().hex + '.gpkg')
    source = QgsVectorLayer(str(shape_path), 'invoer', 'ogr')
    if not source.isValid():
        raise ValueError('Geen geldig invoernetwerk in deze GMZIP.')
    if not source.crs().isValid():
        extent = source.extent()
        if not (-1000000 < extent.xMinimum() < 1500000 and 0 < extent.yMaximum() < 1500000):
            raise ValueError('Coördinatenstelsel ontbreekt en RD-coördinaten zijn niet herkenbaar.')
        source.setCrs(QgsCoordinateReferenceSystem('EPSG:28992'))
    fields = QgsFields(source.fields())
    names = {f.name().casefold():f.name() for f in fields}
    added = []
    for alias, original in [('A','knoopa'), ('B','knoopb')]:
        if alias.casefold() not in names:
            if original not in names:
                raise ValueError('KnoopA/KnoopB of A/B ontbreken.')
            fields.append(QgsField(alias, QVariant.LongLong))
            added.append(names[original])
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = 'GPKG'
    options.layerName = 'invoernetwerk'
    options.layerOptions = ['SPATIAL_INDEX=YES']
    writer = None
    try:
        writer = QgsVectorFileWriter.create(str(stage), fields, source.wkbType(), source.crs(), QgsCoordinateTransformContext(), options)
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise RuntimeError(writer.errorMessage())
        total = source.featureCount()
        for i, feature in enumerate(source.getFeatures()):
            if i % 1000 == 0:
                if cancelled():
                    raise InterruptedError()
                progress(100*i/max(total,1))
            target = QgsFeature(fields)
            target.setGeometry(feature.geometry())
            target.setAttributes(feature.attributes()+[int(feature[n]) for n in added])
            if not writer.addFeature(target):
                raise RuntimeError(writer.lastError())
        if cancelled():
            raise InterruptedError()
        if not writer.flushBuffer():
            raise RuntimeError(writer.lastError())
        del writer
        writer = None
        os.replace(stage, output)
        progress(100)
    finally:
        if writer is not None:
            del writer
        if stage.exists():
            stage.unlink()
    return Path(archive_path).stem.replace('GM-zipfile_', '').replace('_', ' ') + ' — Invoernetwerk'
