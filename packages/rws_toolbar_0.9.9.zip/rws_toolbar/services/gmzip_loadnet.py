"""Build a loaded LMS/NRM network directly from a Groeimodel ZIP file."""

from __future__ import annotations

import math
import os
import re
import sqlite3
import tempfile
from dataclasses import dataclass
from pathlib import Path
from zipfile import ZipFile


DAYPARTS = ("OS", "RD", "AS")

COMMON_FIELDS = (
    "DISTANCE",
    "NRM_TYPE",
    "WEGSOORT",
    "HWN",
    "GEB_C",
)

GENERAL_SPECS = (
    ("A", 1, 6),
    ("B", 7, 12),
    ("FLOW", 13, 18),
    ("QBB", 20, 25),
    ("CAP", 27, 32),
    ("DRUK", 34, 39),
    ("NBB", 41, 46),
    ("FCST", 48, 53),
    ("WCST", 55, 60),
    ("DCST", 62, 67),
    ("TCST", 69, 74),
    ("DISTANCE", 76, 81),
    ("LANES", 83, 84),
    ("HWN", 85, 87),
    ("HOV", 88, 89),
    ("FLBLK", 90, 94),
    ("WVTL", 96, 96),
    ("WEGSOORT", 97, 97),
    ("WVTYPE", 98, 99),
    ("FLCPW", 100, 105),
    ("TYPE", 107, 108),
    ("TSVA", 109, 112),
    ("TOL", 115, 116),
    ("NBBIN", 117, 126),
    ("NEK", 127, 136),
    ("NBREST", 137, 146),
    ("BUF", 147, 156),
    ("LEID", 157, 159),
    ("LLNK", 160, 162),
    ("WVDIST", 163, 170),
    ("FILED", 171, 178),
    ("VVU", 179, 186),
    ("FRGTFF", 187, 194),
    ("FRGTIM", 195, 202),
    ("SNEL_WET", 203, 206),
    ("NRM_TYPE", 207, 209),
    ("GEB_C", 211, 211),
    ("VWH", 212, 213),
    ("KMHEF", 214, 215),
    ("ALUW", 216, 216),
)

LOADED_SPECS = (
    ("A", 1, 6),
    ("B", 7, 12),
    ("FLOW", 13, 21),
    ("QBB", 22, 30),
    ("NBB", 31, 39),
    ("VTG", 40, 48),
    ("QBBV", 49, 57),
    ("NBBV", 58, 66),
    ("FRGT3", 67, 75),
    ("FRGT2", 76, 84),
    ("BEST2", 85, 93),
    ("BEST1", 94, 102),
    ("COMM", 103, 111),
    ("BUSS", 112, 120),
    ("OTHR", 121, 129),
)

GENERAL_DAY_FIELDS = tuple(
    name
    for name, _start, _end in GENERAL_SPECS
    if name not in {"A", "B", *COMMON_FIELDS}
)
LOADED_DAY_FIELDS = tuple(
    name for name, _start, _end in LOADED_SPECS if name not in {"A", "B"}
)

DAY_OUTPUT_SUFFIXES = (
    "FILED", "VVU", "QBBV", "NBBV", "FRGT2", "FRGT3", "BEST1", "BEST2", "COMM", "BUSS", "OTHR",
    "SPEED_LOSS", "EXTRA_TIME", "OFFERED_LOAD", "FREIGHT_SHARE",
    "FLOW",
    "QBB",
    "CAP",
    "DRUK",
    "NBB",
    "FCST",
    "WCST",
    "DCST",
    "TCST",
    "LANES",
    "HOV",
    "WVTL",
    "FLCPW",
    "TYPE",
    "TSVA",
    "TOL",
    "NEK",
    "FRGTFF",
    "FRGTIM",
    "SNEL_WET",
    "VWH",
    "KMHEF",
    "ALUW",
    "VTG",
    "SPEED",
    "IC",
    "VVU100",
    "L1",
    "L2",
    "L3",
    "L23",
    "L123",
)

ET_FIELDS = (
    "ET_VVU100",
    "ET_L1",
    "ET_L2",
    "ET_L3",
    "ET_L23",
    "ET_L123",
    "ET_L1_STF",
    "ET_L2_STF",
    "ET_L3_STF",
)

OUTPUT_FIELDS = (
    *COMMON_FIELDS,
    *(f"{period}_{suffix}" for period in DAYPARTS for suffix in DAY_OUTPUT_SUFFIXES),
    *ET_FIELDS,
)

RAW_FIELDS = (
    *COMMON_FIELDS,
    *(
        f"{period}_{suffix}"
        for period in DAYPARTS
        for suffix in dict.fromkeys((*GENERAL_DAY_FIELDS, *LOADED_DAY_FIELDS))
    ),
)


class GmZipLoadnetError(RuntimeError):
    """Raised when a Groeimodel ZIP cannot be interpreted."""


class GmZipLoadnetCancelled(RuntimeError):
    """Raised when the user cancels processing."""


@dataclass(frozen=True)
class GmZipContents:
    zip_path: Path
    shape_member: str
    general_members: dict[str, str]
    loaded_members: dict[str, str]

    @property
    def shape_name(self):
        return Path(self.shape_member.replace("\\", "/")).stem

    @property
    def vsi_shape_path(self):
        member = self.shape_member.replace("\\", "/")
        return f"/vsizip/{self.zip_path.resolve()}/{member}"


class LoadnetIndex:
    """Temporary indexed store for the six fixed-width model files."""

    def __init__(self, path, connection, contents, file_counts):
        self.path = Path(path)
        self.connection = connection
        self.contents = contents
        self.file_counts = file_counts
        self._field_sql = ", ".join(_quote(field) for field in RAW_FIELDS)
        self._lookup_sql = (
            f"SELECT {self._field_sql} FROM links WHERE a = ? AND b = ?"
        )

    @property
    def record_count(self):
        row = self.connection.execute("SELECT COUNT(*) FROM links").fetchone()
        return int(row[0])

    def lookup(self, a_value, b_value):
        row = self.connection.execute(
            self._lookup_sql,
            (int(a_value), int(b_value)),
        ).fetchone()
        if row is None:
            return None
        values = dict(zip(RAW_FIELDS, row))
        return calculate_loadnet_values(values)

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


def discover_gmzip(zip_path):
    zip_path = Path(zip_path)
    if not zip_path.exists():
        raise GmZipLoadnetError(f"GMZIP niet gevonden: {zip_path}")

    with ZipFile(zip_path) as archive:
        names = archive.namelist()
        normalised = {
            _normalise_member(name).casefold(): name
            for name in names
            if not name.endswith(("/", "\\"))
        }
        shape_member = _discover_shape_member(archive, normalised)

        general_members = {}
        loaded_members = {}
        for period_number, period in zip(("1", "2", "3"), DAYPARTS):
            general_members[period] = _discover_result_member(
                names,
                "gld2",
                period_number,
                shape_member,
            )
            loaded_members[period] = _discover_result_member(
                names,
                "uld2",
                period_number,
                shape_member,
            )

    return GmZipContents(
        zip_path=zip_path,
        shape_member=shape_member,
        general_members=general_members,
        loaded_members=loaded_members,
    )


def build_loadnet_index(
    zip_path,
    progress_callback=None,
    cancel_callback=None,
):
    contents = discover_gmzip(zip_path)
    descriptor, database_path = tempfile.mkstemp(
        prefix="lms_nrm_gmzip_",
        suffix=".sqlite",
    )
    os.close(descriptor)
    connection = sqlite3.connect(database_path)
    connection.execute("PRAGMA journal_mode = OFF")
    connection.execute("PRAGMA synchronous = OFF")
    connection.execute("PRAGMA temp_store = MEMORY")
    connection.execute("PRAGMA locking_mode = EXCLUSIVE")
    _create_index_table(connection)

    file_counts = {}
    try:
        with ZipFile(contents.zip_path) as archive:
            stage = 0
            for period in DAYPARTS:
                member = contents.general_members[period]
                file_counts[member] = _import_member(
                    archive,
                    connection,
                    member,
                    period,
                    GENERAL_SPECS,
                    stage,
                    progress_callback,
                    cancel_callback,
                )
                stage += 1

                member = contents.loaded_members[period]
                file_counts[member] = _import_member(
                    archive,
                    connection,
                    member,
                    period,
                    LOADED_SPECS,
                    stage,
                    progress_callback,
                    cancel_callback,
                )
                stage += 1
        connection.execute("ANALYZE links")
        return LoadnetIndex(database_path, connection, contents, file_counts)
    except Exception:
        connection.close()
        try:
            Path(database_path).unlink()
        except FileNotFoundError:
            pass
        raise


def write_loaded_geopackage(
    source_layer,
    loadnet_index,
    output_path,
    layer_name="geladen_netwerk",
    progress_callback=None,
    cancel_callback=None,
):
    """Write the linked shape and register OS/RD/AS views in one GeoPackage."""

    from osgeo import ogr, osr
    from qgis.core import NULL, QgsWkbTypes

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    _remove_geopackage_files(output_path)

    driver = ogr.GetDriverByName("GPKG")
    dataset = driver.CreateDataSource(str(output_path))
    if dataset is None:
        raise GmZipLoadnetError(f"GeoPackage kon niet worden gemaakt: {output_path}")

    spatial_ref = None
    if source_layer.crs().isValid():
        spatial_ref = osr.SpatialReference()
        spatial_ref.ImportFromWkt(source_layer.crs().toWkt())

    geometry_type = _ogr_geometry_type(source_layer.wkbType(), QgsWkbTypes, ogr)
    output_layer = dataset.CreateLayer(
        layer_name,
        spatial_ref,
        geometry_type,
        options=["GEOMETRY_NAME=geom", "FID=fid", "SPATIAL_INDEX=YES"],
    )
    if output_layer is None:
        dataset = None
        raise GmZipLoadnetError("De gecombineerde GeoPackage-laag kon niet worden gemaakt.")

    source_fields = list(source_layer.fields())
    source_names = [field.name() for field in source_fields]
    existing_names = {name.casefold() for name in source_names}
    linked_fields = [
        field for field in OUTPUT_FIELDS if field.casefold() not in existing_names
    ]

    for field in source_fields:
        output_layer.CreateField(_ogr_field_from_qgs(field, ogr))
    for field_name in linked_fields:
        output_layer.CreateField(ogr.FieldDefn(field_name, ogr.OFTReal))

    definition = output_layer.GetLayerDefn()
    matched = 0
    used_keys = set()
    total = max(0, source_layer.featureCount())
    key_fields = _source_key_fields(source_layer)
    output_layer.StartTransaction()

    try:
        for processed, source_feature in enumerate(source_layer.getFeatures(), start=1):
            if cancel_callback and cancel_callback():
                raise GmZipLoadnetCancelled()

            a_value, b_value = _feature_key(source_feature, key_fields)
            linked_values = None
            if a_value is not None and b_value is not None:
                linked_values = loadnet_index.lookup(a_value, b_value)
            if linked_values is not None:
                matched += 1
                used_keys.add((int(a_value), int(b_value)))

            output_feature = ogr.Feature(definition)
            geometry = source_feature.geometry()
            if geometry is not None and not geometry.isEmpty():
                output_feature.SetGeometry(
                    ogr.CreateGeometryFromWkb(bytes(geometry.asWkb()))
                )

            for field_index, value in enumerate(source_feature.attributes()):
                if value is None or value == NULL:
                    continue
                _set_ogr_value(output_feature, field_index, value)

            offset = len(source_fields)
            if linked_values is not None:
                for linked_index, field_name in enumerate(linked_fields):
                    value = linked_values.get(field_name)
                    if value is not None:
                        output_feature.SetField(offset + linked_index, float(value))

            if output_layer.CreateFeature(output_feature) != ogr.OGRERR_NONE:
                raise GmZipLoadnetError(
                    f"Link {processed} kon niet naar het GeoPackage worden geschreven."
                )
            output_feature = None

            if processed % 500 == 0 and progress_callback:
                progress_callback(processed, total)

        output_layer.CommitTransaction()
        if progress_callback:
            progress_callback(total, total)
    except Exception:
        output_layer.RollbackTransaction()
        dataset = None
        _remove_geopackage_files(output_path)
        raise

    dataset = None
    actual_fields = source_names + linked_fields
    _create_daypart_views(
        output_path,
        layer_name,
        source_names,
        actual_fields,
        total,
    )

    return {
        "output_path": output_path,
        "layer_name": layer_name,
        "view_names": {period: f"{layer_name}_{period.casefold()}" for period in DAYPARTS},
        "shape_total": total,
        "data_total": loadnet_index.record_count,
        "matched": matched,
        "unmatched_shape": total - matched,
        "unused_data": loadnet_index.record_count - len(used_keys),
        "linked_fields": linked_fields,
    }


def calculate_loadnet_values(raw_values):
    """Apply the original bldldnet_20251001.s calculations."""

    values = {
        field: _number(raw_values.get(field))
        for field in RAW_FIELDS
    }

    for period in DAYPARTS:
        values[f"{period}_L1"] = (
            values[f"{period}_COMM"]
            + values[f"{period}_BUSS"]
            + values[f"{period}_OTHR"]
            + values[f"{period}_BEST1"]
        )
        values[f"{period}_L2"] = (
            values[f"{period}_FRGT2"] + values[f"{period}_BEST2"]
        )
        values[f"{period}_L3"] = values[f"{period}_FRGT3"]
        values[f"{period}_L23"] = (
            values[f"{period}_L2"] + values[f"{period}_L3"]
        )
        values[f"{period}_L123"] = (
            values[f"{period}_L1"]
            + values[f"{period}_L2"]
            + values[f"{period}_L3"]
        )

    values["ET_L1"] = (
        2 * values["OS_L1"] + 2 * values["AS_L1"] + 12.54 * values["RD_L1"]
    )
    values["ET_L2"] = (
        2 * values["OS_L2"] + 2 * values["AS_L2"] + 10.50 * values["RD_L2"]
    )
    values["ET_L3"] = (
        2 * values["OS_L3"] + 2 * values["AS_L3"] + 11.46 * values["RD_L3"]
    )
    values["ET_L23"] = values["ET_L2"] + values["ET_L3"]
    values["ET_L123"] = values["ET_L1"] + values["ET_L2"] + values["ET_L3"]

    distance = values["DISTANCE"]
    for period in DAYPARTS:
        speed = values[f"{period}_TSVA"]
        total_time = values[f"{period}_TCST"]
        if total_time > 0:
            speed = distance / total_time * 3.6
        if speed > values[f"{period}_TSVA"]:
            speed = values[f"{period}_TSVA"]
        values[f"{period}_SPEED"] = speed

        flcpw = values[f"{period}_FLCPW"]
        values[f"{period}_IC"] = (
            values[f"{period}_QBB"] / flcpw if flcpw > 0 else 0.0
        )
        values[f"{period}_SPEED_LOSS"] = max(0, values[f"{period}_TSVA"] - cube_round(speed))
        values[f"{period}_EXTRA_TIME"] = max(0, total_time - values[f"{period}_FCST"])
        values[f"{period}_OFFERED_LOAD"] = values[f"{period}_FLOW"] / flcpw if flcpw > 0 else None
        vehicles = values[f"{period}_VTG"]
        values[f"{period}_FREIGHT_SHARE"] = 100 * (values[f"{period}_FRGT2"] + values[f"{period}_FRGT3"]) / vehicles if vehicles > 0 else None

    values["OS_VVU100"] = 0.0
    values["RD_VVU100"] = 0.0
    values["AS_VVU100"] = 0.0
    values["ET_VVU100"] = 0.0
    if values["HWN"] > 0 and values["OS_CAP"] != 99999:
        reference_car = cube_round(3.6 * distance / 100)
        reference_freight = cube_round(3.6 * distance / 80)
        weights = {"OS": 2, "RD": 9, "AS": 2}
        for period in DAYPARTS:
            if values[f"{period}_FLOW"] <= 0:
                continue
            car_delay = (
                max(
                    0,
                    values[f"{period}_DCST"]
                    - max(reference_car, values[f"{period}_FCST"]),
                )
                + values[f"{period}_WCST"]
            )
            freight_delay = (
                max(
                    0,
                    values[f"{period}_DCST"]
                    - max(reference_freight, values[f"{period}_FRGTFF"]),
                )
                + values[f"{period}_WCST"]
            )
            values[f"{period}_VVU100"] = weights[period] * (
                car_delay
                * (values[f"{period}_L1"] + values[f"{period}_BEST2"])
                + freight_delay
                * (values[f"{period}_FRGT3"] + values[f"{period}_FRGT2"])
            ) / 3600.0
        values["ET_VVU100"] = cube_round(
            values["OS_VVU100"]
            + values["RD_VVU100"]
            + values["AS_VVU100"]
        )

    period_vehicles = {
        "OS": (
            2 * values["OS_L1"],
            2 * values["OS_L2"],
            2 * values["OS_L3"],
        ),
        "AS": (
            2 * values["AS_L1"],
            2 * values["AS_L2"],
            2 * values["AS_L3"],
        ),
        # This deliberately mirrors the original script, including AS_BEST2.
        "RD": (
            12.54 * values["RD_L1"],
            10.50 * (values["RD_FRGT2"] + values["AS_BEST2"]),
            11.46 * values["RD_L3"],
        ),
    }

    for period in DAYPARTS:
        stagnation = (0.0, 0.0, 0.0)
        flcpw = values[f"{period}_FLCPW"]
        if values[f"{period}_CAP"] > 0 and flcpw > 0:
            ic_weight = values[f"{period}_FLOW"] / flcpw
            if ic_weight > 0.9:
                factor = min(1.0, (ic_weight - 0.9) / (1.1 - 0.9))
                stagnation = tuple(
                    factor * vehicle_count
                    for vehicle_count in period_vehicles[period]
                )
        values[f"{period}_L1_STF"] = stagnation[0]
        values[f"{period}_L2_STF"] = stagnation[1]
        values[f"{period}_L3_STF"] = stagnation[2]

    for vehicle_class in ("L1", "L2", "L3"):
        values[f"ET_{vehicle_class}_STF"] = sum(
            values[f"{period}_{vehicle_class}_STF"]
            for period in DAYPARTS
        )

    for period in DAYPARTS:
        for suffix in ("FLOW", "QBB", "VTG", "VVU100", "L1", "L2", "L3", "L23", "L123"):
            values[f"{period}_{suffix}"] = cube_round(values[f"{period}_{suffix}"])
        values[f"{period}_SPEED"] = cube_round(values[f"{period}_SPEED"])
        values[f"{period}_IC"] = cube_round(100 * values[f"{period}_IC"]) / 100.0
        for suffix in ("L1_STF", "L2_STF", "L3_STF"):
            values[f"{period}_{suffix}"] = cube_round(values[f"{period}_{suffix}"])

    for field in ("ET_L1", "ET_L2", "ET_L3", "ET_L23", "ET_L123", *ET_FIELDS[-3:]):
        values[field] = cube_round(values[field])

    return {field: values.get(field, 0.0) for field in OUTPUT_FIELDS}


def cube_round(value):
    """CUBE-style rounding, avoiding Python's ties-to-even behaviour."""

    value = float(value)
    if value >= 0:
        return int(math.floor(value + 0.5))
    return int(math.ceil(value - 0.5))


def _discover_shape_member(archive, normalised):
    gm_members = [
        name for name in archive.namelist() if name.casefold().endswith(".gm")
    ]
    for gm_member in gm_members:
        text = archive.read(gm_member).decode("cp1252", errors="replace")
        match = re.search(r"(?im)^\s*SHP\s*=\s*(.+?)\s*$", text)
        if not match:
            continue
        referenced = _normalise_member(match.group(1)).casefold()
        if referenced in normalised:
            return normalised[referenced]

    candidates = [
        original
        for key, original in normalised.items()
        if key.startswith("input/") and key.endswith(".shp")
    ]
    cube_candidates = [
        name for name in candidates if "cube" in Path(_normalise_member(name)).stem.casefold()
    ]
    if len(cube_candidates) == 1:
        return cube_candidates[0]
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise GmZipLoadnetError("Geen netwerkshape gevonden onder Input in de GMZIP.")
    raise GmZipLoadnetError(
        "Meerdere netwerkshapes gevonden in de GMZIP; de .gm verwijst niet eenduidig naar één SHP."
    )


def _discover_result_member(names, stem, period_number, shape_member):
    pattern = re.compile(
        rf"(?:^|/){re.escape(stem)}_{period_number}[^/]*\.dat$",
        re.IGNORECASE,
    )
    candidates = [
        name for name in names if pattern.search(_normalise_member(name))
    ]
    if not candidates:
        raise GmZipLoadnetError(
            f"{stem.upper()} voor dagdeel {period_number} ontbreekt in de GMZIP."
        )

    year_match = re.search(r"(20\d{2})", Path(_normalise_member(shape_member)).stem)
    year_suffix = year_match.group(1)[-2:] if year_match else ""

    def score(member):
        normalised = _normalise_member(member).casefold()
        basename = Path(normalised).name
        return (
            0 if "/matrix/assign/iter6/" in f"/{normalised}" else 1,
            0 if normalised.startswith("network/") else 1,
            0 if year_suffix and year_suffix in basename else 1,
            len(normalised),
        )

    candidates.sort(key=score)
    if len(candidates) > 1 and score(candidates[0]) == score(candidates[1]):
        raise GmZipLoadnetError(
            f"Meerdere gelijkwaardige {stem.upper()}-bestanden voor dagdeel {period_number} gevonden."
        )
    return candidates[0]


def _create_index_table(connection):
    columns = ", ".join(f"{_quote(field)} REAL" for field in RAW_FIELDS)
    connection.execute(
        f"CREATE TABLE links (a INTEGER NOT NULL, b INTEGER NOT NULL, {columns}, PRIMARY KEY (a, b)) WITHOUT ROWID"
    )


def _import_member(
    archive,
    connection,
    member,
    period,
    specs,
    stage,
    progress_callback,
    cancel_callback,
):
    common_names = [
        name for name, _start, _end in specs if name in COMMON_FIELDS
    ]
    day_names = [
        name for name, _start, _end in specs if name not in {"A", "B", *COMMON_FIELDS}
    ]
    columns = [
        *common_names,
        *(f"{period}_{name}" for name in day_names),
    ]
    insert_columns = ", ".join(("a", "b", *(_quote(name) for name in columns)))
    placeholders = ", ".join("?" for _ in range(2 + len(columns)))
    updates = ", ".join(
        f"{_quote(name)} = excluded.{_quote(name)}"
        for name in columns
    )
    sql = (
        f"INSERT INTO links ({insert_columns}) VALUES ({placeholders}) "
        f"ON CONFLICT(a, b) DO UPDATE SET {updates}"
    )

    count = 0
    batch = []
    connection.execute("BEGIN")
    try:
        with archive.open(member) as handle:
            for raw_line in handle:
                if cancel_callback and cancel_callback():
                    raise GmZipLoadnetCancelled()
                raw_line = raw_line.rstrip(b"\r\n")
                if not raw_line.strip():
                    continue
                parsed = _parse_fixed_width(raw_line, specs)
                a_value = int(parsed.pop("A"))
                b_value = int(parsed.pop("B"))
                row = [a_value, b_value]
                row.extend(parsed.get(name, 0.0) for name in common_names)
                row.extend(parsed.get(name, 0.0) for name in day_names)
                batch.append(tuple(row))
                count += 1
                if len(batch) >= 2000:
                    connection.executemany(sql, batch)
                    batch = []
                    if progress_callback:
                        progress_callback(stage, count, member)
            if batch:
                connection.executemany(sql, batch)
        connection.commit()
    except Exception:
        connection.rollback()
        raise

    if progress_callback:
        progress_callback(stage, count, member)
    return count


def _parse_fixed_width(raw_line, specs):
    values = {}
    for name, start, end in specs:
        raw_value = raw_line[start - 1 : end].strip()
        if not raw_value:
            values[name] = 0.0
            continue
        try:
            values[name] = float(raw_value)
        except ValueError as exc:
            text = raw_value.decode("ascii", errors="replace")
            raise GmZipLoadnetError(
                f"Waarde '{text}' in veld {name} kon niet worden gelezen."
            ) from exc
    return values


def _source_key_fields(source_layer):
    field_names = {name.casefold(): name for name in source_layer.fields().names()}
    a_field = field_names.get("knoopa") or field_names.get("a")
    b_field = field_names.get("knoopb") or field_names.get("b")
    if a_field is None or b_field is None:
        raise GmZipLoadnetError(
            "De shape in de GMZIP heeft geen KnoopA/KnoopB- of A/B-velden."
        )
    return a_field, b_field


def _feature_key(feature, key_fields):
    a_field, b_field = key_fields
    try:
        return int(feature[a_field]), int(feature[b_field])
    except (TypeError, ValueError):
        return None, None


def _ogr_geometry_type(wkb_type, qgs_wkb_types, ogr):
    geometry_type = qgs_wkb_types.geometryType(wkb_type)
    if geometry_type != qgs_wkb_types.LineGeometry:
        raise GmZipLoadnetError("De shape in de GMZIP is geen lijnlaag.")
    if qgs_wkb_types.isMultiType(wkb_type):
        return ogr.wkbMultiLineString
    return ogr.wkbLineString


def _ogr_field_from_qgs(field, ogr):
    type_name = field.typeName().casefold()
    if "int" in type_name:
        ogr_type = ogr.OFTInteger64
    elif any(token in type_name for token in ("real", "double", "float", "numeric", "decimal")):
        ogr_type = ogr.OFTReal
    elif "datetime" in type_name:
        ogr_type = ogr.OFTDateTime
    elif "date" in type_name:
        ogr_type = ogr.OFTDate
    else:
        ogr_type = ogr.OFTString

    output = ogr.FieldDefn(field.name(), ogr_type)
    if field.length() > 0:
        output.SetWidth(field.length())
    if field.precision() > 0:
        output.SetPrecision(field.precision())
    return output


def _set_ogr_value(feature, field_index, value):
    if hasattr(value, "toPyDateTime"):
        value = value.toPyDateTime().isoformat(sep=" ")
    elif hasattr(value, "toPyDate"):
        value = value.toPyDate().isoformat()
    elif not isinstance(value, (str, int, float, bytes)):
        value = str(value)
    feature.SetField(field_index, value)


def _create_daypart_views(
    output_path,
    main_layer,
    source_fields,
    actual_fields,
    feature_count,
):
    connection = sqlite3.connect(output_path)
    try:
        contents = connection.execute(
            """
            SELECT data_type, description, last_change, min_x, min_y, max_x, max_y, srs_id
            FROM gpkg_contents
            WHERE table_name = ?
            """,
            (main_layer,),
        ).fetchone()
        geometry = connection.execute(
            """
            SELECT column_name, geometry_type_name, srs_id, z, m
            FROM gpkg_geometry_columns
            WHERE table_name = ?
            """,
            (main_layer,),
        ).fetchone()
        if contents is None or geometry is None:
            raise GmZipLoadnetError("GeoPackage-metadata voor de geladen netwerklaag ontbreekt.")

        common_actual = [
            field for field in COMMON_FIELDS if field in actual_fields
        ]
        for period in DAYPARTS:
            view_name = f"{main_layer}_{period.casefold()}"
            period_fields = [
                field
                for field in actual_fields
                if field.startswith(f"{period}_")
            ]
            selected_fields = list(
                dict.fromkeys(("fid", geometry[0], *source_fields, *common_actual, *period_fields))
            )
            selected_sql = ", ".join(_quote(field) for field in selected_fields)
            connection.execute(
                f"CREATE VIEW {_quote(view_name)} AS "
                f"SELECT {selected_sql} FROM {_quote(main_layer)}"
            )
            connection.execute(
                """
                INSERT INTO gpkg_contents
                    (table_name, data_type, identifier, description, last_change,
                     min_x, min_y, max_x, max_y, srs_id)
                VALUES (?, 'features', ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    view_name,
                    f"{period} geladen netwerk",
                    f"{period}-velden uit {main_layer}",
                    contents[2],
                    contents[3],
                    contents[4],
                    contents[5],
                    contents[6],
                    contents[7],
                ),
            )
            connection.execute(
                """
                INSERT INTO gpkg_geometry_columns
                    (table_name, column_name, geometry_type_name, srs_id, z, m)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (view_name, *geometry),
            )
            if _table_exists(connection, "gpkg_ogr_contents"):
                connection.execute(
                    "INSERT OR REPLACE INTO gpkg_ogr_contents (table_name, feature_count) VALUES (?, ?)",
                    (view_name, feature_count),
                )
        connection.commit()
    finally:
        connection.close()


def _table_exists(connection, table_name):
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table_name,),
    ).fetchone()
    return row is not None


def _remove_geopackage_files(path):
    for candidate in (
        Path(path),
        Path(f"{path}-wal"),
        Path(f"{path}-shm"),
        Path(f"{path}-journal"),
    ):
        try:
            candidate.unlink()
        except FileNotFoundError:
            pass


def _normalise_member(member):
    return str(member).replace("\\", "/").lstrip("./")


def _quote(identifier):
    return '"' + str(identifier).replace('"', '""') + '"'


def _number(value):
    if value is None:
        return 0.0
    return float(value)
