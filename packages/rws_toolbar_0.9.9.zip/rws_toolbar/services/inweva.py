"""Shared matching helpers for INWEVA and LMS/NRM network links."""

from collections import defaultdict
from dataclasses import dataclass
import re

from qgis.core import QgsGeometry, QgsPointXY, QgsCoordinateTransform, QgsProject


@dataclass(frozen=True)
class InwevaCandidate:
    """One directional INWEVA feature referenced by a WVK ID."""

    feature_id: int
    attributes: tuple
    geometry: QgsGeometry


@dataclass
class InwevaIndex:
    """INWEVA candidates indexed by normalized WVK ID."""

    candidates: dict
    reference_count: int
    duplicate_references: int


def build_inweva_index(
    inweva_layer,
    id_field_name,
    progress_callback=None,
    cancel_callback=None,
    target_crs=None,
):
    """Index every WVK_IDS reference, retaining both directional candidates."""
    id_index = inweva_layer.fields().lookupField(id_field_name)
    if id_index < 0:
        raise ValueError(f"Het veld '{id_field_name}' bestaat niet in de INWEVA-laag.")

    transform = None
    if target_crs is not None and inweva_layer.crs() != target_crs:
        if not inweva_layer.crs().isValid() or not target_crs.isValid():
            raise ValueError('Een geldig coördinatenstelsel is nodig voor de richtingscontrole.')
        transform = QgsCoordinateTransform(inweva_layer.crs(), target_crs, QgsProject.instance())
    candidates = defaultdict(list)
    reference_count = 0
    duplicate_references = 0

    for processed, feature in enumerate(inweva_layer.getFeatures(), 1):
        geometry = QgsGeometry(feature.geometry())
        if transform is not None:
            geometry.transform(transform)
        candidate = InwevaCandidate(
            feature_id=int(feature.id()),
            attributes=tuple(feature.attributes()),
            geometry=geometry,
        )
        for link_id in split_link_ids(feature.attributes()[id_index]):
            reference_count += 1
            if candidates[link_id]:
                duplicate_references += 1
            candidates[link_id].append(candidate)

        if processed % 500 == 0:
            if progress_callback is not None:
                progress_callback(processed)
            if cancel_callback is not None and cancel_callback():
                break

    return InwevaIndex(
        candidates=dict(candidates),
        reference_count=reference_count,
        duplicate_references=duplicate_references,
    )


def match_inweva_candidate(network_feature, network_id_field_name, inweva_index):
    """Return the INWEVA candidate matching WVK ID and network direction."""
    link_id = normalise_link_id(network_feature[network_id_field_name])
    if link_id is None:
        return None, None, False

    candidates = inweva_index.candidates.get(link_id, ())
    if not candidates:
        return link_id, None, False
    network_geometry = network_feature.geometry()
    best_candidate = max(
        candidates,
        key=lambda candidate: _direction_score(network_geometry, candidate),
    )
    score = _direction_score(network_geometry, best_candidate)
    # An ID alone is insufficient: opposite or remote geometries must not match.
    if not score[0] or best_candidate.geometry.distance(network_geometry) > max(network_geometry.length(), best_candidate.geometry.length()) * 0.02:
        return link_id, None, len(candidates) > 1
    return link_id, best_candidate, len(candidates) > 1


def split_link_ids(value):
    """Split a WVK_IDS value into normalized identifiers."""
    if value is None:
        return []
    link_ids = []
    for part in re.split(r"[,;\s]+", str(value)):
        normalized = normalise_link_id(part)
        if normalized:
            link_ids.append(normalized)
    return link_ids


def normalise_link_id(value):
    """Normalize numeric and textual WVK identifiers to a stable string."""
    if value is None:
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value != value:
            return None
        if value.is_integer():
            return str(int(value))
        return str(value).rstrip("0").rstrip(".")

    text = str(value).strip()
    if not text or text.casefold() in {"null", "none"}:
        return None
    text = text.replace(" ", "")
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        return text.split(".", 1)[0]
    return text


def _direction_score(network_geometry, candidate):
    """Prefer the candidate whose geometry runs from network start to end."""
    if network_geometry is None or network_geometry.isEmpty():
        return 0, 0.0, 0.0, -candidate.feature_id
    if candidate.geometry is None or candidate.geometry.isEmpty():
        return 0, 0.0, 0.0, -candidate.feature_id

    vertices = list(network_geometry.vertices())
    if len(vertices) < 2:
        return 0, 0.0, 0.0, -candidate.feature_id

    start = QgsGeometry.fromPointXY(QgsPointXY(vertices[0]))
    end = QgsGeometry.fromPointXY(QgsPointXY(vertices[-1]))
    start_measure = candidate.geometry.lineLocatePoint(start)
    end_measure = candidate.geometry.lineLocatePoint(end)
    if start_measure < 0 or end_measure < 0:
        return 0, 0.0, 0.0, -candidate.feature_id

    same_direction = int(end_measure > start_measure)
    covered_span = abs(end_measure - start_measure)
    endpoint_distance = candidate.geometry.distance(start) + candidate.geometry.distance(end)
    return same_direction, covered_span, -endpoint_distance, -candidate.feature_id


def match_quality(network_geometry, candidate, tolerance):
    """Fraction covered by this one INWEVA segment, not a chain aggregation."""
    if network_geometry.isEmpty() or network_geometry.length() <= 0:
        return 'onbekend', 0.0
    overlap = network_geometry.intersection(candidate.geometry.buffer(tolerance, 5))
    coverage = min(1.0, max(0.0, overlap.length() / network_geometry.length()))
    return ('segment' if coverage < 0.9 else 'dekking_geometrie'), coverage
