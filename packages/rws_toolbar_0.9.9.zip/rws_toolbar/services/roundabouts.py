"""Detect likely roundabouts in line-based LMS/NRM networks."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from heapq import heappop, heappush
from itertools import count
from math import atan2, degrees, hypot, pi, sqrt

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsVectorLayer,
    QgsWkbTypes,
)


class RoundaboutCancelled(Exception):
    """Raised when the user cancels roundabout detection."""


@dataclass(frozen=True)
class RoundaboutSettings:
    """Heuristic thresholds for likely roundabout loops."""

    snap_tolerance: float = 0.01
    min_diameter: float = 8.0
    max_diameter: float = 220.0
    min_perimeter: float = 20.0
    max_perimeter: float = 750.0
    max_bbox_ratio: float = 3.0
    min_compactness: float = 0.45
    min_shape_score: float = 0.42
    poor_shape_score: float = 0.55
    min_vertices: int = 12
    min_attachment_nodes: int = 2
    max_chain_cycles: int = 10
    min_score: float = 0.58
    overlap_limit: float = 0.35
    sharp_turn_angle: float = 70.0
    hard_turn_angle: float = 125.0
    straight_run_turn_angle: float = 24.0
    max_straight_fraction_for_poor_shape: float = 0.25
    max_straight_fraction_with_sharp_turns: float = 0.22


@dataclass
class RoundaboutResult:
    """Layers and counters produced by roundabout detection."""

    link_layer: QgsVectorLayer
    area_layer: QgsVectorLayer
    candidate_count: int
    selected_count: int
    link_count: int
    source_count: int


@dataclass
class _Edge:
    index: int
    feature_id: int
    node_a: str
    node_b: str
    point_a: QgsPointXY
    point_b: QgsPointXY
    geometry: QgsGeometry
    length: float
    segment_id: str
    knoop_a: str
    knoop_b: str

    def other(self, node_id: str) -> str:
        return self.node_b if node_id == self.node_a else self.node_a


@dataclass
class _Chain:
    index: int
    node_a: str
    node_b: str
    edge_ids: tuple[int, ...]
    length: float
    points: tuple[QgsPointXY, ...]

    def other(self, node_id: str) -> str:
        return self.node_b if node_id == self.node_a else self.node_a


@dataclass
class _Candidate:
    edge_ids: frozenset[int]
    chain_ids: tuple[int, ...]
    points: tuple[QgsPointXY, ...]
    score: float
    confidence: str
    area: float
    perimeter: float
    diameter: float
    compactness: float
    bbox_ratio: float
    attachment_nodes: int
    attachment_edges: int
    vertex_count: int
    shape_score: float
    max_turn: float
    sharp_turns: int
    straight_fraction: float


@dataclass(frozen=True)
class _ShapeMetrics:
    score: float
    max_turn: float
    sharp_turns: int
    straight_fraction: float


def build_roundabout_layers(
    source_layer,
    settings: RoundaboutSettings | None = None,
    progress_callback=None,
    cancel_callback=None,
) -> RoundaboutResult:
    """Build temporary line and polygon layers with likely roundabouts."""

    settings = settings or RoundaboutSettings()
    fields = _source_fields(source_layer)
    edges, adjacency = _read_edges(
        source_layer,
        fields,
        settings,
        progress_callback=progress_callback,
        cancel_callback=cancel_callback,
    )
    if not edges:
        link_layer, area_layer = _new_result_layers(source_layer)
        return RoundaboutResult(link_layer, area_layer, 0, 0, 0, 0)

    chains = _build_chains(edges, adjacency, progress_callback, cancel_callback)
    candidates = _find_candidates(
        edges,
        chains,
        adjacency,
        settings,
        progress_callback=progress_callback,
        cancel_callback=cancel_callback,
    )
    selected = _select_candidates(candidates, settings)
    link_layer, area_layer = _new_result_layers(source_layer)
    _write_layers(link_layer, area_layer, selected, edges)

    return RoundaboutResult(
        link_layer=link_layer,
        area_layer=area_layer,
        candidate_count=len(candidates),
        selected_count=len(selected),
        link_count=link_layer.featureCount(),
        source_count=len(edges),
    )


def _source_fields(layer):
    return {
        "segment": _find_field(layer, ("Segment_ID", "SEGMENT_ID", "SEGMENTID", "LINK_ID")),
        "knoopa": _find_field(layer, ("KnoopA", "KNOOPA", "A")),
        "knoopb": _find_field(layer, ("KnoopB", "KNOOPB", "B")),
    }


def _find_field(layer, names):
    wanted = {name.casefold() for name in names}
    for field in layer.fields():
        if field.name().casefold() in wanted:
            return field.name()
    return None


def _read_edges(
    layer,
    fields,
    settings,
    progress_callback=None,
    cancel_callback=None,
):
    edges = []
    adjacency = defaultdict(list)
    total = max(0, int(layer.featureCount()))
    for processed, feature in enumerate(layer.getFeatures(), 1):
        if cancel_callback and cancel_callback():
            raise RoundaboutCancelled()

        geometry = feature.geometry()
        points = _geometry_points(geometry)
        if len(points) < 2:
            continue

        point_a = points[0]
        point_b = points[-1]
        node_a = _field_value(feature, fields["knoopa"]) if fields["knoopa"] else ""
        node_b = _field_value(feature, fields["knoopb"]) if fields["knoopb"] else ""
        if not node_a:
            node_a = _point_node_id(point_a, settings.snap_tolerance)
        if not node_b:
            node_b = _point_node_id(point_b, settings.snap_tolerance)

        edge = _Edge(
            index=len(edges),
            feature_id=feature.id(),
            node_a=node_a,
            node_b=node_b,
            point_a=point_a,
            point_b=point_b,
            geometry=QgsGeometry(geometry),
            length=max(0.0, geometry.length()),
            segment_id=_field_value(feature, fields["segment"]) if fields["segment"] else "",
            knoop_a=node_a,
            knoop_b=node_b,
        )
        if edge.length <= 0:
            continue

        edges.append(edge)
        adjacency[edge.node_a].append(edge.index)
        if edge.node_b != edge.node_a:
            adjacency[edge.node_b].append(edge.index)

        if progress_callback and (processed % 2500 == 0 or processed == total):
            progress_callback("Rotondecheck: netwerk lezen...", processed, total * 3)

    return edges, adjacency


def _build_chains(edges, adjacency, progress_callback=None, cancel_callback=None):
    degree = {node_id: len(edge_ids) for node_id, edge_ids in adjacency.items()}
    branch_nodes = {node_id for node_id, count in degree.items() if count != 2}
    visited_edges = set()
    chains = []

    def add_chain(node_a, node_b, edge_ids, points):
        if not edge_ids:
            return
        chain = _Chain(
            index=len(chains),
            node_a=node_a,
            node_b=node_b,
            edge_ids=tuple(edge_ids),
            length=sum(edges[edge_id].length for edge_id in edge_ids),
            points=tuple(_clean_points(points, 0.001)),
        )
        chains.append(chain)
        visited_edges.update(edge_ids)

    for edge in edges:
        if cancel_callback and cancel_callback():
            raise RoundaboutCancelled()
        if edge.index in visited_edges:
            continue
        if edge.node_a == edge.node_b:
            add_chain(edge.node_a, edge.node_b, [edge.index], _edge_points(edges, edge.index, edge.node_a))

    for node_id in list(branch_nodes):
        for edge_id in list(adjacency.get(node_id, [])):
            if cancel_callback and cancel_callback():
                raise RoundaboutCancelled()
            if edge_id in visited_edges:
                continue
            edge_ids, points, end_node = _follow_chain(
                node_id,
                edge_id,
                edges,
                adjacency,
                branch_nodes,
                visited_edges,
            )
            add_chain(node_id, end_node, edge_ids, points)

        if progress_callback and len(chains) % 1000 == 0:
            progress_callback("Rotondecheck: netwerkpaden maken...", len(edges), len(edges) * 3)

    for edge in edges:
        if cancel_callback and cancel_callback():
            raise RoundaboutCancelled()
        if edge.index in visited_edges:
            continue
        edge_ids, points, end_node = _follow_chain(
            edge.node_a,
            edge.index,
            edges,
            adjacency,
            branch_nodes,
            visited_edges,
            allow_degree_two_loop=True,
        )
        add_chain(edge.node_a, end_node, edge_ids, points)

    return chains


def _follow_chain(
    start_node,
    first_edge_id,
    edges,
    adjacency,
    branch_nodes,
    globally_visited,
    allow_degree_two_loop=False,
):
    edge_ids = []
    local_edges = set()
    current_node = start_node
    edge_id = first_edge_id
    points = []

    while True:
        if edge_id in local_edges:
            break
        local_edges.add(edge_id)
        edge_ids.append(edge_id)
        edge_points = _edge_points(edges, edge_id, current_node)
        points = _append_points(points, edge_points)
        next_node = edges[edge_id].other(current_node)

        if next_node == start_node and allow_degree_two_loop:
            return edge_ids, points, start_node
        if next_node in branch_nodes:
            return edge_ids, points, next_node

        candidates = [
            candidate
            for candidate in adjacency.get(next_node, [])
            if candidate != edge_id
            and candidate not in globally_visited
            and candidate not in local_edges
        ]
        if len(candidates) != 1:
            return edge_ids, points, next_node

        current_node = next_node
        edge_id = candidates[0]


def _find_candidates(
    edges,
    chains,
    adjacency,
    settings,
    progress_callback=None,
    cancel_callback=None,
):
    chain_adjacency = defaultdict(list)
    for chain in chains:
        chain_adjacency[chain.node_a].append(chain.index)
        if chain.node_b != chain.node_a:
            chain_adjacency[chain.node_b].append(chain.index)

    candidates = {}
    for index, chain in enumerate(chains, 1):
        if cancel_callback and cancel_callback():
            raise RoundaboutCancelled()

        if chain.node_a == chain.node_b:
            candidate = _score_candidate([chain], edges, adjacency, settings)
            if candidate is not None:
                candidates[candidate.edge_ids] = _best_candidate(
                    candidates.get(candidate.edge_ids),
                    candidate,
                )
        else:
            path = _shortest_chain_path(
                chain.node_b,
                chain.node_a,
                chain.index,
                chains,
                chain_adjacency,
                settings,
            )
            if path:
                candidate_chains = [chain] + [chains[chain_id] for chain_id in path]
                candidate = _score_candidate(candidate_chains, edges, adjacency, settings)
                if candidate is not None:
                    candidates[candidate.edge_ids] = _best_candidate(
                        candidates.get(candidate.edge_ids),
                        candidate,
                    )

        if progress_callback and (index % 500 == 0 or index == len(chains)):
            progress_callback(
                "Rotondecheck: lussen beoordelen...",
                len(edges) + index,
                max(1, len(edges) + len(chains) * 2),
            )

    return list(candidates.values())


def _shortest_chain_path(start_node, target_node, excluded_chain_id, chains, chain_adjacency, settings):
    sequence = count()
    heap = [
        (
            0.0,
            next(sequence),
            start_node,
            tuple(),
            frozenset({excluded_chain_id}),
            frozenset({start_node}),
        )
    ]
    best = {}

    while heap:
        distance, _sequence_id, node_id, path, used_chains, used_nodes = heappop(heap)
        if distance > settings.max_perimeter:
            continue
        if node_id == target_node and path:
            return path
        if len(path) >= settings.max_chain_cycles:
            continue

        for chain_id in chain_adjacency.get(node_id, []):
            if chain_id in used_chains:
                continue
            chain = chains[chain_id]
            next_node = chain.other(node_id)
            if next_node in used_nodes and next_node != target_node:
                continue
            next_distance = distance + chain.length
            if next_distance > settings.max_perimeter:
                continue
            if next_distance >= best.get((next_node, len(path) + 1), float("inf")):
                continue
            best[(next_node, len(path) + 1)] = next_distance
            heappush(
                heap,
                (
                    next_distance,
                    next(sequence),
                    next_node,
                    path + (chain_id,),
                    used_chains | {chain_id},
                    used_nodes | {next_node},
                ),
            )

    return None


def _score_candidate(candidate_chains, edges, adjacency, settings):
    edge_ids = frozenset(
        edge_id for chain in candidate_chains for edge_id in chain.edge_ids
    )
    if len(edge_ids) < 2 and all(edges[edge_id].node_a != edges[edge_id].node_b for edge_id in edge_ids):
        return None

    points = _candidate_points(candidate_chains)
    points = _clean_points(points, settings.snap_tolerance)
    if len(points) >= 2 and _point_distance(points[0], points[-1]) > settings.snap_tolerance:
        points.append(points[0])
    unique_vertices = max(0, len(points) - 1)
    if unique_vertices < settings.min_vertices:
        return None

    area = abs(_polygon_area(points))
    perimeter = sum(edges[edge_id].length for edge_id in edge_ids)
    if perimeter < settings.min_perimeter or perimeter > settings.max_perimeter:
        return None
    if area <= 0:
        return None

    diameter = sqrt((4.0 * area) / pi)
    if diameter < settings.min_diameter or diameter > settings.max_diameter:
        return None

    bbox_ratio = _bbox_ratio(points)
    if bbox_ratio > settings.max_bbox_ratio:
        return None

    compactness = (4.0 * pi * area) / (perimeter * perimeter) if perimeter else 0.0
    if compactness < settings.min_compactness:
        return None

    attachment_nodes, attachment_edges = _attachment_counts(edge_ids, edges, adjacency)
    if attachment_nodes < settings.min_attachment_nodes:
        return None

    segment_fraction = _longest_segment_fraction(points, perimeter)
    if segment_fraction > 0.45:
        return None

    shape = _shape_metrics(points, perimeter, settings)
    if shape.max_turn >= settings.hard_turn_angle:
        return None
    if (
        shape.sharp_turns >= 3
        and shape.straight_fraction >= settings.max_straight_fraction_with_sharp_turns
    ):
        return None
    if (
        shape.score < settings.poor_shape_score
        and shape.straight_fraction > settings.max_straight_fraction_for_poor_shape
    ):
        return None
    if shape.score < settings.min_shape_score:
        return None

    vertex_score = min(1.0, max(0.0, (unique_vertices - 4) / 10.0))
    ratio_score = min(1.0, max(0.0, (settings.max_bbox_ratio - bbox_ratio) / (settings.max_bbox_ratio - 1.0)))
    compactness_score = min(1.0, compactness / 0.85)
    segment_score = min(1.0, max(0.0, (0.45 - segment_fraction) / 0.35))
    attachment_score = min(1.0, attachment_nodes / 4.0)

    score = (
        0.24 * compactness_score
        + 0.16 * vertex_score
        + 0.15 * ratio_score
        + 0.13 * segment_score
        + 0.09 * attachment_score
        + 0.23 * shape.score
    )
    if score < settings.min_score:
        return None

    if score >= 0.78:
        confidence = "hoog"
    elif score >= 0.66:
        confidence = "middel"
    else:
        confidence = "laag"

    return _Candidate(
        edge_ids=edge_ids,
        chain_ids=tuple(chain.index for chain in candidate_chains),
        points=tuple(points),
        score=round(score, 3),
        confidence=confidence,
        area=area,
        perimeter=perimeter,
        diameter=diameter,
        compactness=compactness,
        bbox_ratio=bbox_ratio,
        attachment_nodes=attachment_nodes,
        attachment_edges=attachment_edges,
        vertex_count=unique_vertices,
        shape_score=shape.score,
        max_turn=shape.max_turn,
        sharp_turns=shape.sharp_turns,
        straight_fraction=shape.straight_fraction,
    )


def _best_candidate(old, new):
    if old is None:
        return new
    if new.score > old.score:
        return new
    return old


def _select_candidates(candidates, settings):
    selected = []
    selected_by_cell = defaultdict(list)
    used_edges = Counter()
    cell_size = 100.0
    for candidate in sorted(candidates, key=lambda item: item.score, reverse=True):
        if candidate.edge_ids:
            overlap = sum(1 for edge_id in candidate.edge_ids if used_edges[edge_id])
            if overlap / len(candidate.edge_ids) > settings.overlap_limit:
                continue
        candidate_bbox = _candidate_bbox(candidate)
        candidate_center = _candidate_center(candidate)
        nearby = _nearby_selected_candidates(selected_by_cell, candidate_center, cell_size)
        if _duplicates_selected_location(candidate, candidate_bbox, candidate_center, nearby):
            continue
        selected.append(candidate)
        selected_by_cell[_candidate_cell(candidate_center, cell_size)].append(
            (candidate, candidate_bbox, candidate_center)
        )
        for edge_id in candidate.edge_ids:
            used_edges[edge_id] += 1
    return selected


def _nearby_selected_candidates(selected_by_cell, center, cell_size):
    cell_x, cell_y = _candidate_cell(center, cell_size)
    nearby = []
    for dx in range(-2, 3):
        for dy in range(-2, 3):
            nearby.extend(selected_by_cell.get((cell_x + dx, cell_y + dy), []))
    return nearby


def _candidate_cell(center, cell_size):
    return (int(center.x() // cell_size), int(center.y() // cell_size))


def _duplicates_selected_location(candidate, candidate_bbox, candidate_center, selected_records):
    for existing, existing_bbox, existing_center in selected_records:
        overlap = _bbox_overlap_fraction(candidate_bbox, existing_bbox)
        center_distance = _point_distance(candidate_center, existing_center)
        center_limit = max(12.0, 0.28 * (candidate.diameter + existing.diameter))
        if overlap >= 0.65 or center_distance <= center_limit:
            return True
    return False


def _candidate_bbox(candidate):
    xs = [point.x() for point in candidate.points]
    ys = [point.y() for point in candidate.points]
    return (min(xs), min(ys), max(xs), max(ys))


def _candidate_center(candidate):
    points = candidate.points[:-1] if _same_point(candidate.points[0], candidate.points[-1], 0.001) else candidate.points
    if not points:
        return QgsPointXY(0, 0)
    return QgsPointXY(
        sum(point.x() for point in points) / len(points),
        sum(point.y() for point in points) / len(points),
    )


def _bbox_overlap_fraction(bbox_a, bbox_b):
    ax1, ay1, ax2, ay2 = bbox_a
    bx1, by1, bx2, by2 = bbox_b
    width = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    height = max(0.0, min(ay2, by2) - max(ay1, by1))
    intersection = width * height
    if intersection <= 0:
        return 0.0
    area_a = max(0.0, (ax2 - ax1) * (ay2 - ay1))
    area_b = max(0.0, (bx2 - bx1) * (by2 - by1))
    smallest = min(area_a, area_b)
    if smallest <= 0:
        return 0.0
    return intersection / smallest


def _write_layers(link_layer, area_layer, candidates, edges):
    link_features = []
    area_features = []

    for index, candidate in enumerate(candidates, 1):
        roundabout_id = f"R{index:04d}"
        advice = _candidate_advice(candidate)
        for edge_id in sorted(candidate.edge_ids):
            edge = edges[edge_id]
            feature = QgsFeature(link_layer.fields())
            feature.setGeometry(edge.geometry)
            feature.setAttributes(
                [
                    1,
                    roundabout_id,
                    edge.feature_id,
                    edge.segment_id,
                    edge.knoop_a,
                    edge.knoop_b,
                    candidate.score,
                    candidate.confidence,
                    advice,
                    "",
                    candidate.diameter,
                    candidate.perimeter,
                    candidate.attachment_nodes,
                    len(candidate.edge_ids),
                    candidate.shape_score,
                    candidate.max_turn,
                    candidate.sharp_turns,
                    candidate.straight_fraction,
                ]
            )
            link_features.append(feature)

        polygon = QgsGeometry.fromPolygonXY([list(candidate.points)])
        area_feature = QgsFeature(area_layer.fields())
        area_feature.setGeometry(polygon)
        area_feature.setAttributes(
            [
                roundabout_id,
                candidate.score,
                candidate.confidence,
                advice,
                "",
                candidate.diameter,
                candidate.perimeter,
                candidate.area,
                candidate.compactness,
                candidate.bbox_ratio,
                candidate.attachment_nodes,
                candidate.attachment_edges,
                len(candidate.edge_ids),
                candidate.vertex_count,
                candidate.shape_score,
                candidate.max_turn,
                candidate.sharp_turns,
                candidate.straight_fraction,
            ]
        )
        area_features.append(area_feature)

    if link_features:
        link_layer.dataProvider().addFeatures(link_features)
    if area_features:
        area_layer.dataProvider().addFeatures(area_features)
    link_layer.updateExtents()
    area_layer.updateExtents()


def _new_result_layers(source_layer):
    crs = source_layer.crs().authid()
    line_type = QgsWkbTypes.displayString(source_layer.wkbType())
    if not line_type or line_type == "Unknown":
        line_type = "LineString"

    link_layer = QgsVectorLayer(
        f"{line_type}?crs={crs}",
        "Rotonde kandidaatlinks",
        "memory",
    )
    link_provider = link_layer.dataProvider()
    link_provider.addAttributes(
        [
            QgsField("rotonde", QVariant.Int),
            QgsField("rotonde_id", QVariant.String),
            QgsField("fid_bron", QVariant.LongLong),
            QgsField("Segment_ID", QVariant.String),
            QgsField("KnoopA", QVariant.String),
            QgsField("KnoopB", QVariant.String),
            QgsField("score", QVariant.Double),
            QgsField("klasse", QVariant.String),
            QgsField("advies", QVariant.String),
            QgsField("controle", QVariant.String),
            QgsField("diam_m", QVariant.Double),
            QgsField("omtrek_m", QVariant.Double),
            QgsField("takken", QVariant.Int),
            QgsField("links", QVariant.Int),
            QgsField("vorm", QVariant.Double),
            QgsField("hoek_max", QVariant.Double),
            QgsField("scherp", QVariant.Int),
            QgsField("zij_frac", QVariant.Double),
        ]
    )
    link_layer.updateFields()

    area_layer = QgsVectorLayer(
        f"Polygon?crs={crs}",
        "Rotonde kandidaatvlakken",
        "memory",
    )
    area_provider = area_layer.dataProvider()
    area_provider.addAttributes(
        [
            QgsField("rotonde_id", QVariant.String),
            QgsField("score", QVariant.Double),
            QgsField("klasse", QVariant.String),
            QgsField("advies", QVariant.String),
            QgsField("controle", QVariant.String),
            QgsField("diam_m", QVariant.Double),
            QgsField("omtrek_m", QVariant.Double),
            QgsField("opp_m2", QVariant.Double),
            QgsField("compact", QVariant.Double),
            QgsField("bbox_ratio", QVariant.Double),
            QgsField("takknopen", QVariant.Int),
            QgsField("takken", QVariant.Int),
            QgsField("links", QVariant.Int),
            QgsField("vertices", QVariant.Int),
            QgsField("vorm", QVariant.Double),
            QgsField("hoek_max", QVariant.Double),
            QgsField("scherp", QVariant.Int),
            QgsField("zij_frac", QVariant.Double),
        ]
    )
    area_layer.updateFields()
    return link_layer, area_layer


def _candidate_advice(candidate):
    if candidate.shape_score < 0.60:
        return "controleer: hoekige vorm"
    if candidate.sharp_turns >= 2:
        return "controleer: scherpe hoeken"
    if candidate.straight_fraction > 0.28:
        return "controleer: lange zijde"
    if candidate.attachment_nodes <= 2:
        return "controleer: weinig aansluitingen"
    if candidate.bbox_ratio > 2.6:
        return "controleer: langwerpig"
    if candidate.compactness < 0.45:
        return "controleer: hoekig/laag compact"
    if candidate.score >= 0.78:
        return "waarschijnlijk rotonde"
    return "controleer"


def _candidate_points(chains):
    if not chains:
        return []

    points = []
    current_node = chains[0].node_a
    for chain in chains:
        oriented = _chain_points(chain, current_node)
        points = _append_points(points, oriented)
        current_node = chain.other(current_node)
    return points


def _chain_points(chain, from_node):
    points = list(chain.points)
    if from_node != chain.node_a:
        points.reverse()
    return points


def _edge_points(edges, edge_id, from_node):
    edge = edges[edge_id]
    points = _geometry_points(edge.geometry)
    if from_node != edge.node_a:
        points.reverse()
    return points


def _geometry_points(geometry):
    return [QgsPointXY(point) for point in geometry.vertices()]


def _append_points(existing, extra):
    if not extra:
        return existing
    if not existing:
        return list(extra)
    result = list(existing)
    start_index = 1 if _same_point(result[-1], extra[0], 0.001) else 0
    result.extend(extra[start_index:])
    return result


def _clean_points(points, tolerance):
    cleaned = []
    for point in points:
        if cleaned and _same_point(cleaned[-1], point, tolerance):
            continue
        cleaned.append(point)
    if len(cleaned) > 2 and _same_point(cleaned[0], cleaned[-1], tolerance):
        cleaned[-1] = cleaned[0]
    return cleaned


def _attachment_counts(edge_ids, edges, adjacency):
    ring_nodes = set()
    for edge_id in edge_ids:
        edge = edges[edge_id]
        ring_nodes.add(edge.node_a)
        ring_nodes.add(edge.node_b)

    attachment_nodes = 0
    attachment_edges = 0
    for node_id in ring_nodes:
        external = [edge_id for edge_id in adjacency.get(node_id, []) if edge_id not in edge_ids]
        if external:
            attachment_nodes += 1
            attachment_edges += len(external)
    return attachment_nodes, attachment_edges


def _polygon_area(points):
    if len(points) < 4:
        return 0.0
    total = 0.0
    for point, next_point in zip(points, points[1:]):
        total += point.x() * next_point.y() - next_point.x() * point.y()
    return total / 2.0


def _bbox_ratio(points):
    xs = [point.x() for point in points]
    ys = [point.y() for point in points]
    width = max(xs) - min(xs)
    height = max(ys) - min(ys)
    shortest = min(width, height)
    longest = max(width, height)
    if shortest <= 0:
        return float("inf")
    return longest / shortest


def _longest_segment_fraction(points, perimeter):
    if not points or perimeter <= 0:
        return 1.0
    longest = 0.0
    for point, next_point in zip(points, points[1:]):
        longest = max(longest, _point_distance(point, next_point))
    return longest / perimeter


def _shape_metrics(points, perimeter, settings):
    turn_angles = _turn_angles(points)
    max_turn = max(turn_angles) if turn_angles else 180.0
    sharp_turns = sum(1 for angle in turn_angles if angle >= settings.sharp_turn_angle)
    straight_fraction = _longest_low_curvature_fraction(
        points,
        perimeter,
        settings.straight_run_turn_angle,
    )

    turn_score = _turn_score_from_max(max_turn)
    corner_score = 1.0 - min(1.0, max(0.0, sharp_turns - 1) / 3.0)
    straight_score = 1.0 - min(1.0, max(0.0, straight_fraction - 0.20) / 0.18)
    score = max(
        0.0,
        min(
            1.0,
            0.45 * turn_score
            + 0.30 * corner_score
            + 0.25 * straight_score,
        ),
    )
    return _ShapeMetrics(
        score=score,
        max_turn=max_turn,
        sharp_turns=sharp_turns,
        straight_fraction=straight_fraction,
    )


def _turn_score(points):
    turn_angles = _turn_angles(points)
    if not turn_angles:
        return 0.0
    return _turn_score_from_max(max(turn_angles))


def _turn_score_from_max(max_turn):
    if max_turn <= 55:
        return 1.0
    if max_turn >= 115:
        return 0.0
    return (115 - max_turn) / 60.0


def _turn_angles(points):
    if len(points) < 5:
        return []
    unique = points[:-1] if _same_point(points[0], points[-1], 0.001) else points
    if len(unique) < 4:
        return []

    turns = []
    count = len(unique)
    for index, point in enumerate(unique):
        previous_point = unique[index - 1]
        next_point = unique[(index + 1) % count]
        a1 = atan2(point.y() - previous_point.y(), point.x() - previous_point.x())
        a2 = atan2(next_point.y() - point.y(), next_point.x() - point.x())
        delta = abs(degrees((a2 - a1 + pi) % (2 * pi) - pi))
        turns.append(delta)
    return turns


def _longest_low_curvature_fraction(points, perimeter, turn_limit):
    if len(points) < 5 or perimeter <= 0:
        return 1.0
    unique = points[:-1] if _same_point(points[0], points[-1], 0.001) else points
    if len(unique) < 4:
        return 1.0

    count = len(unique)
    turns = _turn_angles(points)
    if len(turns) != count:
        return 1.0

    segment_lengths = [
        _point_distance(unique[index], unique[(index + 1) % count])
        for index in range(count)
    ]
    if not segment_lengths:
        return 1.0

    longest = 0.0
    for start in range(count):
        run_length = 0.0
        turn_sum = 0.0
        for step in range(count):
            index = (start + step) % count
            run_length += segment_lengths[index]
            turn_sum += turns[(index + 1) % count]
            if turn_sum >= turn_limit:
                break
        longest = max(longest, run_length)

    return longest / perimeter


def _field_value(feature, field_name):
    value = feature[field_name]
    if value is None:
        return ""
    return str(value).strip()


def _point_node_id(point, tolerance):
    if tolerance <= 0:
        tolerance = 0.001
    return f"{round(point.x() / tolerance)}:{round(point.y() / tolerance)}"


def _same_point(point, other, tolerance):
    return _point_distance(point, other) <= tolerance


def _point_distance(point, other):
    return hypot(point.x() - other.x(), point.y() - other.y())
