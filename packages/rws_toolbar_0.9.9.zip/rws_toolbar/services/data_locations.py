"""Filesystem-only discovery, called by a background thread, never by a menu."""
from pathlib import Path


def scan_data_locations(default_root, fallback_root=None):
    root = Path(default_root)
    if not root.is_dir() and fallback_root:
        root = Path(fallback_root)
    result = {'root': root, 'regions': {}, 'zones': False, 'inweva': False, 'projects': False}
    for key, filename in [('zones', 'zones_2022.gpkg'), ('inweva', 'inweva_2025.gpkg'), ('projects', 'projects_rp2026.json')]:
        result[key] = (root / filename).is_file()
    library = root / 'RP2025 v2026'
    if not library.is_dir():
        return result
    folders = {p.name.casefold(): p for p in library.iterdir() if p.is_dir()}
    for region in ('LMS', 'Noord', 'Oost', 'West', 'Zuid'):
        folder = folders.get(region.casefold())
        if folder is None:
            continue
        candidates = [p for p in folder.iterdir() if p.suffix.casefold() == '.gpkg' and p.is_file()]
        preferred = next((p for p in candidates if p.stem.casefold() == f'rp25v2_{region}'.casefold()), None)
        if preferred is not None or len(candidates) == 1:
            result['regions'][region] = preferred or candidates[0]
    return result
