"""Private GitHub updates: QGIS authentication, verified downloads, next-start install."""
import configparser
import ast
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import uuid
import zipfile
from pathlib import Path

REPOSITORY = 'SRMulder/lmsnrm-qgis-updates'
MANIFEST_URL = f'https://raw.githubusercontent.com/{REPOSITORY}/main/update-manifest.json'


def version_tuple(value):
    if not re.fullmatch(r'\d+(?:\.\d+){1,3}', str(value)):
        raise ValueError('Ongeldig versienummer.')
    parts = tuple(int(p) for p in value.split('.'))
    return parts + (0,) * (4-len(parts))


def metadata(folder):
    parser = configparser.ConfigParser(interpolation=None)
    parser.read(Path(folder)/'metadata.txt', encoding='utf-8')
    return dict(parser['general'])


def state_dir(plugin_id):
    from qgis.core import QgsApplication
    path = Path(QgsApplication.qgisSettingsDirPath())/'plugin-updates'/plugin_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def verify_archive(path, plugin_id, version, digest):
    if not re.fullmatch('[a-f0-9]{64}', digest) or hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest:
        raise ValueError('Controle van het installatiebestand mislukt.')
    with zipfile.ZipFile(path) as archive:
        for item in archive.infolist():
            parts = item.filename.replace('\\', '/').split('/')
            if parts[0] != plugin_id or any(p in ('..', '') for p in parts[:-1]) or item.filename.startswith('/'):
                raise ValueError('Onveilig pad in installatiebestand.')
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Symbolische koppelingen zijn niet toegestaan.')
        if sum(i.file_size for i in archive.infolist()) > 512*1024*1024:
            raise ValueError('Installatiebestand is onverwacht groot.')
        parser = configparser.ConfigParser(interpolation=None)
        parser.read_string(archive.read(f'{plugin_id}/metadata.txt').decode('utf-8'))
        if parser['general']['version'] != version:
            raise ValueError('Versie in ZIP wijkt af van de update.')
        if f'{plugin_id}/__init__.py' not in archive.namelist() or archive.testzip():
            raise ValueError('Installatiebestand is beschadigd of onvolledig.')
        for name in archive.namelist():
            if name.endswith('.py'):
                ast.parse(archive.read(name).decode('utf-8'), filename=name)


def apply_pending(folder, state=None):
    folder = Path(folder)
    state = Path(state) if state else state_dir(folder.name)
    pending = state/'pending.json'
    if not pending.exists():
        return False
    info = json.loads(pending.read_text())
    if version_tuple(info['version']) <= version_tuple(metadata(folder)['version']):
        pending.unlink()
        return False
    archive_path = state/'pending.zip'
    verify_archive(archive_path, folder.name, info['version'], info['sha256'])
    staging = Path(tempfile.mkdtemp(prefix='.'+folder.name+'-update-', dir=folder.parent))
    backup = folder.with_name('.'+folder.name+'-backup-'+uuid.uuid4().hex[:8])
    try:
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(staging)
        folder.rename(backup)
        try:
            (staging/folder.name).rename(folder)
        except Exception:
            backup.rename(folder)
            raise
        pending.unlink()
        archive_path.unlink()
        # Keep the previous installed plugin available for recovery.
        (state/'previous.json').write_text(json.dumps({'backup':str(backup),'version':info['version']}))
        return True
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def fetch(url, authcfg, accept):
    from qgis.core import QgsNetworkAccessManager
    from qgis.PyQt.QtCore import QUrl
    from qgis.PyQt.QtNetwork import QNetworkRequest
    from urllib.parse import urlparse
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname != 'raw.githubusercontent.com' or not parsed.path.startswith(f'/{REPOSITORY}/main/'):
        raise ValueError('Onverwachte updatebron.')
    request = QNetworkRequest(QUrl(url))
    request.setRawHeader(b'Accept', accept.encode())
    reply = QgsNetworkAccessManager.blockingGet(request, authcfg, True)
    status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute if hasattr(QNetworkRequest,'Attribute') else QNetworkRequest.HttpStatusCodeAttribute)
    if int(status or 0) != 200:
        raise ValueError('GitHub-update niet bereikbaar. Controleer de internetverbinding.')
    return bytes(reply.content())


class UpdateManager:
    def __init__(self, iface, folder):
        self.iface, self.folder = iface, Path(folder)
        self.task = None
        self.action = None
        from qgis.PyQt.QtCore import QTimer
        self.timer = QTimer(iface.mainWindow())
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.check)
        self.timer.start(5000)

    def settings(self):
        from qgis.PyQt.QtCore import QSettings
        return QSettings()

    def prefix(self):
        return 'lmsnrm_updates/'+self.folder.name+'/'

    def configure(self):
        from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QLabel,QCheckBox,QDialogButtonBox
        dialog = QDialog(self.iface.mainWindow())
        dialog.setWindowTitle('Pluginupdates')
        layout = QVBoxLayout(dialog)
        label = QLabel('Controleer direct op een nieuwe pluginversie. Geen login nodig.\nUpdates worden bij de volgende QGIS-start geïnstalleerd.')
        label.setWordWrap(True)
        layout.addWidget(label)
        settings = self.settings()
        automatic = QCheckBox('Automatisch controleren en bij de volgende start bijwerken')
        automatic.setChecked(settings.value(self.prefix()+'automatic', True, type=bool))
        layout.addWidget(automatic)
        owner = getattr(QDialogButtonBox,'StandardButton',QDialogButtonBox)
        buttons = QDialogButtonBox(owner.Ok | owner.Cancel)
        buttons.button(owner.Ok).setText('Nu controleren en updaten')
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        result = dialog.exec() if hasattr(dialog,'exec') else dialog.exec_()
        if result == 1:
            settings.setValue(self.prefix()+'automatic',automatic.isChecked())
            self.check(manual=True)

    def check(self, manual=False):
        from qgis.core import QgsTask,QgsApplication,Qgis
        from qgis.PyQt.QtWidgets import QMessageBox
        settings = self.settings()
        authcfg = ''
        if self.task:
            if manual:QMessageBox.information(self.iface.mainWindow(),'Updates','Er loopt al een updatecontrole.')
            return
        if not manual and not settings.value(self.prefix()+'automatic',True,type=bool):
            return
        if not manual and time.time()-float(settings.value(self.prefix()+'last_check',0) or 0)<86400:
            return
        folder, state = self.folder, state_dir(self.folder.name)
        installed = metadata(folder)['version']
        def work(task):
            manifest = json.loads(fetch(MANIFEST_URL,authcfg,'application/json'))
            if manifest.get('schema_version') != 1:
                raise ValueError('Onbekende updateversielijst.')
            info = manifest['plugins'].get(folder.name)
            if not info or version_tuple(info['version']) <= version_tuple(installed):
                return None
            qgis_version = re.match(r'\d+\.\d+(?:\.\d+)?',Qgis.QGIS_VERSION).group()
            if not version_tuple(info['qgis_minimum']) <= version_tuple(qgis_version) <= version_tuple(info['qgis_maximum']):
                raise ValueError('De nieuwe versie ondersteunt deze QGIS-versie niet.')
            data = fetch(info['asset_api_url'],authcfg,'application/octet-stream')
            if task.isCanceled():
                return None
            stage = state/'download.zip'
            try:
                stage.write_bytes(data)
                verify_archive(stage,folder.name,info['version'],info['sha256'])
                os.replace(stage,state/'pending.zip')
                (state/'pending.json.tmp').write_text(json.dumps(info))
                os.replace(state/'pending.json.tmp',state/'pending.json')
            finally:
                if stage.exists():stage.unlink()
            return info['version']
        def finished(exception,result=None):
            self.task = None
            if exception:
                if manual:QMessageBox.warning(self.iface.mainWindow(),'Updates',str(exception))
                return
            settings.setValue(self.prefix()+'last_check',time.time())
            if result:
                self.iface.messageBar().pushMessage('Pluginupdate',f'Versie {result} staat klaar en wordt bij de volgende QGIS-start geïnstalleerd.',level=Qgis.Info,duration=15)
            elif manual:
                QMessageBox.information(self.iface.mainWindow(),'Updates','Deze plugin is bijgewerkt naar de nieuwste aangeboden versie.')
        self.task = QgsTask.fromFunction('Private pluginupdate controleren',work,on_finished=finished)
        QgsApplication.taskManager().addTask(self.task)

    def unload(self):
        self.timer.stop()
        if self.task:self.task.cancel()
