# LMSNRM Toolbar — handleiding

LMSNRM Toolbar is een QGIS-plugin voor het laden, verrijken, vergelijken en visualiseren van LMS- en NRM-wegennetwerken. Je werkt met lagen in je QGIS-project. De plugin maakt onder meer GeoPackages, attribuutkaarten, resultaatkaarten en verschilnetwerken.

## Installeren en starten

Gebruik QGIS 3.28 of hoger binnen de ondersteunde versiereeks 3.28–4.99. Open **Plugins → Plugins beheren en installeren → Installeren vanuit ZIP**, kies de installatie-ZIP en installeer de plugin. Schakel **LMSNRM Toolbar** in. Is de toolbar verborgen, zet hem aan via **Beeld → Werkbalken → LMSNRM Toolbar**. Herstart QGIS als de toolbar na installatie niet verschijnt.

De gedeelde installatie-ZIP staat in `P:\wvl\Toepassingen_NRM_En_LMS\Diverse scripts\LMSNRM toolbar plugin QGIS`. De publieke installatiebestanden staan ook op [GitHub](https://github.com/SRMulder/lmsnrm-qgis-updates). Voor downloaden en controleren op updates is geen GitHub-login nodig.

## Beginnen met een netwerk

Open een eigen shapefile of GeoPackage met de normale QGIS-functies, of gebruik een importactie onder **Netwerken**. Klik daarna op de gewenste netwerklaag in het lagenpaneel. Deze actieve laag bepaalt op welk netwerk een actie wordt uitgevoerd. Selecteer de bronlaag, niet een losse kleurklasse.

Een invoernetwerk bevat de wegen en modelkenmerken. Een geladen netwerk bevat daarnaast verkeersresultaten. Een verschilnetwerk bevat de vergelijking tussen twee netwerken. Een visualisatie is een groep gefilterde lagen die dezelfde brongegevens tonen; de bronwaarden worden hierdoor niet aangepast.

## Menu’s

- **Netwerken:** bibliotheeknetwerk laden, invoer- of geladen netwerk uit GMZIP halen, .NET-attributen koppelen en verschilnetwerk maken.
- **Attributen:** Eigenschappen, Resultaten, Verschilnetwerk en Visualisatielagen verwijderen.
- **Afslagverboden:** .PEN koppelen aan de actieve netwerklaag en de gemaakte afslagverbodlagen verwijderen.
- **Projecten:** projecten kiezen en projectlagen verwijderen.
- **Extra data:** Zones 2022 en INWEVA 2025.
- **Kaart:** kaart uitlijnen met OpenStreetMap, updates controleren, datamap kiezen en deze handleiding openen.

Projecten, Extra data en de netwerkbibliotheek zijn alleen zichtbaar wanneer hun bestanden bereikbaar zijn. Ook een afzonderlijk landsdeel wordt verborgen als zijn GeoPackage ontbreekt. De plugin controleert de bereikbaarheid tijdens gebruik. Zonder interne data blijven netwerkimport, koppelen van eigen bestanden, vergelijken en visualiseren beschikbaar.

## Interne gegevens en locaties

De standaarddatamap is:

`P:\wvl\Toepassingen_NRM_En_LMS\Diverse scripts\LMSNRM toolbar plugin QGIS\PluginData`

Deze map bevat `zones_2022.gpkg`, `inweva_2025.gpkg`, `projects_rp2026.json` en de map `RP2025 v2026`. Onder `RP2025 v2026` staan de landsdelen `LMS`, `Noord`, `Oost`, `West` en `Zuid`, met per landsdeel het GeoPackage en een QGIS-project. De toolbar leest de netwerklagen uit het GeoPackage; hij hoeft het meegeleverde project niet te openen.

Via **Kaart → Datamap kiezen…** kun je een andere PluginData-map instellen. De gedeelde standaardmap krijgt voorrang wanneer deze bereikbaar is. De gekozen datamap wordt gebruikt als de standaardmap niet beschikbaar is. Bewaar interne data op de netwerkschijf; ze zitten niet in de publieke plugin-ZIP.

## Netwerken: RP2025 v2026

Kies **Netwerken → RP2025 v2026 → landsdeel**. Kies het zichtjaar en dagdeel en klik op **Netwerk laden**. Alleen beschikbare jaren en dagdelen worden aangeboden. De GeoPackage-lagen heten `netwerk_<jaar>_RD`, `netwerk_<jaar>_OC` en `netwerk_<jaar>_AV`.

RD is restdag, OC is ochtendspits en AV is avondspits. Bij geladen-netwerkresultaten worden de spitsen ook OS en AS genoemd. De geladen bibliotheeklaag is een kaal netwerk: kies daarna zelf een kaart onder Attributen.

## Netwerken: invoernetwerk uit GMZIP

Kies **Netwerken → Invoernetwerk uit GMZIP halen…**, selecteer de GMZIP en kies de locatie van het uitvoer-GeoPackage. De plugin zoekt naar een `.shp` in de map `Input`, ongeacht de netwerknaam. De bijbehorende `.dbf` en `.shx` zijn vereist. Een aanwezige `.prj` en `.cpg` worden meegenomen. Bij meerdere shapes in Input is de keuze niet eenduidig en wordt de import gestopt met een melding.

Alleen de bestanden van deze shape worden tijdelijk gekopieerd. De volledige GMZIP wordt niet uitgepakt. De uitvoer bevat de laag `invoernetwerk`, de bronattributen, A/B-knoopvelden en een ruimtelijke index. Deze import heeft geen toedelingsresultaten nodig. Bij annuleren of een fout wordt het uitvoerbestand niet vervangen.

## Netwerken: geladen netwerk uit GMZIP

Kies **Netwerken → Maak geladen netwerk vanuit GMZIP…**. Kies de bron-ZIP en het uitvoerbestand in het importvenster. De plugin leest de netwerkshape en de bijbehorende QBlok-resultaten en maakt een GeoPackage met verkeersgegevens per dagdeel. De bronvariant en het dagdeel zijn herkenbaar in de laagnamen.

Gebruik een laag met alle dagdelen voor een vergelijking van alle dagdelen. Voor een kaart van één periode kun je de overeenkomstige dagdeellaag gebruiken. Ontbrekende of niet-eenduidige benodigde bestanden geven een melding. Het installeren van de plugin voegt geen verkeersresultaten toe aan een bestaand GeoPackage; importeer de GMZIP wanneer die gegevens nodig zijn.

## Netwerken: .NET-attributen koppelen

Selecteer de gewenste netwerklaag en kies **Netwerken → .NET-attributen koppelen…**. Selecteer het CUBE .NET-bestand en volg de veldkeuze in het venster. De koppeling gebruikt het gerichte knooppaar A → B, met A/B of KnoopA/KnoopB uit het netwerk. Gebruik bestanden van hetzelfde landsdeel, zichtjaar en dagdeel.

De A/B-volgorde is van belang: B → A is een andere gerichte link. WVK_ID is niet de sleutel voor deze koppeling. Controleer het gemelde aantal matches en de velden in de uitvoerlaag. Een bestand van een andere variant kan afwijkende of ontbrekende knoopparen bevatten.

## Netwerken: verschilnetwerk maken

Kies **Netwerken → Verschilnetwerk maken…**. Kies bij beide netwerken een geopende laag in het QGIS-project of een bestand vanaf schijf. Bij een bestand met meerdere lagen kies je ook de laag. De keuzelijst vermeldt de laag, groep en bron om varianten met dezelfde dagdeelnamen te onderscheiden.

**Netwerk 1 is de variant/nieuwe situatie. Netwerk 2 is de referentie/oude situatie. Uitkomst = netwerk 1 − netwerk 2.** Kies de uitvoerlocatie en maak het verschilnetwerk. Vergelijk dezelfde eenheden en dagdelen; voor alle dagdelen kies je bij beide netwerken de volledige laag.

Links die alleen in één netwerk voorkomen behouden hun eigen geometrie. Hun verschilwaarden worden vergeleken met nul en zijn geen meting van dezelfde link voor en na. Bekijk daarom ook **Attributen → Verschilnetwerk → Netwerkveranderingen / koppeling**. `D_`-velden bevatten verschillen; `N1_` en `N2_` de oorspronkelijke waarden.

## Attributen: Eigenschappen

Selecteer een invoer- of geladen netwerk en kies een eigenschap. De plugin maakt een groep met kleurklassen onder de bronlaag. Een keuze is grijs wanneer de geselecteerde laag de benodigde velden niet heeft.

De kaarten omvatten linktypes, wettelijke en nachtelijke snelheid, rijstroken en effectieve rijstroken, capaciteit, modelsnelheid, speciale stroken, weefvakken, wegsoort, gebiedscode, signalering, hoofdwegennet, doelgroepstrook, wegbeheerder, tol, vrachtwagenheffing, kilometerheffing, autoluw, grensovergang, openstellingsjaar, provincie en rijrichting. Beschikbaarheid hangt af van de bronvelden.

Rijstroken en effectieve rijstroken gebruiken verschillende modelvelden. Capaciteit 99999 wordt als onbegrensde modelcapaciteit weergegeven. Modelsnelheid is de vrije/modelmatige snelheid; gereden snelheid bij congestie staat onder Resultaten.

Bij moederbestanden zijn H/T de heen- en terugattributen ten opzichte van de vastgelegde linkrichting. De kaart Rijrichting gebruikt H_SEL/T_SEL. Gerichte CUBE-exports kunnen deze selectievelden missen; de plugin meldt dat. Leid H/T niet af uit noord, zuid, links of rechts op de kaart.

## Attributen: Resultaten

Selecteer een geladen netwerk. Beschikbare kaarten omvatten intensiteit motorvoertuigen en pae, IC-verhouding, gereden snelheid, snelheidsverlies, extra reistijd, wachttijd, VVU100, aangeboden belasting, wachtrij, onafgewikkelde stroom, fileduur, vrachtaandeel en L1/L2/L3-intensiteiten. Gebruik de dagdeel- of etmaallaag passend bij de vraag.

IC gebruikt QBB / FLCPW. Aangeboden belasting gebruikt FLOW / FLCPW. Snelheidsverlies is max(0, vrije snelheid − gereden snelheid). Extra reistijd is max(0, totale reistijd − vrije reistijd), in seconden per link. Vrachtaandeel gebruikt (FRGT2 + FRGT3) / VTG × 100 en sluit bestelverkeer uit. Bij een nulnoemer ontbreekt de afgeleide waarde; dat is geen gemeten nul.

Bekijk de legenda voor de eenheid en klassegrenzen. Etmaalintensiteiten hebben andere grenzen dan dagdeelwaarden. De hoogste IC-knelpuntklassen worden boven de lagere klassen getekend. De kaartstijl is een hulpmiddel voor analyse; de legenda bepaalt de interpretatie.

## Attributen: Verschilnetwerk

Selecteer een gemaakt verschilnetwerk en kies de gewenste verschilkaart. Naast intensiteit, IC en VVU100 zijn onder meer snelheid, reistijd, wachttijd, snelheidsverlies, aangeboden belasting, fileduur, vrachtaandeel, L1/L2/L3 en wachtrij beschikbaar wanneer de benodigde velden aanwezig zijn.

Blauw betekent bij de meeste verschilkaarten afname, rood toename en grijs rond nul. Rode/oranje klassen worden boven blauwe klassen getekend. Bij gereden snelheid is een afname rood en een toename groen. Een verschil in vrachtaandeel wordt weergegeven in procentpunten. Positief en negatief betekenen altijd netwerk 1 − netwerk 2; de betekenis van de kleur hangt af van de gekozen indicator.

Met **Attributen → Visualisatielagen verwijderen…** verwijder je de gemaakte attribuut- en resultaatvisualisaties van de actieve bron. De brongegevens blijven behouden.

## Afslagverboden

Selecteer de netwerklaag en kies **Afslagverboden → .PEN koppelen aan actieve shape…**. Kies het bijbehorende CUBE .PEN-bestand. De koppeling gebruikt drie opeenvolgende knopen om de afslag in het netwerk te vinden. Gebruik het netwerk waarvoor het PEN-bestand is gemaakt en controleer het gemelde aantal gekoppelde afslagbewegingen.

De gemaakte lagen tonen de afslagbewegingen en bijbehorende beperkingen/penalties. Gebruik de legenda en attributen om de betekenis van een penalty te beoordelen. **Lagen verwijderen** verwijdert de afslagverbodlagen van de plugin.

## Projecten

Selecteer een netwerk met een projectveld en kies **Projecten → Projecten kiezen…**. De projectenlijst uit PluginData geeft namen en informatie bij de projectcodes. Kies de gewenste projecten om gefilterde projectlagen te maken. **Projectlagen verwijderen** verwijdert deze lagen.

Het menu wordt alleen getoond als `projects_rp2026.json` bereikbaar is. Niet elk netwerk bevat projectcodes; controleer de bronlaag wanneer de selectie leeg is.

## Extra data: Zones 2022

Kies het gewenste landsdeel onder **Extra data → Zones 2022** om de beschikbare zonekaart uit `zones_2022.gpkg` toe te voegen. Met **Lagen verwijderen** verwijder je de zonekaarten die de plugin heeft toegevoegd.

## Extra data: INWEVA 2025

Kies een beschikbare INWEVA-kaart onder **Extra data → INWEVA 2025**. De kaarten komen uit `inweva_2025.gpkg` en bevatten de INWEVA-verkeersgegevens voor de aangeboden periodes.

**Koppelen met netwerk (bèta)…** koppelt een gekozen invoer- of geladen netwerk aan een INWEVA-laag. Gebruik bij voorkeur WVK_ID. Dat ID wordt gezocht in alle IDs van WVK_IDS, niet alleen het eerste. VBN_ID, LINK_ID, SEGMENT_ID en knoopnummers zijn andere sleutels. De plugin controleert de geometrische richting en afstand en verwerkt verschillen in coördinatenstelsel.

De koppellaag behoudt de modellinkgeometrie en krijgt de gegevens van één gekozen INWEVA-segment. Links zonder passende match worden niet opgenomen. Korte INWEVA-segmenten worden niet automatisch tot een volledige modellinkketen samengevoegd; intensiteiten worden niet opgeteld of gemiddeld.

- `INW_koppeling`: `segment` bij minder dan 90% geometrische dekking, anders `dekking_geometrie`.
- `INW_dekking_pct`: het percentage modellengte binnen ongeveer 10 meter van het gekozen INWEVA-segment. Dit is geen betrouwbaarheidspercentage voor verkeerswaarden.
- `INW_kandidaten`: het aantal INWEVA-features dat hetzelfde ID vermeldt. Bij meerdere kandidaten kiest de plugin op geometrische richting, span en afstand.

Een volledige geometrische dekking bewijst niet dat de verkeerswaarden representatief zijn voor de hele modellink. Controleer gedeeltelijke en meervoudige matches op de kaart en in de attributentabel. De koppeling blijft bèta.

**Alle 5 splitsen op actieve netwerklaag…** maakt de vijf beschikbare INWEVA-uitvoerlagen op basis van de overeenkomende IDs van het actieve netwerk, met netwerkgeometrie, WVK_ID, KnoopA/KnoopB en de INWEVA-attributen. Ook deze uitvoer is geen automatische ketensamenvoeging. **Lagen verwijderen** verwijdert de INWEVA-lagen van de plugin.

## Kaart en opslaan

**Kaart → Kaart uitlijnen met OpenStreetMap** stemt de projectweergave af op de OpenStreetMap-achtergrond en herstelt geselecteerde RD-lagen waar van toepassing. De actie vervangt geen netwerkbestand. Gebruik hem wanneer de achtergrond en netwerklaag niet goed over elkaar liggen; controleer ook het broncoördinatenstelsel.

Sla je QGIS-project op als `.qgz`. GeoPackage-uitvoer staat op de gekozen schijflocatie. Geheugenlagen, zoals koppellagen, zijn tijdelijk: exporteer ze via **Rechtsklik op de laag → Exporteren → Objecten opslaan als…**, bijvoorbeeld naar GeoPackage, als je de gegevens wilt bewaren. Een opgeslagen project alleen bewaart niet de objecten van een geheugenlaag.

## Updates

Open **Kaart → Updates instellen / controleren…** en klik op **Nu controleren en updaten**. Dit controleert direct, ook als automatisch controleren uitstaat. Met de automatische optie controleert de plugin dagelijks op een nieuwere ondersteunde versie. Daarvoor is internet nodig, geen login of token.

De plugin downloadt de update en controleert het installatiebestand. De nieuwe versie wordt bij de volgende QGIS-start geïnstalleerd. Sla je werk op en sluit QGIS om de update toe te passen. De interne netwerk- en presetdata worden niet via GitHub bijgewerkt.

## Veelvoorkomende vragen

**Een menu ontbreekt.** Controleer de verbinding met de P-schijf en de benodigde bestanden in PluginData. Wacht kort op de bereikbaarheidscontrole of open Netwerken opnieuw. Stel zo nodig een bereikbare map in via Kaart → Datamap kiezen.

**Een attribuutkaart is grijs.** Selecteer de juiste netwerkbronlaag. Controleer of het benodigde veld bestaat en of je een invoer-, geladen of verschilnetwerk gebruikt.

**Een koppeling vindt weinig matches.** Controleer landsdeel, variant, zichtjaar, dagdeel en de juiste sleutel. .NET gebruikt A/B, INWEVA gebruikt WVK_ID/WVK_IDS en .PEN gebruikt drie knopen. Verschillende netwerkindelingen kunnen onvolledige koppelingen geven.

**Een GMZIP-import stopt.** Lees de melding over ontbrekende of meerdere bestanden. Zorg dat SHP, DBF en SHX samen in Input staan en kies voor een geladen netwerk een ZIP met de benodigde verkeersresultaten.

**De kaart ligt verkeerd.** Controleer het coördinatenstelsel van de bronlaag en gebruik Kaart uitlijnen met OpenStreetMap. Ken een ontbrekend coördinatenstelsel alleen toe wanneer je de werkelijke broncoördinaten kent.

**Updates zijn niet bereikbaar.** Controleer internettoegang tot GitHub en probeer Nu controleren en updaten opnieuw. De geïnstalleerde plugin blijft bruikbaar als de updatecontrole niet lukt.
