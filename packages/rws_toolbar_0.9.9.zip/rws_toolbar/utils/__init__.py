"""Shared utility helpers for the LMS/NRM toolbar plugin."""
