"""Compatibility helpers for QGIS 3 and QGIS 4 API enum locations."""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QToolButton,
)
from qgis.core import QgsSymbol


def enum_value(owner, enum_name, value_name):
    enum = getattr(owner, enum_name, None)
    if enum is not None and hasattr(enum, value_name):
        return getattr(enum, value_name)
    return getattr(owner, value_name)


QT_USER_ROLE = enum_value(Qt, "ItemDataRole", "UserRole")
QT_TOOL_BUTTON_TEXT_ONLY = enum_value(Qt, "ToolButtonStyle", "ToolButtonTextOnly")
QT_WINDOW_MODAL = enum_value(Qt, "WindowModality", "WindowModal")

PEN_SOLID_LINE = enum_value(Qt, "PenStyle", "SolidLine")
PEN_DASH_LINE = enum_value(Qt, "PenStyle", "DashLine")
PEN_DOT_LINE = enum_value(Qt, "PenStyle", "DotLine")

TOOL_BUTTON_INSTANT_POPUP = enum_value(QToolButton, "ToolButtonPopupMode", "InstantPopup")

VIEW_SELECT_ROWS = enum_value(QAbstractItemView, "SelectionBehavior", "SelectRows")
VIEW_EXTENDED_SELECTION = enum_value(QAbstractItemView, "SelectionMode", "ExtendedSelection")
VIEW_NO_EDIT_TRIGGERS = enum_value(QAbstractItemView, "EditTrigger", "NoEditTriggers")

HEADER_RESIZE_TO_CONTENTS = enum_value(QHeaderView, "ResizeMode", "ResizeToContents")
HEADER_STRETCH = enum_value(QHeaderView, "ResizeMode", "Stretch")

DIALOG_OK = enum_value(QDialogButtonBox, "StandardButton", "Ok")
DIALOG_CANCEL = enum_value(QDialogButtonBox, "StandardButton", "Cancel")
DIALOG_ACCEPTED = enum_value(QDialog, "DialogCode", "Accepted")

SYMBOL_MARKER = enum_value(QgsSymbol, "SymbolType", "Marker")


def exec_dialog(dialog):
    if hasattr(dialog, "exec"):
        return dialog.exec()
    return dialog.exec_()
