import csv
import json
import os
import re
import struct
import zipfile
from copy import deepcopy
from collections import Counter
from pathlib import Path

from qgis.PyQt.QtCore import QCoreApplication, QVariant, QSettings
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAction,
    QFileDialog,
    QInputDialog,
    QMessageBox,
    QMenu,
    QProgressDialog,
    QToolButton,
)
from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsFillSymbol,
    QgsField,
    QgsGeometry,
    QgsGeometryGeneratorSymbolLayer,
    QgsLayerTreeGroup,
    QgsLineSymbol,
    QgsMarkerSymbol,
    QgsPalLayerSettings,
    QgsRectangle,
    QgsMapLayer,
    QgsProject,
    QgsProviderRegistry,
    QgsProperty,
    QgsSingleSymbolRenderer,
    QgsSymbolLayer,
    QgsTextBufferSettings,
    QgsTextFormat,
    QgsUnitTypes,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    QgsWkbTypes,
)

from .dialogs import (
    DifferenceNetworkDialog,
    InwevaLinkDialog,
    ProjectSelectionDialog,
    RoundaboutReviewDialog,
)
from .loaded_visualisations import definitions as loaded_definitions, difference_definitions
from .dialogs.difference_network import network_label
from .services import (
    DifferenceNetworkCancelled,
    GmZipLoadnetCancelled,
    GmZipLoadnetError,
    RoundaboutCancelled,
    TurnPenaltyCancelled,
    create_difference_geopackage,
    build_loadnet_index,
    build_inweva_index,
    build_roundabout_layers,
    build_turn_penalty_layers,
    discover_gmzip,
    match_inweva_candidate,
    parse_pen_file,
    write_loaded_geopackage,
    ViewerPublicationError,
    prepare_package,
)
from .utils.qgis_compat import (
    DIALOG_ACCEPTED,
    PEN_DASH_LINE,
    PEN_DOT_LINE,
    PEN_SOLID_LINE,
    QT_TOOL_BUTTON_TEXT_ONLY,
    QT_WINDOW_MODAL,
    SYMBOL_MARKER,
    TOOL_BUTTON_INSTANT_POPUP,
    exec_dialog as _exec_dialog,
)


class RwsToolbarPlugin:
    """QGIS toolbar helpers for RWS network visualisation."""

    VISUALISATION_PROPERTY = "rws_toolbar/visualisation"
    PROJECT_PROPERTY = "rws_toolbar/projects"
    ZONE_PROPERTY = "rws_toolbar/zones_2022"
    ZONE_KEY_PROPERTY = "rws_toolbar/zone_key"
    INWEVA_PROPERTY = "rws_toolbar/inweva"
    INWEVA_KEY_PROPERTY = "rws_toolbar/inweva_key"
    INWEVA_LINK_PROPERTY = "rws_toolbar/inweva_link"
    INWEVA_SPLIT_PROPERTY = "rws_toolbar/inweva_split"
    TURN_PROPERTY = "rws_toolbar/turn_penalties"
    TURN_FILE_PROPERTY = "rws_toolbar/turn_penalty_file"
    ROUNDABOUT_PROPERTY = "rws_toolbar/roundabouts"
    SCRIPT_PROPERTY = "rws_toolbar/script"
    SOURCE_PROPERTY = "rws_toolbar/source_layer_id"
    TOOL_LABEL = "LMSNRM Toolbar"
    PLUGIN_MENU_NAME = "&LMSNRM Toolbar"
    PROJECT_GROUP_NAME = "Projecten"
    PROJECT_FIELD_NAMES = ["Project"]
    @property
    def PROJECT_LIST_PATH(self):
        return Path(QSettings().value("lmsnrm_toolbar/preset_data_path", r"P:\wvl\Toepassingen_NRM_En_LMS\ADHOC_NRM\RP2025\Autonetwerken\PluginData")) / "projects_rp2026.json"
    @property
    def ZONE_DATA_PATH(self):
        return Path(QSettings().value("lmsnrm_toolbar/preset_data_path", r"P:\wvl\Toepassingen_NRM_En_LMS\ADHOC_NRM\RP2025\Autonetwerken\PluginData")) / "zones_2022.gpkg"
    @property
    def INWEVA_DATA_PATH(self):
        return Path(QSettings().value("lmsnrm_toolbar/preset_data_path", r"P:\wvl\Toepassingen_NRM_En_LMS\ADHOC_NRM\RP2025\Autonetwerken\PluginData")) / "inweva_2025.gpkg"
    ATTRIBUTE_VISUALISATIONS = (
        "linktypes",
        "legal_speed",
        "night_speed",
        "lanes",
        "effective_lanes",
        "capacity",
        "model_speed",
        "special_lanes",
        "weave_lanes",
        "wegsoort",
        "area_code",
        "signal",
        "hwn",
        "doelstrook",
        "wegbeheerder",
        "tol",
        "vwh",
        "kmhef",
        "autoluw",
        "border",
        "year",
        "province",
        "direction",
    )
    LOADED_NETWORK_VISUALISATIONS = (
        "ic_ratio",
        "vehicle_flow", "pae_flow", "driven_speed", "speed_loss", "extra_time",
        "waiting_time", "vvu100_absolute", "class_l1", "class_l2", "class_l3",
        "offered_load", "file_duration", "freight_share",
        "queue", "unprocessed_flow",
        "ic_ratio_delta",
        "flow_delta",
        "vvu100_delta",
    )
    NET_KEY_FIELDS = ("A", "B")
    NET_IMPORT_FIELDS = (
        "DISTANCE",
        "NRM_TYPE",
        "WEGSOORT",
        "HWN",
        "GEB_C",
        "OS_SNEL_WET",
        "RD_SNEL_WET",
        "AS_SNEL_WET",
        "OS_TSVA",
        "RD_TSVA",
        "AS_TSVA",
        "OS_SPEED",
        "RD_SPEED",
        "AS_SPEED",
        "OS_LANES",
        "RD_LANES",
        "AS_LANES",
        "OS_CAP",
        "RD_CAP",
        "AS_CAP",
        "OS_FLCPW",
        "RD_FLCPW",
        "AS_FLCPW",
        "OS_FLOW",
        "RD_FLOW",
        "AS_FLOW",
        "OS_QBB",
        "RD_QBB",
        "AS_QBB",
        "OS_DRUK",
        "RD_DRUK",
        "AS_DRUK",
        "OS_NBB",
        "RD_NBB",
        "AS_NBB",
        "OS_FCST",
        "RD_FCST",
        "AS_FCST",
        "OS_WCST",
        "RD_WCST",
        "AS_WCST",
        "OS_DCST",
        "RD_DCST",
        "AS_DCST",
        "OS_TCST",
        "RD_TCST",
        "AS_TCST",
        "OS_TYPE",
        "RD_TYPE",
        "AS_TYPE",
        "OS_TOL",
        "RD_TOL",
        "AS_TOL",
        "OS_VWH",
        "RD_VWH",
        "AS_VWH",
        "OS_KMHEF",
        "RD_KMHEF",
        "AS_KMHEF",
        "OS_ALUW",
        "RD_ALUW",
        "AS_ALUW",
        "OS_NEK",
        "RD_NEK",
        "AS_NEK",
        "OS_NBBKM",
        "RD_NBBKM",
        "AS_NBBKM",
        "OS_VTG",
        "RD_VTG",
        "AS_VTG",
        "OS_IC",
        "RD_IC",
        "AS_IC",
        "OS_VVU100",
        "RD_VVU100",
        "AS_VVU100",
        "ET_VVU100",
        "OS_L1",
        "OS_L2",
        "OS_L3",
        "OS_L23",
        "OS_L123",
        "RD_L1",
        "RD_L2",
        "RD_L3",
        "RD_L23",
        "RD_L123",
        "AS_L1",
        "AS_L2",
        "AS_L3",
        "AS_L23",
        "AS_L123",
        "ET_L1",
        "ET_L2",
        "ET_L3",
        "ET_L23",
        "ET_L123",
        "OSP_L1",
        "OSP_L2",
        "OSP_L3",
        "OSP_L123",
        "RDP_L1",
        "RDP_L2",
        "RDP_L3",
        "RDP_L123",
        "ASP_L1",
        "ASP_L2",
        "ASP_L3",
        "ASP_L123",
        "KALIBSET",
        "TOETSSET",
    )
    CUBE_CSV_SUFFIX = "_links.csv"
    CUBE_SCHEMA_SUFFIX = "_links_schema.json"
    ZONES_2022 = {
        "lms": {
            "label": "LMS",
            "layer_name": "lms_zones",
            "zone_field": "LMS_2022",
        },
        "noord": {
            "label": "Noord",
            "layer_name": "noord_zones",
            "zone_field": "N_2022",
        },
        "oost": {
            "label": "Oost",
            "layer_name": "oost_zones",
            "zone_field": "O_2022",
        },
        "west": {
            "label": "West",
            "layer_name": "west_zones",
            "zone_field": "W_2022",
        },
        "zuid": {
            "label": "Zuid",
            "layer_name": "zuid_zones",
            "zone_field": "Z_2022",
        },
    }
    INWEVA_LAYERS = {
        "werkdag_uren": {
            "label": "Werkdag uren",
            "layer_name": "werkdag_uren",
        },
        "weekenddag": {
            "label": "Weekenddag",
            "layer_name": "weekenddag",
        },
        "weekdag_uren": {
            "label": "Weekdag uren",
            "layer_name": "weekdag_uren",
        },
        "weekdag": {
            "label": "Weekdag",
            "layer_name": "weekdag",
        },
        "werkdag": {
            "label": "Werkdag",
            "layer_name": "werkdag",
        },
    }
    PROJECT_COLORS = [
        "#d81b60",
        "#1e88e5",
        "#ffc107",
        "#43a047",
        "#8e24aa",
        "#f4511e",
        "#00acc1",
        "#6d4c41",
        "#3949ab",
        "#7cb342",
    ]

    VISUALISATIONS = {
        "linktypes": {
            "group_name": "Linktypes",
            "field_names": ["linktype", "NRM_TYPE"],
            "empty_message": "Er zijn geen waarden gevonden in het linktype-veld.",
            "categories": [
                {
                    "values": [1],
                    "label": "1 Autosnelweg",
                    "color": "#ff0000",
                    "width": 1.25,
                },
                {
                    "values": [2],
                    "label": "2 Autoweg",
                    "color": "#ff9900",
                    "width": 0.95,
                },
                {
                    "values": [3],
                    "label": "3 Gebiedsontsluitingsweg gesloten",
                    "color": "#004bff",
                    "width": 0.75,
                },
                {
                    "values": [4],
                    "label": "4 Gebiedsontsluitingsweg gemengd",
                    "color": "#9ffff7",
                    "width": 0.70,
                },
                {
                    "values": [5],
                    "label": "5 Erftoegangsweg",
                    "color": "#111111",
                    "width": 0.45,
                },
                {
                    "values": [6],
                    "label": "6 Stadsontsluitingsweg",
                    "color": "#00b050",
                    "width": 0.65,
                },
                {
                    "values": [7],
                    "label": "7 Wijkontsluitingsweg",
                    "color": "#7fffe9",
                    "width": 0.45,
                },
                {
                    "values": [8],
                    "label": "8 Veerpont",
                    "color": "#666666",
                    "width": 0.75,
                    "style": PEN_DASH_LINE,
                },
                {
                    "values": [99],
                    "label": "99 Voedingslink",
                    "color": "#9a9a9a",
                    "width": 0.40,
                    "style": PEN_DOT_LINE,
                },
            ],
            "fallback": {
                "label_template": "{value} Onbekend linktype",
                "color": "#777777",
                "width": 0.35,
                "style": PEN_DOT_LINE,
            },
        },
        "legal_speed": {
            "group_name": "Wettelijke snelheid",
            "field_names": [
                "H_Snel_wet",
                "H_SNEL_WET",
                "T_SNEL_WET",
                "SNEL_WET",
                "RD_SNEL_WET",
                "OS_SNEL_WET", "OC_SNEL_WET",
                "AS_SNEL_WET", "AV_SNEL_WET",
                "RD_SNELW",
                "OS_SNELW", "OC_SNELW",
                "AS_SNELW", "AV_SNELW",
            ],
            "field_groups": [
                {"label": "Heen", "field_names": ["H_Snel_wet", "H_SNEL_WET", "SNEL_WET"]},
                {"label": "Terug", "field_names": ["T_SNEL_WET"]},
                {"label": "RD", "field_names": ["RD_SNEL_WET", "RD_SNELW"]},
                {"label": "OS", "field_names": ["OS_SNEL_WET", "OC_SNEL_WET", "OS_SNELW", "OC_SNELW"]},
                {"label": "AS", "field_names": ["AS_SNEL_WET", "AV_SNEL_WET", "AS_SNELW", "AV_SNELW"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het wettelijke-snelheidsveld.",
            "categories": [
                {
                    "max": 30,
                    "max_inclusive": False,
                    "label": "<30 km/u",
                    "color": "#ff4bc0",
                    "width": 0.75,
                },
                {
                    "values": [30],
                    "label": "30 km/u",
                    "color": "#bdbdbd",
                    "width": 0.75,
                },
                {
                    "min": 30,
                    "max": 50,
                    "label": ">30 t/m 50 km/u",
                    "color": "#00e5ff",
                    "width": 0.75,
                },
                {
                    "min": 50,
                    "max": 60,
                    "label": ">50 t/m 60 km/u",
                    "color": "#ffff00",
                    "width": 0.75,
                },
                {
                    "min": 60,
                    "max": 70,
                    "label": ">60 t/m 70 km/u",
                    "color": "#00d733",
                    "width": 0.75,
                },
                {
                    "min": 70,
                    "max": 80,
                    "label": ">70 t/m 80 km/u",
                    "color": "#a7ff95",
                    "width": 0.75,
                },
                {
                    "min": 80,
                    "max": 90,
                    "label": ">80 t/m 90 km/u",
                    "color": "#004bff",
                    "width": 0.75,
                },
                {
                    "min": 90,
                    "max": 100,
                    "label": ">90 t/m 100 km/u",
                    "color": "#ff7f00",
                    "width": 0.85,
                },
                {
                    "min": 100,
                    "max": 120,
                    "label": ">100 t/m 120 km/u",
                    "color": "#c00050",
                    "width": 0.95,
                },
                {
                    "min": 120,
                    "label": ">120 km/u",
                    "color": "#000000",
                    "width": 1.05,
                },
            ],
        },
        "lanes": {
            "group_name": "Rijstroken",
            "field_names": [
                "H_Stroken",
                "H_STROKEN",
                "T_STROKEN",
                "H_Lanes",
                "H_LANES",
                "T_LANES",
                "RD_LANES",
                "OS_LANES", "OC_LANES",
                "AS_LANES", "AV_LANES",
            ],
            "field_groups": [
                {"label": "Heen", "field_names": ["H_Stroken", "H_STROKEN", "H_Lanes", "H_LANES"]},
                {"label": "Terug", "field_names": ["T_STROKEN", "T_LANES"]},
                {"label": "RD", "field_names": ["RD_LANES"]},
                {"label": "OS", "field_names": ["OS_LANES", "OC_LANES"]},
                {"label": "AS", "field_names": ["AS_LANES", "AV_LANES"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het rijstrokenveld.",
            "categories": [
                {"values": [0], "label": "0 rijstroken", "color": "#bdbdbd", "width": 0.35},
                {
                    "values": [1],
                    "label": "1 rijstrook",
                    "color": "#315d99",
                    "width": 0.50,
                },
                {
                    "values": [2],
                    "label": "2 rijstroken",
                    "color": "#12c7d8",
                    "width": 0.75,
                },
                {
                    "values": [3],
                    "label": "3 rijstroken",
                    "color": "#ff9800",
                    "width": 1.00,
                },
                {
                    "values": [4],
                    "label": "4 rijstroken",
                    "color": "#a85d00",
                    "width": 1.25,
                },
                {
                    "values": [5],
                    "label": "5 rijstroken",
                    "color": "#d40050",
                    "width": 1.50,
                },
                {
                    "values": [6],
                    "label": "6 rijstroken",
                    "color": "#bf00ff",
                    "width": 1.75,
                },
                {"values": [7], "label": "7 rijstroken", "color": "#6a3d9a", "width": 1.90},
                {"values": [8], "label": "8 rijstroken", "color": "#42145f", "width": 2.05},
            ],
            "fallback": {"label_template": "{value} Rijstrookwaarde (controleer bron)", "color": "#777777", "width": 0.65, "style": PEN_DOT_LINE},
        },
        "model_speed": {
            "group_name": "Model snelheid",
            "field_names": [
                "H_Snel_mod",
                "H_SNEL_MOD",
                "T_SNEL_MOD",
                "ModSpeed",
                "MODSPEED",
                "SNEL_MOD",
                "RD_TSVA",
                "OS_TSVA", "OC_TSVA",
                "AS_TSVA", "AV_TSVA",
            ],
            "field_groups": [
                {"label": "Heen", "field_names": ["H_Snel_mod", "H_SNEL_MOD", "ModSpeed", "MODSPEED", "SNEL_MOD"]},
                {"label": "Terug", "field_names": ["T_SNEL_MOD"]},
                {"label": "RD", "field_names": ["RD_TSVA"]},
                {"label": "OS", "field_names": ["OS_TSVA", "OC_TSVA"]},
                {"label": "AS", "field_names": ["AS_TSVA", "AV_TSVA"]},
            ],
            "fallback": {"label_template": "{value} km/u (buiten standaardklassen)", "color": "#777777", "width": 0.75},
            "empty_message": "Er zijn geen waarden gevonden in het model-snelheidsveld.",
            "categories": [
                {
                    "values": [0],
                    "label": "0",
                    "color": "#d9d9d9",
                    "width": 0.55,
                },
                {
                    "min": 0,
                    "max": 3,
                    "label": ">0 t/m 3 km/u",
                    "color": "#1f77b4",
                    "width": 0.65,
                },
                {
                    "min": 3,
                    "max": 11,
                    "label": ">3 t/m 11 km/u",
                    "color": "#a7e88a",
                    "width": 0.70,
                },
                {
                    "min": 11,
                    "max": 20,
                    "label": ">11 t/m 20 km/u",
                    "color": "#2ca02c",
                    "width": 0.70,
                },
                {
                    "min": 20,
                    "max": 35,
                    "label": ">20 t/m 35 km/u",
                    "color": "#ff9896",
                    "width": 0.75,
                },
                {
                    "min": 35,
                    "max": 40,
                    "label": ">35 t/m 40 km/u",
                    "color": "#e31a1c",
                    "width": 0.80,
                },
                {
                    "min": 40,
                    "max": 50,
                    "label": ">40 t/m 50 km/u",
                    "color": "#fff2a8",
                    "width": 0.85,
                },
                {
                    "min": 50,
                    "max": 60,
                    "label": ">50 t/m 60 km/u",
                    "color": "#ff7f00",
                    "width": 0.90,
                },
                {
                    "min": 60,
                    "max": 70,
                    "label": ">60 t/m 70 km/u",
                    "color": "#cab2d6",
                    "width": 0.95,
                },
                {
                    "min": 70,
                    "max": 80,
                    "label": ">70 t/m 80 km/u",
                    "color": "#6a3d9a",
                    "width": 1.00,
                },
                {
                    "min": 80,
                    "max": 90,
                    "label": ">80 t/m 90 km/u",
                    "color": "#ffff99",
                    "width": 1.05,
                },
                {
                    "min": 90,
                    "max": 100,
                    "label": ">90 t/m 100 km/u",
                    "color": "#a65628",
                    "width": 1.10,
                },
                {"min": 100, "max": 120, "label": ">100 t/m 120 km/u", "color": "#c00050", "width": 1.15},
                {"min": 120, "label": ">120 km/u", "color": "#111111", "width": 1.25},
            ],
        },
        "night_speed": {
            "group_name": "Nachtelijke snelheid",
            "field_names": ["NCHT_SN", "Nacht_Snelheid"],
            "empty_message": "Er zijn geen waarden gevonden in het nachtelijke-snelheidsveld.",
            "categories": [
                {"values": [0], "label": "0 km/u", "color": "#d9d9d9", "width": 0.55},
                {"min": 0, "max": 30, "max_inclusive": False, "label": ">0 en <30 km/u", "color": "#ff4bc0", "width": 0.75},
                {"values": [30], "label": "30 km/u", "color": "#bdbdbd", "width": 0.75},
                {"min": 30, "max": 50, "label": ">30 t/m 50 km/u", "color": "#00e5ff", "width": 0.75},
                {"min": 50, "max": 60, "label": ">50 t/m 60 km/u", "color": "#ffff00", "width": 0.75},
                {"min": 60, "max": 70, "label": ">60 t/m 70 km/u", "color": "#00d733", "width": 0.75},
                {"min": 70, "max": 80, "label": ">70 t/m 80 km/u", "color": "#a7ff95", "width": 0.75},
                {"min": 80, "max": 90, "label": ">80 t/m 90 km/u", "color": "#004bff", "width": 0.75},
                {"min": 90, "max": 100, "label": ">90 t/m 100 km/u", "color": "#ff7f00", "width": 0.85},
                {"min": 100, "max": 120, "label": ">100 t/m 120 km/u", "color": "#c00050", "width": 0.95},
                {"min": 120, "label": ">120 km/u", "color": "#000000", "width": 1.05},
            ],
        },
        "capacity": {
            "group_name": "Capaciteit",
            "field_names": ["H_CAP", "T_CAP", "RD_CAP", "OS_CAP", "OC_CAP", "AS_CAP", "AV_CAP"],
            "field_groups": [
                {"label": "Heen", "field_names": ["H_CAP", "H_Cap"]},
                {"label": "Terug", "field_names": ["T_CAP"]},
                {"label": "RD", "field_names": ["RD_CAP"]},
                {"label": "OS", "field_names": ["OS_CAP", "OC_CAP"]},
                {"label": "AS", "field_names": ["AS_CAP", "AV_CAP"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het capaciteitsveld.",
            "categories": [
                {"values": [0], "label": "0 pae/u", "color": "#bdbdbd", "width": 0.45},
                {"min": 0, "max": 1500, "label": "1 - 1.500 pae/u", "color": "#c7e9b4", "width": 0.55},
                {"min": 1500, "max": 3000, "label": "1.500 - 3.000 pae/u", "color": "#7fcdbb", "width": 0.70},
                {"min": 3000, "max": 5000, "label": "3.000 - 5.000 pae/u", "color": "#41b6c4", "width": 0.85},
                {"min": 5000, "max": 8000, "label": "5.000 - 8.000 pae/u", "color": "#2c7fb8", "width": 1.05},
                {"min": 8000, "max": 12000, "label": "8.000 - 12.000 pae/u", "color": "#253494", "width": 1.25},
                {"min": 12000, "max": 99999, "max_inclusive": False, "label": ">12.000 en <99.999 pae/u", "color": "#6a3d9a", "width": 1.45},
                {"values": [99999], "label": "99.999 Onbegrensde modelcapaciteit", "color": "#111111", "width": 1.00, "style": PEN_DOT_LINE},
            ],
        },
        "special_lanes": {
            "group_name": "Speciale stroken",
            "field_names": ["EX_STROOK", "EX_STROKEN", "Ex_Stroken"],
            "empty_message": "Er zijn geen waarden gevonden in het speciale-strokenveld.",
            "categories": [
                {"values": [0], "label": "0 Geen aanvullende stroken", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Spitsstrook", "color": "#f9e11e", "width": 1.00},
                {"values": [2], "label": "2 Plusstrook", "color": "#ff7f00", "width": 1.10},
                {"values": [3], "label": "3 Wisselstrook", "color": "#9d006b", "width": 1.20},
            ],
            "fallback": {"label_template": "{value} Onbekende speciale strook", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "weave_lanes": {
            "group_name": "Weefvak",
            "field_names": ["WEEFVAK", "WEEFVAKKEN", "Weefvakken", "WEEF"],
            "empty_message": "Er zijn geen waarden gevonden in het weefvakveld.",
            "categories": [
                {"values": [0], "label": "0 Geen weefvak", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Wel weefvak", "color": "#154273", "width": 1.15},
            ],
            "fallback": {"label_template": "{value} Onbekende weefvakwaarde", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "wegsoort": {
            "group_name": "Wegsoort",
            "field_names": ["WEGSOORT", "wegsoort"],
            "empty_message": "Er zijn geen waarden gevonden in het wegsoortveld.",
            "categories": [
                {"values": [0], "label": "0 Hoofdrijbaan", "color": "#154273", "width": 0.90},
                {"values": [1], "label": "1 Toe- of afrit", "color": "#f9e11e", "width": 0.95},
                {"values": [2], "label": "2 Verbindingsboog buiten", "color": "#00a6d6", "width": 0.85},
                {"values": [3], "label": "3 Verbindingsboog binnen", "color": "#007bc7", "width": 0.85},
                {"values": [4], "label": "4 Rangeerbaan", "color": "#ff7f00", "width": 0.85},
                {"values": [5], "label": "5 Vertragende elementen", "color": "#d52b1e", "width": 1.10},
                {"values": [6], "label": "6 Linksafverbinding", "color": "#9d006b", "width": 0.95},
                {"values": [7], "label": "7 Rechtdoorverbinding", "color": "#39870c", "width": 0.95},
                {"values": [8], "label": "8 Rechtsafverbinding", "color": "#42145f", "width": 0.95},
                {"values": [9], "label": "9 Buitenlands congestiegebied", "color": "#767676", "width": 0.80, "style": PEN_DASH_LINE},
            ],
            "fallback": {"label_template": "{value} Onbekende wegsoort", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "area_code": {
            "group_name": "Gebiedscode",
            "field_names": ["GEB_CODE", "geb_code", "GEB_C", "GEB_LMS", "GEB_NOORD", "GEB_OOST", "GEB_WEST", "GEB_ZUID", "GEB_NL"],
            "field_groups": [
                {"label": "LMS", "field_names": ["GEB_LMS"]},
                {"label": "Noord", "field_names": ["GEB_NOORD"]},
                {"label": "Oost", "field_names": ["GEB_OOST"]},
                {"label": "West", "field_names": ["GEB_WEST"]},
                {"label": "Zuid", "field_names": ["GEB_ZUID"]},
                {"label": "NL", "field_names": ["GEB_NL"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het gebiedscodeveld.",
            "categories": [
                {"values": [1], "label": "1 Studiegebied", "color": "#154273", "width": 1.05},
                {"values": [2], "label": "2 Invloedsgebied Nederland", "color": "#007bc7", "width": 0.90},
                {"values": [3], "label": "3 Buitengebied Nederland", "color": "#76d2b6", "width": 0.70},
                {"values": [4], "label": "4 Invloedsgebied buitenland", "color": "#f9e11e", "width": 0.70},
                {"values": [5], "label": "5 Buitengebied buitenland", "color": "#ffb612", "width": 0.70},
            ],
            "fallback": {"label_template": "{value} Onbekende gebiedscode", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "signal": {
            "group_name": "Signalering",
            "field_names": ["SIGNAL", "Signal"],
            "empty_message": "Er zijn geen waarden gevonden in het signaleringsveld.",
            "categories": [
                {"values": [0], "label": "0 Geen signalering", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Wel signalering", "color": "#154273", "width": 1.20},
            ],
            "fallback": {"label_template": "{value} Onbekende signalering", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "hwn": {
            "group_name": "Hoofdwegennet",
            "field_names": ["HWN"],
            "empty_message": "Er zijn geen waarden gevonden in het HWN-veld.",
            "categories": [
                {"values": [0], "label": "0 Geen HWN", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Wel HWN", "color": "#154273", "width": 1.25},
            ],
            "fallback": {"label_template": "{value} Onbekende HWN-waarde", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "doelstrook": {
            "group_name": "Doelgroepstrook",
            "field_names": ["DOELSTROOK", "Doelstrook", "DOEL"],
            "empty_message": "Er zijn geen waarden gevonden in het doelgroepstrookveld.",
            "categories": [
                {"values": [0], "label": "0 Alle verkeer", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Busstrook", "color": "#42145f", "width": 1.00},
                {"values": [2], "label": "2 Personenvervoerstrook", "color": "#007bc7", "width": 1.00},
                {"values": [3], "label": "3 Vrachtstrook", "color": "#a90061", "width": 1.00},
            ],
            "fallback": {"label_template": "{value} Onbekende doelgroepstrook", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "wegbeheerder": {
            "group_name": "Wegbeheerder",
            "field_names": ["WEGBEHSRT", "WegBehSrt"],
            "empty_message": "Er zijn geen waarden gevonden in het wegbeheerderveld.",
            "categories": [
                {"values": [1], "label": "1 Rijk", "color": "#154273", "width": 1.10},
                {"values": [2], "label": "2 Provincie", "color": "#007bc7", "width": 0.90},
                {"values": [3], "label": "3 Gemeente", "color": "#39870c", "width": 0.75},
                {"values": [4], "label": "4 Waterschap", "color": "#00a6d6", "width": 0.75},
                {"values": [5], "label": "5 Particulier", "color": "#ffb612", "width": 0.75},
                {"values": [6], "label": "6 Buitenland", "color": "#767676", "width": 0.70, "style": PEN_DASH_LINE},
            ],
            "fallback": {"label_template": "{value} Onbekende wegbeheerder", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "tol": {
            "group_name": "Tol",
            "field_names": ["TOL", "OS_TOL", "OC_TOL", "RD_TOL", "AS_TOL", "AV_TOL"],
            "field_groups": [
                {"label": "Basis", "field_names": ["TOL"]},
                {"label": "RD", "field_names": ["RD_TOL"]},
                {"label": "OS", "field_names": ["OS_TOL", "OC_TOL"]},
                {"label": "AS", "field_names": ["AS_TOL", "AV_TOL"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het tolveld.",
            "categories": [
                {"values": [0], "label": "0 Geen tol", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Westerscheldetunnel", "color": "#154273", "width": 1.10},
                {"values": [2], "label": "2 Liefkenshoektunnel", "color": "#007bc7", "width": 1.10},
                {"values": [3], "label": "3 Kiltunnel", "color": "#39870c", "width": 1.10},
                {"values": [4], "label": "4 Blankenburgtunnel", "color": "#ffb612", "width": 1.10},
                {"values": [5], "label": "5 ViA15", "color": "#d52b1e", "width": 1.10},
            ],
            "fallback": {"label_template": "{value} Onbekende tolcode", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "vwh": {
            "group_name": "Vrachtwagenheffing",
            "field_names": ["VWH", "OS_VWH", "OC_VWH", "RD_VWH", "AS_VWH", "AV_VWH"],
            "field_groups": [
                {"label": "Basis", "field_names": ["VWH"]},
                {"label": "RD", "field_names": ["RD_VWH"]},
                {"label": "OS", "field_names": ["OS_VWH", "OC_VWH"]},
                {"label": "AS", "field_names": ["AS_VWH", "AV_VWH"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het vrachtwagenheffingveld.",
            "categories": [
                {"values": [0], "label": "0 Geen vrachtwagenheffing", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Nederland", "color": "#154273", "width": 1.10},
                {"values": [11], "label": "11 Belgie Vlaanderen", "color": "#007bc7", "width": 1.00},
                {"values": [12], "label": "12 Belgie Brussel", "color": "#42145f", "width": 1.00},
                {"values": [13], "label": "13 Belgie Wallonie", "color": "#00a6d6", "width": 1.00},
                {"values": [14], "label": "14 Belgie Brussel snelweg", "color": "#76d2b6", "width": 1.00},
                {"values": [21], "label": "21 Duitsland", "color": "#ffb612", "width": 1.00},
            ],
            "fallback": {"label_template": "{value} Onbekende VWH-code", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "kmhef": {
            "group_name": "Kilometerheffing",
            "field_names": ["KMHEF", "OS_KMH", "OC_KMH", "RD_KMH", "AS_KMH", "AV_KMH"],
            "field_groups": [
                {"label": "Basis", "field_names": ["KMHEF"]},
                {"label": "RD", "field_names": ["RD_KMH"]},
                {"label": "OS", "field_names": ["OS_KMH", "OC_KMH"]},
                {"label": "AS", "field_names": ["AS_KMH", "AV_KMH"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in het kilometerheffingveld.",
            "categories": [
                {"values": [0], "label": "0 Geen kilometerheffing", "color": "#bdbdbd", "width": 0.45},
                {"min": 0, "max": 9, "label": "1 - 9 Nederland", "color": "#154273", "width": 1.00},
                {"min": 10, "max": 19, "label": "11 - 19 Belgie", "color": "#007bc7", "width": 1.00},
                {"min": 20, "max": 29, "label": "21 - 29 Duitsland", "color": "#ffb612", "width": 1.00},
            ],
            "fallback": {"label_template": "{value} Onbekende KMHEF-code", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "autoluw": {
            "group_name": "Autoluw",
            "field_names": ["ALUW"],
            "empty_message": "Er zijn geen waarden gevonden in het autoluwveld.",
            "categories": [
                {"values": [0], "label": "0 Geen autoluwe weg", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Autoluwe weg", "color": "#154273", "width": 1.10},
                {"min": 1, "max": 9, "label": "2 - 9 Kilometerbeprijzing NL", "color": "#007bc7", "width": 0.90},
                {"min": 10, "max": 19, "label": "11 - 19 Kilometerbeprijzing BE", "color": "#42145f", "width": 0.90},
                {"min": 20, "max": 29, "label": "21 - 29 Kilometerbeprijzing DE", "color": "#ffb612", "width": 0.90},
            ],
            "fallback": {"label_template": "{value} Onbekende ALUW-code", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "border": {
            "group_name": "Grensovergang",
            "field_names": ["GRENS", "Grens"],
            "empty_message": "Er zijn geen waarden gevonden in het grensovergangveld.",
            "categories": [
                {"values": [0], "label": "0 Geen grensovergang", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Wel grensovergang", "color": "#d52b1e", "width": 1.20},
            ],
            "fallback": {"label_template": "{value} Onbekende grenswaarde", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "year": {
            "group_name": "Openstellingsjaar",
            "field_names": ["JAAR", "Jaar"],
            "empty_message": "Er zijn geen waarden gevonden in het jaarveld.",
            "categories": [
                {"values": [2022], "label": "2022 basis", "color": "#bdbdbd", "width": 0.45},
                {"min": 2022, "max": 2030, "label": "2023 - 2030", "color": "#76d2b6", "width": 0.75},
                {"min": 2030, "max": 2040, "label": "2031 - 2040", "color": "#007bc7", "width": 0.90},
                {"min": 2040, "max": 2050, "label": "2041 - 2050", "color": "#154273", "width": 1.05},
                {"min": 2050, "label": "2051 en later", "color": "#42145f", "width": 1.10},
            ],
            "fallback": {"label_template": "{value} Onbekend jaar", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "province": {
            "group_name": "Provincie",
            "field_names": ["PRV_CODE", "prv_code"],
            "empty_message": "Er zijn geen waarden gevonden in het provincieveld.",
            "categories": [
                {"values": [20], "label": "20 Groningen", "color": "#154273", "width": 0.75},
                {"values": [21], "label": "21 Friesland", "color": "#007bc7", "width": 0.75},
                {"values": [22], "label": "22 Drenthe", "color": "#76d2b6", "width": 0.75},
                {"values": [23], "label": "23 Overijssel", "color": "#39870c", "width": 0.75},
                {"values": [24], "label": "24 Flevoland", "color": "#f9e11e", "width": 0.75},
                {"values": [25], "label": "25 Gelderland", "color": "#ffb612", "width": 0.75},
                {"values": [26], "label": "26 Utrecht", "color": "#ff7f00", "width": 0.75},
                {"values": [27], "label": "27 Noord-Holland", "color": "#d52b1e", "width": 0.75},
                {"values": [28], "label": "28 Zuid-Holland", "color": "#a90061", "width": 0.75},
                {"values": [29], "label": "29 Zeeland", "color": "#42145f", "width": 0.75},
                {"values": [30], "label": "30 Noord-Brabant", "color": "#00a6d6", "width": 0.75},
                {"values": [31], "label": "31 Limburg", "color": "#8fcae7", "width": 0.75},
                {"values": [51], "label": "51 Belgie", "color": "#767676", "width": 0.70, "style": PEN_DASH_LINE},
                {"values": [52], "label": "52 Duitsland", "color": "#535353", "width": 0.70, "style": PEN_DASH_LINE},
                {"values": [53], "label": "53 Luxemburg", "color": "#999999", "width": 0.70, "style": PEN_DASH_LINE},
                {"values": [54], "label": "54 Frankrijk", "color": "#bdbdbd", "width": 0.70, "style": PEN_DASH_LINE},
            ],
            "fallback": {"label_template": "{value} Onbekende provinciecode", "color": "#777777", "width": 0.45, "style": PEN_DOT_LINE},
        },
        "direction": {
            "group_name": "Rijrichting",
            "field_names": ["H_SEL", "T_SEL", "H_Sel"],
            "field_groups": [
                {"label": "Heen", "field_names": ["H_SEL", "H_Sel"]},
                {"label": "Terug", "field_names": ["T_SEL"]},
            ],
            "empty_message": "Er zijn geen waarden gevonden in de richtingselectievelden.",
            "categories": [
                {"values": [0], "label": "0 Niet actief", "color": "#bdbdbd", "width": 0.45},
                {"values": [1], "label": "1 Actief", "color": "#154273", "width": 1.10},
            ],
            "fallback": {"label_template": "{value} Richtingswaarde", "color": "#777777", "width": 0.65, "style": PEN_DOT_LINE},
        },
        "ic_ratio": {
            "group_name": "IC verhouding",
            "field_names": [
                "RD_IC",
                "OS_IC", "OC_IC",
                "AS_IC", "AV_IC",
                "N1_RD_IC",
                "N1_OS_IC",
                "N1_AS_IC",
                "N2_RD_IC",
                "N2_OS_IC",
                "N2_AS_IC",
            ],
            "field_groups": [
                {"label": "RD", "field_names": ["RD_IC"]},
                {"label": "OS", "field_names": ["OS_IC", "OC_IC"]},
                {"label": "AS", "field_names": ["AS_IC", "AV_IC"]},
                {"label": "Netwerk 1 RD", "field_names": ["N1_RD_IC"]},
                {"label": "Netwerk 1 OS", "field_names": ["N1_OS_IC"]},
                {"label": "Netwerk 1 AS", "field_names": ["N1_AS_IC"]},
                {"label": "Netwerk 2 RD", "field_names": ["N2_RD_IC"]},
                {"label": "Netwerk 2 OS", "field_names": ["N2_OS_IC"]},
                {"label": "Netwerk 2 AS", "field_names": ["N2_AS_IC"]},
            ],
            "symbol_defaults": {
                "unit": "map",
                "offset_multiplier": 0.55,
                "offset_extra": 3.0,
                "scale_factor_expression": (
                    "CASE "
                    "WHEN @map_scale <= 5000 THEN 1.35 "
                    "WHEN @map_scale <= 15000 THEN 1.45 "
                    "WHEN @map_scale <= 50000 THEN 1.90 "
                    "WHEN @map_scale <= 150000 THEN 2.80 "
                    "WHEN @map_scale <= 500000 THEN 4.20 "
                    "ELSE 5.50 "
                    "END"
                ),
            },
            "empty_message": "Er zijn geen waarden gevonden in de IC-velden.",
            "categories": [
                {
                    "values": [0],
                    "label": "IC 0,00",
                    "color": "#7f7f7f",
                    "width": 3.0,
                    "opacity": 0.58,
                    "scale_factor_expression": (
                        "CASE "
                        "WHEN @map_scale <= 15000 THEN 0.85 "
                        "WHEN @map_scale <= 50000 THEN 1.15 "
                        "WHEN @map_scale <= 150000 THEN 1.80 "
                        "WHEN @map_scale <= 500000 THEN 3.20 "
                        "ELSE 4.50 "
                        "END"
                    ),
                },
                {
                    "min": 0,
                    "max": 0.50,
                    "label": "IC 0,01 - 0,50",
                    "color": "#009e73",
                    "width": 5.0,
                    "opacity": 0.70,
                    "scale_factor_expression": (
                        "CASE "
                        "WHEN @map_scale <= 15000 THEN 1.00 "
                        "WHEN @map_scale <= 50000 THEN 1.15 "
                        "WHEN @map_scale <= 150000 THEN 1.45 "
                        "WHEN @map_scale <= 500000 THEN 1.90 "
                        "ELSE 2.40 "
                        "END"
                    ),
                },
                {
                    "min": 0.50,
                    "max": 0.70,
                    "label": "IC 0,50 - 0,70",
                    "color": "#91cf60",
                    "width": 10.0,
                    "opacity": 0.82,
                    "scale_factor_expression": (
                        "CASE "
                        "WHEN @map_scale <= 15000 THEN 1.10 "
                        "WHEN @map_scale <= 50000 THEN 1.30 "
                        "WHEN @map_scale <= 150000 THEN 1.80 "
                        "WHEN @map_scale <= 500000 THEN 2.50 "
                        "ELSE 3.30 "
                        "END"
                    ),
                },
                {
                    "min": 0.70,
                    "max": 0.80,
                    "label": "IC 0,70 - 0,80",
                    "color": "#f6d32d",
                    "width": 24.0,
                    "opacity": 0.95,
                },
                {
                    "min": 0.80,
                    "max": 0.90,
                    "label": "IC 0,80 - 0,90",
                    "color": "#f97316",
                    "width": 34.0,
                    "opacity": 1.0,
                },
                {
                    "min": 0.90,
                    "max": 1.00,
                    "max_inclusive": False,
                    "label": "IC 0,90 - 1,00",
                    "color": "#dc2626",
                    "width": 48.0,
                    "opacity": 1.0,
                },
                {
                    "min": 1.00,
                    "min_inclusive": True,
                    "label": "IC >= 1,00",
                    "color": "#9d006b",
                    "width": 64.0,
                    "opacity": 1.0,
                },
            ],
        },
        "ic_ratio_delta": {
            "group_name": "Verschil IC verhouding",
            "field_names": ["D_RD_IC", "D_OS_IC", "D_AS_IC"],
            "field_groups": [
                {"label": "RD", "field_names": ["D_RD_IC"]},
                {"label": "OS", "field_names": ["D_OS_IC"]},
                {"label": "AS", "field_names": ["D_AS_IC"]},
            ],
            "default_group_label": "RD",
            "symbol_defaults": {
                "unit": "map",
                "offset_multiplier": 0.55,
                "offset_extra": 3.0,
                "scale_factor_expression": (
                    "CASE "
                    "WHEN @map_scale <= 15000 THEN 1.30 "
                    "WHEN @map_scale <= 50000 THEN 1.70 "
                    "WHEN @map_scale <= 150000 THEN 2.40 "
                    "WHEN @map_scale <= 500000 THEN 3.40 "
                    "ELSE 4.40 "
                    "END"
                ),
            },
            "empty_message": "Er zijn geen verschilvelden voor IC verhouding gevonden. Maak eerst een verschilnetwerk met IC-velden.",
            "categories": [
                {"max": -0.20, "label": "IC verschil <= -0,20", "color": "#154273", "width": 28.0, "opacity": 0.95},
                {"min": -0.20, "max": -0.10, "label": "IC verschil -0,20 - -0,10", "color": "#007bc7", "width": 20.0, "opacity": 0.90},
                {"min": -0.10, "max": -0.02, "label": "IC verschil -0,10 - -0,02", "color": "#8fcae7", "width": 12.0, "opacity": 0.80},
                {"min": -0.02, "max": 0.02, "label": "IC verschil rond 0", "color": "#bdbdbd", "width": 4.0, "opacity": 0.55},
                {"min": 0.02, "max": 0.10, "label": "IC verschil +0,02 - +0,10", "color": "#f9e11e", "width": 12.0, "opacity": 0.90},
                {"min": 0.10, "max": 0.20, "label": "IC verschil +0,10 - +0,20", "color": "#ff7f00", "width": 20.0, "opacity": 0.95},
                {"min": 0.20, "label": "IC verschil > +0,20", "color": "#d52b1e", "width": 30.0, "opacity": 1.0},
            ],
        },
        "flow_delta": {
            "group_name": "Verschil intensiteit",
            "field_names": [
                "D_RD_FLOW",
                "D_OS_FLOW",
                "D_AS_FLOW",
                "D_ET_L123",
                "D_ET_VTG",
            ],
            "field_groups": [
                {"label": "RD", "field_names": ["D_RD_FLOW"]},
                {"label": "OS", "field_names": ["D_OS_FLOW"]},
                {"label": "AS", "field_names": ["D_AS_FLOW"]},
                {"label": "Etmaal", "field_names": ["D_ET_L123", "D_ET_VTG"]},
            ],
            "default_group_label": "Etmaal",
            "empty_message": "Er zijn geen verschilvelden voor intensiteit gevonden.",
            "categories": [
                {"max": -2500, "label": "<= -2.500", "color": "#154273", "width": 2.20},
                {"min": -2500, "max": -1000, "label": "-2.500 - -1.000", "color": "#007bc7", "width": 1.80},
                {"min": -1000, "max": -250, "label": "-1.000 - -250", "color": "#8fcae7", "width": 1.25},
                {"min": -250, "max": 250, "label": "rond 0", "color": "#bdbdbd", "width": 0.45, "opacity": 0.60},
                {"min": 250, "max": 1000, "label": "+250 - +1.000", "color": "#f9e11e", "width": 1.25},
                {"min": 1000, "max": 2500, "label": "+1.000 - +2.500", "color": "#ff7f00", "width": 1.80},
                {"min": 2500, "label": "> +2.500", "color": "#d52b1e", "width": 2.20},
            ],
        },
        "vvu100_delta": {
            "group_name": "Verschil VVU100",
            "field_names": ["D_RD_VVU100", "D_OS_VVU100", "D_AS_VVU100", "D_ET_VVU100"],
            "field_groups": [
                {"label": "RD", "field_names": ["D_RD_VVU100"]},
                {"label": "OS", "field_names": ["D_OS_VVU100"]},
                {"label": "AS", "field_names": ["D_AS_VVU100"]},
                {"label": "Etmaal", "field_names": ["D_ET_VVU100"]},
            ],
            "default_group_label": "Etmaal",
            "empty_message": "Er zijn geen verschilvelden voor VVU100 gevonden.",
            "categories": [
                {"max": -500, "label": "<= -500", "color": "#154273", "width": 2.00},
                {"min": -500, "max": -100, "label": "-500 - -100", "color": "#007bc7", "width": 1.50},
                {"min": -100, "max": -10, "label": "-100 - -10", "color": "#8fcae7", "width": 1.00},
                {"min": -10, "max": 10, "label": "rond 0", "color": "#bdbdbd", "width": 0.45, "opacity": 0.60},
                {"min": 10, "max": 100, "label": "+10 - +100", "color": "#f9e11e", "width": 1.00},
                {"min": 100, "max": 500, "label": "+100 - +500", "color": "#ff7f00", "width": 1.50},
                {"min": 500, "label": "> +500", "color": "#d52b1e", "width": 2.00},
            ],
        },
    }

    VISUALISATIONS.update(loaded_definitions())
    _DIFFERENCE_DEFINITIONS = difference_definitions()
    VISUALISATIONS.update(_DIFFERENCE_DEFINITIONS)
    LOADED_NETWORK_VISUALISATIONS += tuple(_DIFFERENCE_DEFINITIONS)
    VISUALISATIONS["flow_delta"]["group_name"] = "Verschil intensiteit pae"
    VISUALISATIONS["flow_delta"]["field_groups"] = VISUALISATIONS["flow_delta"]["field_groups"][:3]
    VISUALISATIONS["flow_delta"]["field_names"] = ["D_RD_FLOW", "D_OS_FLOW", "D_AS_FLOW"]

    # H_Stroken excludes special lanes; H_Lanes is the effective model value.
    VISUALISATIONS["effective_lanes"] = deepcopy(VISUALISATIONS["lanes"])
    VISUALISATIONS["effective_lanes"].update({
        "group_name": "Effectieve rijstroken",
        "field_names": ["H_LANES", "T_LANES", "RD_LANES", "OS_LANES", "OC_LANES", "AS_LANES", "AV_LANES"],
        "field_groups": [
            {"label": "Heen", "field_names": ["H_LANES"]},
            {"label": "Terug", "field_names": ["T_LANES"]},
            {"label": "RD", "field_names": ["RD_LANES"]},
            {"label": "OS", "field_names": ["OS_LANES", "OC_LANES"]},
            {"label": "AS", "field_names": ["AS_LANES", "AV_LANES"]},
        ],
    })

    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.tool_button = None
        self.toolbar_widget_action = None
        self.menu = None
        self.attribute_menu = None
        self.loaded_network_menu = None
        self.turn_menu = None
        self.zones_menu = None
        self.inweva_menu = None
        self.inweva_2025_menu = None
        self.map_menu = None
        self.scripts_menu = None
        self.project_menu = None
        self.visualisation_actions = {}
        self.zone_actions = {}
        self.inweva_actions = {}
        self.toolbar_buttons = []
        self.toolbar_widget_actions = []
        self.remove_attribute_layers_action = None
        self.remove_loaded_network_layers_action = None
        self.remove_turn_layers_action = None
        self.link_turn_penalty_action = None
        self.remove_zones_action = None
        self.remove_inweva_action = None
        self.link_inweva_action = None
        self.split_inweva_action = None
        self.align_osm_crs_action = None
        self.link_net_action = None
        self.detect_roundabouts_action = None
        self.review_roundabouts_action = None
        self.gmzip_loadnet_action = None
        self.difference_network_action = None
        self.choose_projects_action = None
        self.remove_projects_action = None
        self.publish_viewer_action = None
        self.project_catalog = None
        self.project_catalog_meta = {}
        self.network_actions = []

    def initGui(self):
        from .updates import UpdateManager
        self.updates = UpdateManager(self.iface, Path(__file__).resolve().parent)
        self.toolbar = self.iface.addToolBar(self.TOOL_LABEL)
        self.toolbar.setObjectName("LmsNrmToolbar")

        self.menu = QMenu(self.TOOL_LABEL, self.iface.mainWindow())
        network_menu = self.menu.addMenu("Netwerken")
        library_menu = network_menu.addMenu("RP2025 v2026")
        for region in ("Noord", "Oost", "West", "Zuid", "LMS"):
            action = QAction(region, self.iface.mainWindow())
            action.triggered.connect(lambda checked=False, region=region: self.choose_library_network(region))
            library_menu.addAction(action)
            self.network_actions.append(action)
            self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, action)
        input_action = QAction("Invoernetwerk uit GMZIP halen...", self.iface.mainWindow())
        input_action.triggered.connect(self.import_input_gmzip)
        network_menu.addAction(input_action)
        self.network_actions.append(input_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, input_action)
        attribute_root = self.menu.addMenu("Attributen")
        self.attribute_menu = attribute_root.addMenu("Eigenschappen")

        self.remove_attribute_layers_action = QAction("Lagen verwijderen", self.iface.mainWindow())
        self.remove_attribute_layers_action.setToolTip(
            "Verwijder de attribuutlagen voor de actieve netwerkshape."
        )
        self.remove_attribute_layers_action.triggered.connect(self.remove_attribute_layers)
        self.attribute_menu.addAction(self.remove_attribute_layers_action)
        self.attribute_menu.addSeparator()
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_attribute_layers_action)

        for visualisation_key in self.ATTRIBUTE_VISUALISATIONS:
            definition = self.VISUALISATIONS[visualisation_key]
            action = QAction(definition["group_name"], self.iface.mainWindow())
            action.setToolTip(
                f"Maak gefilterde lagen voor {definition['group_name'].lower()} onder de actieve netwerkshape."
            )
            action.triggered.connect(
                lambda checked=False, key=visualisation_key: self.create_visualisation_layers(key)
            )
            self.attribute_menu.addAction(action)
            self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, action)
            self.visualisation_actions[visualisation_key] = action

        self.loaded_network_menu = QMenu("Resultaten", self.iface.mainWindow())
        self.remove_loaded_network_layers_action = QAction("Lagen verwijderen", self.iface.mainWindow())
        self.remove_loaded_network_layers_action.setToolTip(
            "Verwijder de geladen-netwerklagen voor de actieve netwerkshape."
        )
        self.remove_loaded_network_layers_action.triggered.connect(self.remove_loaded_network_layers)
        self.loaded_network_menu.addAction(self.remove_loaded_network_layers_action)
        self.loaded_network_menu.addSeparator()
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_loaded_network_layers_action)

        result_menu = attribute_root.addMenu("Resultaten")
        difference_menu = attribute_root.addMenu("Verschilnetwerk")
        for visualisation_key in self.LOADED_NETWORK_VISUALISATIONS:
            definition = self.VISUALISATIONS[visualisation_key]
            action = QAction(definition["group_name"], self.iface.mainWindow())
            action.setToolTip(
                f"Maak gefilterde lagen voor {definition['group_name'].lower()} onder de actieve netwerkshape."
            )
            action.triggered.connect(
                lambda checked=False, key=visualisation_key: self.create_visualisation_layers(key)
            )
            target_menu = difference_menu if visualisation_key.endswith("_delta") or definition.get("difference_result") else result_menu
            action.setToolTip(
                "Selecteer een verschilnetwerk. D_ is netwerk 1 min netwerk 2; N1_ en N2_ zijn de oorspronkelijke waarden."
                if target_menu is difference_menu else
                "Selecteer een geladen netwerk om de waarden per dagdeel te visualiseren."
            )
            target_menu.addAction(action)
            self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, action)
            self.visualisation_actions[visualisation_key] = action

        self.loaded_network_menu.addSeparator()
        self.gmzip_loadnet_action = QAction(
            "Maak geladen netwerk vanuit GMZIP...",
            self.iface.mainWindow(),
        )
        self.gmzip_loadnet_action.setToolTip(
            "Lees de shape en QBlok-resultaten rechtstreeks uit een Groeimodel-ZIP "
            "en maak een geladen GeoPackage met OS, RD en AS."
        )
        self.gmzip_loadnet_action.triggered.connect(
            self.create_loaded_network_from_gmzip
        )
        network_menu.addAction(self.gmzip_loadnet_action)
        self.iface.addPluginToMenu(
            self.PLUGIN_MENU_NAME,
            self.gmzip_loadnet_action,
        )

        self.difference_network_action = QAction(
            "Verschilnetwerk maken...",
            self.iface.mainWindow(),
        )
        self.difference_network_action.setToolTip(
            "Maak netwerk 1 min netwerk 2. Niet-gematchte links uit beide netwerken blijven zichtbaar."
        )
        self.difference_network_action.triggered.connect(self.create_difference_network)
        network_menu.addAction(self.difference_network_action)
        self.iface.addPluginToMenu(
            self.PLUGIN_MENU_NAME,
            self.difference_network_action,
        )

        self.turn_menu = self.menu.addMenu("Afslagverboden")
        self.remove_turn_layers_action = QAction("Lagen verwijderen", self.iface.mainWindow())
        self.remove_turn_layers_action.setToolTip(
            "Verwijder de afslagverbodlagen voor de actieve netwerkshape."
        )
        self.remove_turn_layers_action.triggered.connect(self.remove_turn_penalty_layers)
        self.turn_menu.addAction(self.remove_turn_layers_action)
        self.turn_menu.addSeparator()
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_turn_layers_action)

        self.link_turn_penalty_action = QAction(
            ".PEN koppelen aan actieve shape...",
            self.iface.mainWindow(),
        )
        self.link_turn_penalty_action.setToolTip(
            "Koppel een CUBE .pen-bestand via drie opeenvolgende knopen aan de actieve netwerkshape."
        )
        self.link_turn_penalty_action.triggered.connect(self.create_turn_penalty_layers)
        self.turn_menu.addAction(self.link_turn_penalty_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.link_turn_penalty_action)

        self.zones_menu = self.menu.addMenu("Zones 2022")
        self.remove_zones_action = QAction("Lagen verwijderen", self.iface.mainWindow())
        self.remove_zones_action.setToolTip(
            "Verwijder de zonekaarten die door deze plugin zijn toegevoegd."
        )
        self.remove_zones_action.triggered.connect(self.remove_zone_layers)
        self.zones_menu.addAction(self.remove_zones_action)
        self.zones_menu.addSeparator()
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_zones_action)

        for zone_key, definition in self.ZONES_2022.items():
            action = QAction(definition["label"], self.iface.mainWindow())
            action.setToolTip(
                f"Voeg de Zones 2022-kaart voor perceel {definition['label']} toe."
            )
            action.triggered.connect(
                lambda checked=False, key=zone_key: self.create_zone_layer(key)
            )
            self.zones_menu.addAction(action)
            self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, action)
            self.zone_actions[zone_key] = action

        self.inweva_menu = self.menu.addMenu("INWEVA")
        self.inweva_2025_menu = self.inweva_menu.addMenu("2025")
        self.remove_inweva_action = QAction("Lagen verwijderen", self.iface.mainWindow())
        self.remove_inweva_action.setToolTip(
            "Verwijder de INWEVA 2025-lagen die door deze plugin zijn toegevoegd."
        )
        self.remove_inweva_action.triggered.connect(self.remove_inweva_layers)
        self.inweva_2025_menu.addAction(self.remove_inweva_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_inweva_action)

        self.link_inweva_action = QAction("Koppelen met netwerk...", self.iface.mainWindow())
        self.link_inweva_action.setToolTip(
            "Koppel een INWEVA 2025-laag op WVK_IDS aan een geopende "
            "LMS/NRM-netwerklaag; alleen gematchte links worden opgenomen."
        )
        self.link_inweva_action.triggered.connect(self.link_inweva_to_network)
        self.inweva_2025_menu.addAction(self.link_inweva_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.link_inweva_action)

        self.split_inweva_action = QAction(
            "Alle 5 splitsen op actieve netwerklaag...",
            self.iface.mainWindow(),
        )
        self.split_inweva_action.setToolTip(
            "Splits alle vijf INWEVA 2025-netwerken naar de geometrie, WVK_ID "
            "en KnoopA/KnoopB van de actieve netwerklaag."
        )
        self.split_inweva_action.triggered.connect(self.split_all_inweva_networks)
        self.inweva_2025_menu.addAction(self.split_inweva_action)
        self.inweva_2025_menu.addSeparator()
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.split_inweva_action)

        for inweva_key, definition in self.INWEVA_LAYERS.items():
            action = QAction(definition["label"], self.iface.mainWindow())
            action.setToolTip(f"Voeg de INWEVA-laag '{definition['label']}' toe.")
            action.triggered.connect(
                lambda checked=False, key=inweva_key: self.create_inweva_layer(key)
            )
            self.inweva_2025_menu.addAction(action)
            self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, action)
            self.inweva_actions[inweva_key] = action

        self.map_menu = self.menu.addMenu("Kaart")
        self.align_osm_crs_action = QAction("Kaart uitlijnen met OpenStreetMap", self.iface.mainWindow())
        self.align_osm_crs_action.setToolTip(
            "Zet het project op de CRS van de OpenStreetMap XYZ-laag en herstel geselecteerde RD-lagen naar EPSG:28992."
        )
        self.align_osm_crs_action.triggered.connect(self.align_layers_to_openstreetmap)
        self.map_menu.addAction(self.align_osm_crs_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.align_osm_crs_action)
        update_action = QAction("Updates instellen / controleren...", self.iface.mainWindow())
        update_action.triggered.connect(self.updates.configure)
        self.map_menu.addAction(update_action)
        self.network_actions.append(update_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, update_action)

        self.scripts_menu = QMenu("Scripts", self.iface.mainWindow())
        self.link_net_action = QAction(".NET-attributen koppelen...", self.iface.mainWindow())
        self.link_net_action.setToolTip(
            "Lees een CUBE .NET-bestand direct en koppel de linkattributen op A/B aan de actieve netwerkshape."
        )
        self.link_net_action.triggered.connect(self.link_cube_net_to_active_shape)
        network_menu.insertAction(self.difference_network_action, self.link_net_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.link_net_action)

        self.project_menu = self.menu.addMenu("Projecten")
        self.choose_projects_action = QAction("Projecten kiezen...", self.iface.mainWindow())
        self.choose_projects_action.setToolTip(
            "Kies projecten uit de actieve netwerkshape en maak gefilterde projectlagen."
        )
        self.choose_projects_action.triggered.connect(self.choose_projects)
        self.project_menu.addAction(self.choose_projects_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.choose_projects_action)

        self.remove_projects_action = QAction("Projectlagen verwijderen", self.iface.mainWindow())
        self.remove_projects_action.setToolTip(
            "Verwijder de projectlagen voor de actieve netwerkshape."
        )
        self.remove_projects_action.triggered.connect(self.remove_project_layers)
        self.project_menu.addAction(self.remove_projects_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, self.remove_projects_action)

        self.attribute_menu.removeAction(self.remove_attribute_layers_action)
        self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_attribute_layers_action)
        self.remove_attribute_layers_action = None
        self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_loaded_network_layers_action)
        self.remove_loaded_network_layers_action = None
        clear_action = QAction("Visualisatielagen verwijderen...", self.iface.mainWindow())
        clear_action.triggered.connect(lambda: self._remove_visualisation_layers(
            self.ATTRIBUTE_VISUALISATIONS + self.LOADED_NETWORK_VISUALISATIONS,
            "Visualisatielagen", "visualisatiegroep(en)"))
        attribute_root.addSeparator()
        attribute_root.addAction(clear_action)
        self.network_actions.append(clear_action)
        self.iface.addPluginToMenu(self.PLUGIN_MENU_NAME, clear_action)
        extra_menu = QMenu("Extra data", self.iface.mainWindow())
        self.inweva_2025_menu.setTitle("INWEVA 2025")
        extra_menu.addMenu(self.zones_menu)
        extra_menu.addMenu(self.inweva_2025_menu)
        data_action = extra_menu.addAction("Datamap kiezen…")
        data_action.triggered.connect(self.choose_preset_data)
        # Only the six top-level menus are visible in the toolbar/plugin menu.
        for old_action in self.menu.actions():
            self.menu.removeAction(old_action)
        for label, submenu in (
            ("Netwerken", network_menu), ("Attributen", attribute_root),
            ("Afslagverboden", self.turn_menu), ("Projecten", self.project_menu),
            ("Extra data", extra_menu), ("Kaart", self.map_menu),
        ):
            self.menu.addMenu(submenu)
            self._add_toolbar_menu_button(label, submenu)
        if hasattr(self.iface, 'currentLayerChanged'):
            self.iface.currentLayerChanged.connect(self._refresh_visualisation_actions)
            self._refresh_visualisation_actions()

    def _add_toolbar_menu_button(self, label, menu):
        button = QToolButton(self.toolbar)
        button.setText(label)
        button.setToolTip(label)
        button.setToolButtonStyle(QT_TOOL_BUTTON_TEXT_ONLY)
        button.setPopupMode(TOOL_BUTTON_INSTANT_POPUP)
        button.setMenu(menu)
        self.toolbar_buttons.append(button)
        self.toolbar_widget_actions.append(self.toolbar.addWidget(button))

    def _refresh_visualisation_actions(self, *args):
        layer = self.iface.activeLayer()
        if layer is not None and layer.customProperty(self.SOURCE_PROPERTY):
            layer = QgsProject.instance().mapLayer(layer.customProperty(self.SOURCE_PROPERTY)) or layer
        is_network = layer is not None and layer.type() == QgsMapLayer.VectorLayer and QgsWkbTypes.geometryType(layer.wkbType()) == QgsWkbTypes.LineGeometry
        for key, action in self.visualisation_actions.items():
            enabled = bool(is_network and self._visualisation_field_groups(layer, self.VISUALISATIONS[key]))
            action.setEnabled(enabled)
            if not enabled:
                action.setToolTip('Selecteer een netwerklaag met de velden voor deze kaart. Bij nieuwe resultaatvelden moet het netwerk opnieuw vanuit GMZIP worden gemaakt.')
            else:
                action.setToolTip(self.VISUALISATIONS[key]['group_name'])

    def prepare_viewer_publication(self):
        """Create a local, inspectable package from the active QGIS layer."""
        layer = self.iface.activeLayer()
        if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            QMessageBox.warning(self.iface.mainWindow(), "RWS Viewer", "Selecteer eerst een geldige vectorlaag.")
            return
        fields = [field.name() for field in layer.fields()]
        if not fields:
            QMessageBox.warning(self.iface.mainWindow(), "RWS Viewer", "De actieve laag heeft geen attributen.")
            return
        object_id, accepted = QInputDialog.getItem(self.iface.mainWindow(), "RWS Viewer", "Uniek object-ID-veld", ["rws_fid (gegenereerd per publicatie)"] + fields, 0, False)
        if not accepted:
            return
        if object_id.startswith("rws_fid "):
            object_id = "rws_fid"
        directory = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Map voor RWS Viewer-publicatiepakket")
        if not directory:
            return
        package_name, accepted = QInputDialog.getText(self.iface.mainWindow(), "RWS Viewer", "Versienaam", text="netwerk-versie")
        if not accepted or not package_name.strip():
            return
        destination = Path(directory) / package_name.strip()
        try:
            os.environ.setdefault("QGIS_PREFIX_PATH", QgsApplication.prefixPath())
            manifest = prepare_package(layer, destination, object_id, fields)
        except ViewerPublicationError as error:
            QMessageBox.critical(self.iface.mainWindow(), "RWS Viewer", str(error))
            return
        QMessageBox.information(self.iface.mainWindow(), "RWS Viewer", "Publicatiepakket gemaakt:\n%s\n\n%d objecten, %d attribuutblokken." % (destination, manifest["feature_count"], manifest["attribute_blocks"]["count"]))

    def unload(self):
        if hasattr(self, "updates"):
            self.updates.unload()
        if hasattr(self.iface, 'currentLayerChanged'):
            self.iface.currentLayerChanged.disconnect(self._refresh_visualisation_actions)
        for action in self.network_actions:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, action)
        if self.publish_viewer_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.publish_viewer_action)
        for action in self.visualisation_actions.values():
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, action)
        if self.remove_attribute_layers_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_attribute_layers_action)
        if self.remove_loaded_network_layers_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_loaded_network_layers_action)
        if self.remove_turn_layers_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_turn_layers_action)
        if self.link_turn_penalty_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.link_turn_penalty_action)
        for action in self.zone_actions.values():
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, action)
        if self.remove_zones_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_zones_action)
        for action in self.inweva_actions.values():
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, action)
        if self.remove_inweva_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_inweva_action)
        if self.link_inweva_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.link_inweva_action)
        if self.split_inweva_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.split_inweva_action)
        if self.align_osm_crs_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.align_osm_crs_action)
        if self.link_net_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.link_net_action)
        if self.detect_roundabouts_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.detect_roundabouts_action)
        if self.review_roundabouts_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.review_roundabouts_action)
        if self.gmzip_loadnet_action is not None:
            self.iface.removePluginMenu(
                self.PLUGIN_MENU_NAME,
                self.gmzip_loadnet_action,
            )
        if self.difference_network_action is not None:
            self.iface.removePluginMenu(
                self.PLUGIN_MENU_NAME,
                self.difference_network_action,
            )
        if self.choose_projects_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.choose_projects_action)
        if self.remove_projects_action is not None:
            self.iface.removePluginMenu(self.PLUGIN_MENU_NAME, self.remove_projects_action)
        if self.toolbar is not None:
            self.toolbar.deleteLater()

    def choose_preset_data(self):
        folder = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Kies PluginData (Zones, INWEVA en projectenlijst)", str(self.ZONE_DATA_PATH.parent))
        if folder:
            QSettings().setValue("lmsnrm_toolbar/preset_data_path", folder)
            self.project_catalog = None
            self.project_catalog_meta = None
            self._info("Datamap ingesteld", folder)

    def choose_library_network(self, region):
        from .dialogs.library_network import LibraryNetworkDialog
        settings = QSettings()
        default_root = Path(r"P:\wvl\Toepassingen_NRM_En_LMS\ADHOC_NRM\RP2025\Autonetwerken")
        root = default_root if default_root.is_dir() else Path(settings.value("lmsnrm_toolbar/library_path", "") or default_root)
        def find_file(root):
            if not root.is_dir():
                return None
            for folder in [root, *[p for p in root.iterdir() if p.is_dir() and p.name.casefold() == region.casefold()]]:
                for path in folder.glob("*.gpkg"):
                    if path.stem.casefold() == f"rp25v2_{region}".casefold():
                        return path
            return None
        path = find_file(root)
        if path is None:
            chosen = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Kies de bibliotheekmap (bijvoorbeeld RP2025 v2)", str(root))
            if not chosen:
                return
            root = Path(chosen)
            path = find_file(root)
            if path is None:
                self._warn("Regio niet gevonden", f"Geen RP25v2_{region}.gpkg gevonden in deze map of de regiomap. Kies de bibliotheek van de netwerkbibliotheek-plugin.")
                return
            settings.setValue("lmsnrm_toolbar/library_path", str(root))
        try:
            dialog = LibraryNetworkDialog(path, region, self.iface.mainWindow())
            if _exec_dialog(dialog) == DIALOG_ACCEPTED:
                name = dialog.selection()
                self._load_input_network(f"{path}|layername={name}", f"{region} — {name.replace('netwerk_', '').replace('_', ' — ')}")
        except Exception as error:
            self._warn("Bibliotheek niet geladen", str(error))

    def import_input_gmzip(self):
        from .services.input_network import write_input_network
        source, _ = QFileDialog.getOpenFileName(self.iface.mainWindow(), "Kies GMZIP voor het invoernetwerk", "", "ZIP (*.zip)")
        if not source:
            return
        output, _ = QFileDialog.getSaveFileName(self.iface.mainWindow(), "Sla invoernetwerk op", str(Path(source).with_name(Path(source).stem + "_invoernetwerk.gpkg")), "GeoPackage (*.gpkg)")
        if not output:
            return
        output = Path(output).with_suffix('.gpkg')
        progress = QProgressDialog("Invoernetwerk uit GMZIP halen...", "Annuleren", 0, 100, self.iface.mainWindow())
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.show()
        def update(value):
            progress.setValue(int(value))
            QCoreApplication.processEvents()
        try:
            label = write_input_network(Path(source), output, progress.wasCanceled, update)
            self._load_input_network(f"{output}|layername=invoernetwerk", label)
        except InterruptedError:
            self._info("Import geannuleerd", "Er is geen invoernetwerk toegevoegd.")
        except Exception as error:
            self._warn("Invoernetwerk niet gemaakt", str(error))
        finally:
            progress.close()

    def load_local_network(self):
        path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(), "Kies een lokaal invoernetwerk", "",
            "Netwerken (*.shp *.gpkg)",
        )
        if not path:
            return
        if Path(path).suffix.lower() == ".gpkg":
            details = QgsProviderRegistry.instance().querySublayers(path)
            details = [d for d in details if QgsWkbTypes.geometryType(d.wkbType()) == QgsWkbTypes.LineGeometry]
            if not details:
                self._warn("Geen netwerklaag", "Dit GeoPackage bevat geen lijnlagen.")
                return
            labels = [f"{i + 1}. {d.name()}" for i, d in enumerate(details)]
            choice, accepted = QInputDialog.getItem(
                self.iface.mainWindow(), "Kies netwerklaag", "Netwerk:", labels, 0, False,
            )
            if not accepted:
                return
            detail = details[labels.index(choice)]
            self._load_input_network(detail.uri(), detail.name())
        else:
            self._load_input_network(path, Path(path).stem)

    def load_zipped_network(self):
        path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(), "Kies een netwerk-ZIP", "", "ZIP (*.zip)",
        )
        if not path:
            return
        try:
            with zipfile.ZipFile(path) as archive:
                names = sorted(n for n in archive.namelist() if n.lower().endswith(".shp"))
            if not names:
                self._warn("Geen netwerkshapes", "Deze ZIP bevat geen shapefiles.")
                return
            choice, accepted = QInputDialog.getItem(
                self.iface.mainWindow(), "Kies invoernetwerk uit ZIP",
                "Netwerk (rechtstreeks lezen; lokale GeoPackage aanbevolen voor dagelijks gebruik):",
                names, 0, False,
            )
            if accepted:
                self._load_input_network(f"/vsizip/{Path(path).resolve()}/{choice}", Path(choice).stem)
        except (OSError, zipfile.BadZipFile) as error:
            self._warn("ZIP niet leesbaar", str(error))

    def _load_input_network(self, uri, name):
        layer = QgsVectorLayer(uri, name, "ogr")
        if not layer.isValid() or QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.LineGeometry:
            self._warn("Netwerk niet geladen", "De gekozen bron is geen geldige lijnlaag.")
            return None
        QgsProject.instance().addMapLayer(layer)
        self.iface.setActiveLayer(layer)
        self._zoom_to_layers([layer])
        self._info("Invoernetwerk geladen", f"{name}: {layer.featureCount():,} links. De laag verwijst naar de gekozen bron.")
        return layer

    def create_visualisation_layers(self, visualisation_key):
        definition = self.VISUALISATIONS[visualisation_key]
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        field_groups = self._visualisation_field_groups(source_layer, definition)
        if not field_groups:
            if visualisation_key == "direction":
                self._warn("Geen richtingselectievelden", "Deze export bevat geen H_SEL/T_SEL. De CUBE-netwerken hebben afzonderlijke gerichte links; H_SEL/T_SEL zijn selectievelden van het moederbestand.")
                return
            self._warn(
                "Veld niet gevonden",
                f"De actieve laag heeft geen veld voor '{definition['group_name']}'. Verwachte veldnamen: {', '.join(definition['field_names'])}.",
            )
            return

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(source_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)

        removed = self._remove_existing_visualisation_groups(source_layer, visualisation_key)
        self._hide_other_visualisation_groups(source_layer, visualisation_key)

        group_name = definition["group_name"]
        group = parent_node.insertGroup(insert_index, group_name)
        group.setCustomProperty(self.VISUALISATION_PROPERTY, visualisation_key)
        group.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
        group.setExpanded(True)
        group.setItemVisibilityChecked(True)

        created = 0
        failed = []
        use_daypart_groups = any(field_group["daypart"] is not None for field_group in field_groups)
        default_group_label = definition.get("default_group_label")
        labels = [field_group["label"] for field_group in field_groups]
        if default_group_label not in labels:
            default_group_label = "RD" if "RD" in labels else labels[0]
        for field_group in field_groups:
            target_group = group
            if use_daypart_groups:
                target_group = group.addGroup(field_group["label"])
                is_default_group = field_group["label"] == default_group_label
                target_group.setExpanded(is_default_group)
                target_group.setItemVisibilityChecked(is_default_group)

            group_created, group_failed = self._add_category_layers(
                project,
                target_group,
                source_layer,
                field_group["field"],
                {**definition, "categories": field_group.get("categories") or definition["categories"]},
                visualisation_key,
            )
            if group_created == 0 and use_daypart_groups:
                group.removeChildNode(target_group)
            created += group_created
            failed.extend(group_failed)

        if created == 0:
            if failed:
                self._warn("Klassefilters niet toegepast", "De klasselagen konden niet worden gemaakt of de bron heeft de filters geweigerd. Er zijn geen ongefilterde klasselagen toegevoegd.")
            else:
                self._warn("Geen waarden gevonden", definition["empty_message"])
            parent_node.removeChildNode(group)
            return

        if source_node is not None:
            source_node.setItemVisibilityChecked(False)

        self.iface.mapCanvas().refresh()

        if failed:
            self._warn(
                "Visualisatie deels aangemaakt",
                f"{created} lagen aangemaakt, {len(failed)} lagen niet. Controleer de databron.",
            )
            return

        suffix = " Oude visualisatiegroep is vervangen." if removed else ""
        self._info(
            "Visualisatie aangemaakt",
            f"{created} gefilterde lagen staan onder '{group_name}'. De bronlaag is uitgezet.{suffix}",
        )

    def remove_attribute_layers(self):
        self._remove_visualisation_layers(
            self.ATTRIBUTE_VISUALISATIONS,
            "Attribuutlagen",
            "attribuutgroep(en)",
        )

    def remove_loaded_network_layers(self):
        self._remove_visualisation_layers(
            self.LOADED_NETWORK_VISUALISATIONS,
            "Geladen-netwerklagen",
            "geladen-netwerkgroep(en)",
        )

    def create_turn_penalty_layers(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        pen_file, _selected_filter = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Selecteer CUBE turnpenaltybestand",
            str(Path.home()),
            "CUBE turnpenalties (*.pen);;Alle bestanden (*)",
        )
        if not pen_file:
            return

        try:
            parsed = parse_pen_file(pen_file)
        except Exception as exc:
            self._warn("Afslagverboden niet gelezen", str(exc))
            return

        total = int(source_layer.featureCount()) + len(parsed.records)
        progress = QProgressDialog(
            "Netwerklinks koppelen...",
            "Annuleren",
            0,
            max(1, total),
            self.iface.mainWindow(),
        )
        progress.setWindowTitle("Afslagverboden koppelen")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setMinimumDuration(0)
        progress.show()

        def update_progress(label, value, maximum):
            progress.setLabelText(label)
            progress.setMaximum(max(1, int(maximum)))
            progress.setValue(min(int(value), int(maximum)))
            QCoreApplication.processEvents()
            if progress.wasCanceled():
                raise TurnPenaltyCancelled()

        try:
            result = build_turn_penalty_layers(
                source_layer,
                parsed,
                progress_callback=update_progress,
            )
        except TurnPenaltyCancelled:
            return
        except Exception as exc:
            self._warn("Afslagverboden niet gekoppeld", str(exc))
            return
        finally:
            progress.close()

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(source_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)
        removed = self._remove_existing_turn_groups(
            source_layer,
            pen_path=parsed.path,
        )

        group_name = f"Afslagverboden - {parsed.path.stem}"
        group = parent_node.insertGroup(insert_index, group_name)
        group.setCustomProperty(self.TURN_PROPERTY, True)
        group.setCustomProperty(self.TURN_FILE_PROPERTY, str(parsed.path.resolve()))
        group.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
        group.setExpanded(True)

        result.movement_layer.setName(
            f"Verboden afslagbewegingen [{result.matched_count}]"
        )
        result.junction_layer.setName(f"Draaipunten [{result.matched_count}]")
        result_layers = [result.movement_layer, result.junction_layer]
        if result.unmatched_layer is not None:
            result.unmatched_layer.setName(f"Niet gekoppeld [{result.unmatched_count}]")
            result_layers.append(result.unmatched_layer)

        for layer in result_layers:
            layer.setCustomProperty(self.TURN_PROPERTY, True)
            layer.setCustomProperty(self.TURN_FILE_PROPERTY, str(parsed.path.resolve()))
            layer.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
            project.addMapLayer(layer, False)
            layer_node = group.addLayer(layer)
            layer_node.setCustomProperty("showFeatureCount", True)

        self.iface.mapCanvas().refresh()

        details = [
            f"{result.matched_count} van {len(parsed.records)} verboden gekoppeld",
        ]
        if result.unmatched_count:
            details.append(f"{result.unmatched_count} niet gekoppeld")
        if result.ambiguous_count:
            details.append(
                f"{result.ambiguous_count} met meerdere mogelijke moederlinks"
            )
        if parsed.declared_count is not None and parsed.declared_count != len(parsed.records):
            details.append(
                f"bestandskop noemt {parsed.declared_count}, gelezen {len(parsed.records)}"
            )
        if parsed.malformed_lines:
            details.append(f"{len(parsed.malformed_lines)} ongeldige regel(s) overgeslagen")
        if removed:
            details.append("oude groep voor dit .pen-bestand vervangen")

        message = ". ".join(details) + "."
        if result.unmatched_count or parsed.malformed_lines:
            self._warn("Afslagverboden gedeeltelijk gekoppeld", message)
        else:
            self._info("Afslagverboden gekoppeld", message)

    def remove_turn_penalty_layers(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        removed = self._remove_existing_turn_groups(source_layer)
        self.iface.mapCanvas().refresh()
        if removed:
            self._info(
                "Afslagverboden verwijderd",
                f"{removed} afslagverbodgroep(en) verwijderd.",
            )
        else:
            self._info(
                "Geen afslagverboden",
                "Er zijn geen afslagverbodlagen gevonden voor de actieve laag.",
            )

    def _remove_visualisation_layers(self, visualisation_keys, title, count_label):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        removed = self._remove_existing_visualisation_groups(
            source_layer,
            visualisation_keys=visualisation_keys,
        )
        self.iface.mapCanvas().refresh()

        if removed:
            self._info(
                f"{title} verwijderd",
                f"{removed} {count_label} verwijderd.",
            )
        else:
            self._info(
                f"Geen {title.lower()}",
                "Er zijn geen bijbehorende lagen gevonden voor de actieve laag.",
            )

    def create_zone_layer(self, zone_key):
        definition = self.ZONES_2022[zone_key]
        if not self.ZONE_DATA_PATH.exists():
            self._warn(
                "Zonebestand ontbreekt",
                f"Het GeoPackage met zones is niet gevonden: {self.ZONE_DATA_PATH.name}.",
            )
            return

        layer = QgsVectorLayer(
            f"{self.ZONE_DATA_PATH}|layername={definition['layer_name']}",
            f"Zones 2022 - {definition['label']}",
            "ogr",
        )
        if not layer.isValid():
            self._warn(
                "Zonekaart niet geladen",
                f"De laag '{definition['layer_name']}' kon niet uit {self.ZONE_DATA_PATH.name} worden geladen.",
            )
            return

        layer.setRenderer(self._zone_renderer(layer))
        layer.setCustomProperty(self.ZONE_PROPERTY, True)
        layer.setCustomProperty(self.ZONE_KEY_PROPERTY, zone_key)
        layer.setDisplayExpression(self._zone_display_expression(layer, definition))

        removed = self._remove_existing_zone_layers(zone_key=zone_key)
        QgsProject.instance().addMapLayer(layer)
        zoomed = self._zoom_to_layers([layer])

        suffix = " Oude zonelaag is vervangen." if removed else ""
        self._info(
            "Zonekaart aangemaakt",
            f"'{layer.name()}' is toegevoegd met zwaartepunten in dezelfde laag."
            f"{' Ingezoomd op de zonekaart.' if zoomed else ''}{suffix}",
        )

    def remove_zone_layers(self):
        removed = self._remove_existing_zone_layers()
        self.iface.mapCanvas().refresh()

        if removed:
            self._info("Zonelagen verwijderd", f"{removed} zonelaag/lagen verwijderd.")
        else:
            self._info("Geen zonelagen", "Er zijn geen door de plugin toegevoegde zonelagen gevonden.")

    def create_inweva_layer(self, inweva_key):
        definition = self.INWEVA_LAYERS[inweva_key]
        if not self.INWEVA_DATA_PATH.exists():
            self._warn(
                "INWEVA-bestand ontbreekt",
                f"Het GeoPackage is niet gevonden: {self.INWEVA_DATA_PATH.name}.",
            )
            return

        source_uri = f"{self.INWEVA_DATA_PATH}|layername={definition['layer_name']}"
        layer = QgsVectorLayer(
            source_uri,
            f"INWEVA 2025 - {definition['label']}",
            "ogr",
        )
        if not layer.isValid():
            self._warn(
                "INWEVA niet geladen",
                f"De laag '{definition['layer_name']}' kon niet worden geladen uit {self.INWEVA_DATA_PATH.name}.",
            )
            return

        layer.setRenderer(self._inweva_renderer(inweva_key))
        layer.setCustomProperty(self.INWEVA_PROPERTY, True)
        layer.setCustomProperty(self.INWEVA_KEY_PROPERTY, inweva_key)
        layer.setDisplayExpression(self._inweva_display_expression(layer))

        removed = self._remove_existing_inweva_layers(inweva_key=inweva_key)
        QgsProject.instance().addMapLayer(layer)
        zoomed = self._zoom_to_layers([layer])

        suffix = " Oude INWEVA-laag is vervangen." if removed else ""
        self._info(
            "INWEVA-laag aangemaakt",
            f"'{layer.name()}' is toegevoegd."
            f"{' Ingezoomd op de laag.' if zoomed else ''}{suffix}",
        )

    def remove_inweva_layers(self):
        removed = self._remove_existing_inweva_layers()
        self.iface.mapCanvas().refresh()

        if removed:
            self._info("INWEVA-lagen verwijderd", f"{removed} INWEVA-laag/lagen verwijderd.")
        else:
            self._info("Geen INWEVA-lagen", "Er zijn geen door de plugin toegevoegde INWEVA-lagen gevonden.")

    def link_inweva_to_network(self):
        network_layers = self._candidate_network_layers_for_inweva()
        if not network_layers:
            self._warn(
                "Geen netwerklaag",
                "Laad eerst een LMS/NRM-netwerklaag met lijngeometrie en een ID-veld, bijvoorbeeld WVK_ID.",
            )
            return

        dialog = InwevaLinkDialog(network_layers, self.INWEVA_LAYERS, self.iface.mainWindow())
        if _exec_dialog(dialog) != DIALOG_ACCEPTED:
            return

        network_layer = QgsProject.instance().mapLayer(dialog.selected_network_layer_id())
        network_id_field = dialog.selected_network_id_field()
        inweva_key = dialog.selected_inweva_key()
        if network_layer is None or not network_id_field:
            self._warn("Koppeling mislukt", "Geen geldige netwerklaag of ID-veld gekozen.")
            return

        inweva_layer = self._load_inweva_source_layer(inweva_key)
        if inweva_layer is None:
            return

        result = self._create_inweva_link_layer(
            network_layer,
            network_id_field,
            inweva_layer,
            inweva_key,
        )
        if result is None:
            return

        if result["matched"] == 0:
            self._warn(
                "INWEVA niet gekoppeld",
                "Geen enkele netwerklink kon worden gekoppeld. Controleer of het gekozen netwerkveld "
                "overeenkomt met de waarden in WVK_IDS.",
            )
            return

        self._info(
            "INWEVA gekoppeld",
            f"'{result['layer_name']}' is aangemaakt. "
            f"{result['matched']} gekoppelde netwerklink(s) opgenomen. "
            f"{result['unmatched_network']} netwerklink(s) zonder INWEVA-match zijn weggelaten. "
            f"INWEVA bevat {result['inweva_feature_total']} lijn(en) met "
            f"{result['inweva_id_total']} WVK_ID-verwijzing(en)."
            f"{' Richting geometrisch bepaald voor ' + str(result['directional_matches']) + ' link(s).' if result['directional_matches'] else ''}"
            f"{' Oude koppellaag vervangen.' if result['removed_existing'] else ''}",
        )

    def split_all_inweva_networks(self):
        network_layer = self.iface.activeLayer()
        if not self._is_inweva_network_candidate(network_layer):
            self._warn(
                "Geen actieve netwerklaag",
                "Selecteer eerst de LMS/NRM-lijnlaag waarop de vijf INWEVA-netwerken "
                "moeten worden gesplitst.",
            )
            return

        network_fields = self._inweva_split_network_fields(network_layer)
        if network_fields is None:
            self._warn(
                "Netwerkvelden ontbreken",
                "De actieve laag heeft WVK_ID en knoopvelden nodig. Verwacht "
                "KnoopA/KnoopB, KNOOPA/KNOOPB of A/B.",
            )
            return

        inweva_layers = []
        for inweva_key in self.INWEVA_LAYERS:
            inweva_layer = self._load_inweva_source_layer(inweva_key)
            if inweva_layer is None:
                return
            inweva_layers.append((inweva_key, inweva_layer))

        network_total = max(0, int(network_layer.featureCount()))
        index_total = sum(max(0, int(layer.featureCount())) for _key, layer in inweva_layers)
        progress_max = index_total + network_total * len(inweva_layers)
        progress = QProgressDialog(
            "INWEVA-netwerken voorbereiden...",
            "Annuleren",
            0,
            progress_max,
            self.iface.mainWindow(),
        )
        progress.setWindowTitle("INWEVA 2025 splitsen")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setMinimumDuration(0)
        progress.show()
        QCoreApplication.processEvents()

        created = []
        offset = 0
        try:
            for inweva_key, inweva_layer in inweva_layers:
                definition = self.INWEVA_LAYERS[inweva_key]
                id_field = self._find_first_field(inweva_layer, ["WVK_IDS", "WVK_ID"])
                if id_field is None:
                    self._warn(
                        "WVK_IDS ontbreekt",
                        f"De INWEVA-laag '{definition['label']}' heeft geen WVK_IDS.",
                    )
                    return

                progress.setLabelText(f"{definition['label']}: WVK_IDS indexeren...")
                inweva_index = build_inweva_index(
                    inweva_layer,
                    id_field.name(),
                    progress_callback=lambda value, base=offset: self._set_progress(
                        progress,
                        base + value,
                    ),
                    cancel_callback=progress.wasCanceled,
                )
                if progress.wasCanceled():
                    return
                offset += max(0, int(inweva_layer.featureCount()))

                progress.setLabelText(f"{definition['label']}: netwerklinks splitsen...")
                result = self._create_split_inweva_layer(
                    network_layer,
                    network_fields,
                    inweva_layer,
                    inweva_key,
                    inweva_index,
                    progress,
                    offset,
                )
                if result is None or progress.wasCanceled():
                    return
                created.append(result)
                offset += network_total
        finally:
            progress.close()

        if not created or not any(result["matched"] for result in created):
            self._warn(
                "INWEVA niet gesplitst",
                "Geen WVK_ID uit de actieve netwerklaag is gevonden in de vijf INWEVA-netwerken.",
            )
            return

        removed = self._add_inweva_split_group(network_layer, created)
        matched_counts = {result["matched"] for result in created}
        matched_text = (
            f"{next(iter(matched_counts))} links per laag"
            if len(matched_counts) == 1
            else ", ".join(
                f"{result['label']}: {result['matched']}"
                for result in created
            )
        )
        directional = sum(result["directional_matches"] for result in created)
        self._info(
            "INWEVA-netwerken gesplitst",
            f"Vijf lagen aangemaakt op basis van '{network_layer.name()}': {matched_text}. "
            f"Elke laag bevat WVK_ID, KnoopA, KnoopB en de INWEVA-attributen. "
            f"Richting is geometrisch bepaald voor {directional} koppeling(en)."
            f"{' De vorige gesplitste groep is vervangen.' if removed else ''}",
        )

    def align_layers_to_openstreetmap(self):
        layers = [
            layer
            for layer in self._selected_layers_or_active()
            if layer.type() == QgsMapLayer.VectorLayer and not self._layer_is_openstreetmap(layer)
        ]
        if not layers:
            self._warn(
                "Geen vectorlagen geselecteerd",
                "Selecteer een of meer netwerk-, zone- of visualisatielagen in de lagenboom.",
            )
            return

        osm_layer = self._find_openstreetmap_layer()
        target_crs = self._openstreetmap_target_crs(osm_layer)
        rd_crs = QgsCoordinateReferenceSystem("EPSG:28992")

        if target_crs.isValid():
            QgsProject.instance().setCrs(target_crs)

        updated = []
        unchanged = []
        for layer in layers:
            current_crs = layer.crs()
            if self._layer_extent_looks_like_rd(layer):
                if not current_crs.isValid() or current_crs.authid() != rd_crs.authid():
                    layer.setCrs(rd_crs)
                    updated.append(layer.name())
                else:
                    unchanged.append(layer.name())
                continue

            if not current_crs.isValid():
                layer.setCrs(target_crs)
                updated.append(layer.name())
            else:
                unchanged.append(layer.name())

        self.iface.mapCanvas().refresh()
        target_label = target_crs.authid() or target_crs.description() or "OpenStreetMap CRS"
        source_text = f" uit '{osm_layer.name()}'" if osm_layer is not None else " (standaard OpenStreetMap)"
        details = []
        if updated:
            details.append(f"{len(updated)} laag/lagen aangepast")
        if unchanged:
            details.append(f"{len(unchanged)} laag/lagen stonden al goed of zijn ongemoeid gelaten")

        self._info(
            "CRS afgestemd",
            f"Project-CRS staat op {target_label}{source_text}. " + "; ".join(details) + ".",
        )

    def detect_roundabouts(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        progress = QProgressDialog(
            "Rotondes opsporen...",
            "Annuleren",
            0,
            max(1, int(source_layer.featureCount()) * 3),
            self.iface.mainWindow(),
        )
        progress.setWindowTitle("Rotondes opsporen")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setMinimumDuration(0)
        progress.show()

        def update_progress(label, value, maximum):
            progress.setMaximum(max(1, int(maximum)))
            progress.setLabelText(label)
            progress.setValue(min(int(value), progress.maximum()))
            QCoreApplication.processEvents()
            if progress.wasCanceled():
                raise RoundaboutCancelled()

        try:
            result = build_roundabout_layers(
                source_layer,
                progress_callback=update_progress,
                cancel_callback=progress.wasCanceled,
            )
        except RoundaboutCancelled:
            return
        except Exception as exc:
            self._warn("Rotondes niet opgespoord", str(exc))
            return
        finally:
            progress.close()

        if result.selected_count == 0:
            removed = self._remove_existing_roundabout_groups(source_layer)
            self.iface.mapCanvas().refresh()
            suffix = f" Oude rotondegroep verwijderd." if removed else ""
            self._info(
                "Geen rotondes gevonden",
                "Er zijn geen kandidaat-rotondes gevonden met de huidige drempels."
                + suffix,
            )
            return

        self._style_roundabout_layers(result.link_layer, result.area_layer)

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(source_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)

        removed = self._remove_existing_roundabout_groups(source_layer)
        group = parent_node.insertGroup(insert_index, "Rotondes")
        group.setCustomProperty(self.ROUNDABOUT_PROPERTY, True)
        group.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
        group.setExpanded(True)
        group.setItemVisibilityChecked(True)

        for layer in (result.area_layer, result.link_layer):
            layer.setCustomProperty(self.ROUNDABOUT_PROPERTY, True)
            layer.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
            project.addMapLayer(layer, False)
            layer_node = group.addLayer(layer)
            layer_node.setItemVisibilityChecked(True)
            layer_node.setCustomProperty("showFeatureCount", True)

        if source_node is not None:
            source_node.setItemVisibilityChecked(False)
        if hasattr(self.iface, "setActiveLayer"):
            self.iface.setActiveLayer(result.link_layer)

        zoomed = self._zoom_to_layers([result.link_layer])
        self.iface.mapCanvas().refresh()

        suffix = " Oude rotondegroep is vervangen." if removed else ""
        self._info(
            "Rotondes opgespoord",
            f"{result.selected_count} kandidaat-rotonde(s) gevonden, "
            f"{result.link_count} link(s) gemarkeerd."
            f"{' Ingezoomd op kandidaten.' if zoomed else ''}{suffix}",
        )

    def review_roundabouts(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        area_layer, link_layer = self._roundabout_layers(source_layer)
        if area_layer is None:
            self._warn(
                "Geen rotondekandidaten",
                "Maak eerst kandidaat-rotondes met Scripts > Rotondes opsporen...",
            )
            return

        self._ensure_roundabout_control_field(area_layer)
        if link_layer is not None:
            self._ensure_roundabout_control_field(link_layer)

        candidates = [
            feature
            for feature in area_layer.getFeatures()
            if str(feature["controle"] or "").strip() == ""
        ]
        candidates = self._roundabout_review_sample(candidates)
        if not candidates:
            self._info(
                "Rotondes gecontroleerd",
                "Alle kandidaat-rotondes hebben al een controlewaarde.",
            )
            return

        self._info(
            "Rotondecontrole",
            "Controle mengt compactheidsklassen en adviestypen, zodat niet steeds dezelfde vorm terugkomt.",
        )

        dialog = RoundaboutReviewDialog(self.iface.mainWindow())
        dialog.context_button.clicked.connect(lambda: self._scale_canvas_extent(4.0))
        dialog.zoom_out_button.clicked.connect(lambda: self._scale_canvas_extent(1.6))
        dialog.zoom_in_button.clicked.connect(lambda: self._scale_canvas_extent(0.65))
        reviewed = Counter()
        stopped = False

        for index, feature in enumerate(candidates, 1):
            roundabout_id = str(feature["rotonde_id"])
            self._focus_roundabout_candidate(
                area_layer,
                link_layer,
                feature,
                roundabout_id,
                scale=8.0,
            )
            self._move_roundabout_dialog_to_top(dialog)
            dialog.set_candidate(feature, index, len(candidates))
            if _exec_dialog(dialog) != DIALOG_ACCEPTED:
                stopped = True
                break

            choice = dialog.choice
            if choice == "stop":
                stopped = True
                break
            if choice == "overslaan":
                reviewed["overgeslagen"] += 1
                continue

            self._set_roundabout_control(area_layer, link_layer, roundabout_id, choice)
            reviewed[choice] += 1

        area_layer.removeSelection()
        if link_layer is not None:
            link_layer.removeSelection()
        self.iface.mapCanvas().refresh()

        parts = []
        for key in ("ja", "nee", "twijfel", "overgeslagen"):
            if reviewed[key]:
                parts.append(f"{reviewed[key]} {key}")
        detail = ", ".join(parts) if parts else "geen wijzigingen"
        suffix = " Controle gestopt." if stopped else " Controle klaar."
        self._info("Rotondecontrole", detail + "." + suffix)

    def link_cube_net_to_active_shape(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        key_fields = self._shape_key_fields(source_layer)
        if key_fields is None:
            self._warn(
                "A/B-velden ontbreken",
                "De actieve shape heeft velden A en B nodig om .NET-data te koppelen.",
            )
            return

        net_file, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Kies CUBE .NET bestand",
            "",
            "CUBE netwerk (*.net *.NET);;Alle bestanden (*.*)",
        )
        if not net_file:
            return

        net_path = Path(net_file)
        metadata = self._cube_net_metadata(net_path)

        try:
            net_rows, import_fields, net_total, duplicates = self._read_cube_net_links(net_path, metadata)
        except Exception as exc:
            csv_path = self._cube_net_csv_path(net_path)
            if not csv_path.exists():
                self._warn(
                    ".NET lezen mislukt",
                    f"Het .NET-bestand kon niet direct worden gelezen: {exc}",
                )
                return
            try:
                net_rows, import_fields, net_total, duplicates = self._read_net_link_csv(
                    csv_path,
                    self._cube_net_schema_path(net_path),
                )
            except Exception as csv_exc:
                self._warn(
                    ".NET lezen mislukt",
                    f"Het .NET-bestand kon niet direct worden gelezen ({exc}) en de CSV-fallback kon niet worden gekoppeld: {csv_exc}",
                )
                return

        try:
            result = self._create_net_link_layer(
                source_layer,
                key_fields,
                net_path,
                metadata,
                net_rows,
                import_fields,
                net_total,
                duplicates,
            )
        except Exception as exc:
            self._warn("Koppelen mislukt", f"De .NET-data kon niet worden gekoppeld: {exc}")
            return

        message = (
            f"{result['matched']} van {result['shape_total']} shape-links gekoppeld. "
            f"{result['net_total']} linkregels in .NET"
        )
        if result.get("net_header_total") is not None:
            message += f", {result['net_header_total']} links volgens .NET-header"
        message += "."

        if result["unmatched_shape"] or result["unused_net"] or result["duplicate_net"]:
            details = []
            if result["unmatched_shape"]:
                details.append(f"{result['unmatched_shape']} shape-link(s) zonder .NET-data")
            if result["unused_net"]:
                details.append(f"{result['unused_net']} .NET-link(s) niet gebruikt")
            if result["duplicate_net"]:
                details.append(f"{result['duplicate_net']} dubbele A/B-sleutel(s) in export")
            self._warn("Gedeeltelijk gekoppeld", message + " " + "; ".join(details) + ".")
        else:
            self._info(".NET gekoppeld", message)

    def create_loaded_network_from_gmzip(self):
        zip_file, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Kies Groeimodel-ZIP",
            "",
            "Groeimodel ZIP (*.zip *.ZIP);;Alle bestanden (*.*)",
        )
        if not zip_file:
            return

        zip_path = Path(zip_file)
        default_output = zip_path.with_name(
            f"{zip_path.stem}_geladen_netwerk.gpkg"
        )
        output_file, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            "Sla geladen netwerk op",
            str(default_output),
            "GeoPackage (*.gpkg)",
        )
        if not output_file:
            return
        output_path = Path(output_file)
        if output_path.suffix.casefold() != ".gpkg":
            output_path = output_path.with_suffix(".gpkg")

        progress = QProgressDialog(
            "GMZIP controleren...",
            "Annuleren",
            0,
            100,
            self.iface.mainWindow(),
        )
        progress.setWindowTitle("Geladen netwerk vanuit GMZIP")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setAutoClose(False)
        progress.show()
        QCoreApplication.processEvents()

        loadnet_index = None
        try:
            contents = discover_gmzip(zip_path)
            source_layer = QgsVectorLayer(
                contents.vsi_shape_path,
                contents.shape_name,
                "ogr",
            )
            if not source_layer.isValid():
                raise GmZipLoadnetError(
                    f"De shape '{contents.shape_member}' kon niet rechtstreeks uit de GMZIP worden geopend."
                )
            if not source_layer.crs().isValid() and self._layer_extent_looks_like_rd(
                source_layer
            ):
                source_layer.setCrs(
                    QgsCoordinateReferenceSystem("EPSG:28992")
                )

            shape_total = max(1, source_layer.featureCount())
            progress.setRange(0, shape_total * 7)

            stage_labels = (
                "OS netwerkgegevens lezen...",
                "OS verkeersgegevens lezen...",
                "RD netwerkgegevens lezen...",
                "RD verkeersgegevens lezen...",
                "AS netwerkgegevens lezen...",
                "AS verkeersgegevens lezen...",
            )

            def index_progress(stage, count, _member):
                progress.setLabelText(stage_labels[stage])
                progress.setValue(stage * shape_total + min(count, shape_total))
                QCoreApplication.processEvents()

            loadnet_index = build_loadnet_index(
                zip_path,
                progress_callback=index_progress,
                cancel_callback=progress.wasCanceled,
            )

            progress.setLabelText("Shape koppelen en GeoPackage schrijven...")

            def write_progress(processed, _total):
                progress.setValue(6 * shape_total + min(processed, shape_total))
                QCoreApplication.processEvents()

            result = write_loaded_geopackage(
                source_layer,
                loadnet_index,
                output_path,
                layer_name="geladen_netwerk",
                progress_callback=write_progress,
                cancel_callback=progress.wasCanceled,
            )
            progress.setValue(shape_total * 7)
            QCoreApplication.processEvents()
        except GmZipLoadnetCancelled:
            progress.close()
            self._info(
                "GMZIP verwerking geannuleerd",
                "Er is geen geladen netwerk toegevoegd.",
            )
            return
        except Exception as exc:
            progress.close()
            self._warn(
                "Geladen netwerk niet gemaakt",
                str(exc),
            )
            return
        finally:
            if loadnet_index is not None:
                loadnet_index.close()

        progress.setLabelText("Lagen in QGIS laden...")
        QCoreApplication.processEvents()
        loaded_layers = self._load_gmzip_result_layers(
            result,
            contents.shape_name,
            zip_path,
        )
        progress.close()
        if not loaded_layers:
            self._warn(
                "GeoPackage gemaakt, maar niet geladen",
                f"Het bestand staat op {result['output_path']}.",
            )
            return

        message = (
            f"{result['matched']} van {result['shape_total']} shape-links gekoppeld. "
            f"De gecombineerde laag bevat OS-, RD- en AS-attributen."
        )
        if result["unmatched_shape"] or result["unused_data"]:
            details = []
            if result["unmatched_shape"]:
                details.append(
                    f"{result['unmatched_shape']} shape-link(s) zonder modeldata"
                )
            if result["unused_data"]:
                details.append(
                    f"{result['unused_data']} modelregel(s) niet gebruikt"
                )
            self._warn(
                "GMZIP gedeeltelijk gekoppeld",
                message + " " + "; ".join(details) + ".",
            )
        else:
            self._info("Geladen netwerk gemaakt", message)

    def _load_gmzip_result_layers(self, result, shape_name, zip_path):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        identity = network_label(zip_path, shape_name)
        group = QgsLayerTreeGroup(f"Geladen netwerk — {identity}")
        group.setCustomProperty(self.SCRIPT_PROPERTY, "gmzip_loadnet")
        group.setCustomProperty("rws_toolbar/gmzip_path", str(zip_path))
        root.insertChildNode(0, group)

        definitions = [
            (
                result["layer_name"],
                f"{identity} — Alle dagdelen",
                True,
            ),
            (
                result["view_names"]["OS"],
                f"{identity} — OS (ochtendspits)",
                False,
            ),
            (
                result["view_names"]["RD"],
                f"{identity} — RD (restdag)",
                False,
            ),
            (
                result["view_names"]["AS"],
                f"{identity} — AS (avondspits)",
                False,
            ),
        ]

        loaded_layers = []
        for layer_name, display_name, visible in definitions:
            layer = QgsVectorLayer(
                f"{result['output_path']}|layername={layer_name}",
                display_name,
                "ogr",
            )
            if not layer.isValid():
                continue
            layer.setCustomProperty(self.SCRIPT_PROPERTY, "gmzip_loadnet")
            layer.setCustomProperty("rws_toolbar/gmzip_path", str(zip_path))
            layer.setRenderer(self._renderer({"color": "#154273", "width": 0.45}))
            project.addMapLayer(layer, False)
            node = group.addLayer(layer)
            node.setItemVisibilityChecked(visible)
            loaded_layers.append(layer)

        if not loaded_layers:
            root.removeChildNode(group)
            return []

        group.setExpanded(True)
        group.setItemVisibilityChecked(True)
        combined_layer = loaded_layers[0]
        if hasattr(self.iface, "setActiveLayer"):
            self.iface.setActiveLayer(combined_layer)
        self._zoom_to_layers([combined_layer])
        self.iface.mapCanvas().refresh()
        return loaded_layers

    def create_difference_network(self):
        candidate_layers = self._candidate_difference_layers()
        dialog = DifferenceNetworkDialog(candidate_layers, self.iface.mainWindow())
        if _exec_dialog(dialog) != DIALOG_ACCEPTED:
            return

        selection_1 = dialog.selected_network_1()
        selection_2 = dialog.selected_network_2()
        output_path = dialog.selected_output_path()
        if selection_1 is None or selection_2 is None:
            self._warn(
                "Netwerken ontbreken",
                "Kies netwerk 1 en netwerk 2, als geopende laag of als bestand van schijf.",
            )
            return
        if output_path is None:
            self._warn("Uitvoer ontbreekt", "Kies waar het verschilnetwerk moet worden opgeslagen.")
            return
        for selection in (selection_1, selection_2):
            if selection["kind"] == "file" and Path(selection["path"]).resolve() == output_path.resolve():
                self._warn(
                    "Uitvoer overschrijft invoer",
                    "Kies een ander GeoPackage voor de uitvoer dan een van de invoernetwerken.",
                )
                return

        layer_1 = self._load_difference_source_layer(selection_1, "Netwerk 1")
        if layer_1 is None:
            return
        layer_2 = self._load_difference_source_layer(selection_2, "Netwerk 2")
        if layer_2 is None:
            return

        progress = QProgressDialog(
            "Verschilnetwerk voorbereiden...",
            "Annuleren",
            0,
            max(1, layer_1.featureCount() + layer_2.featureCount()),
            self.iface.mainWindow(),
        )
        progress.setWindowTitle("Verschilnetwerk")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setAutoClose(False)
        progress.show()
        QCoreApplication.processEvents()

        def update_progress(label, value, total):
            progress.setMaximum(max(1, int(total)))
            progress.setLabelText(label)
            progress.setValue(int(value))
            QCoreApplication.processEvents()

        try:
            result = create_difference_geopackage(
                layer_1,
                layer_2,
                output_path,
                selection_1["label"],
                selection_2["label"],
                progress_callback=update_progress,
                cancel_callback=progress.wasCanceled,
            )
        except DifferenceNetworkCancelled:
            progress.close()
            self._info(
                "Verschilnetwerk geannuleerd",
                "Er is geen verschilnetwerk toegevoegd.",
            )
            return
        except Exception as exc:
            progress.close()
            self._warn("Verschilnetwerk niet gemaakt", str(exc))
            return

        progress.setLabelText("Verschilnetwerk laden...")
        QCoreApplication.processEvents()
        layer = QgsVectorLayer(
            f"{result['output_path']}|layername={result['layer_name']}",
            f"Verschilnetwerk - {selection_1['label']} min {selection_2['label']}",
            "ogr",
        )
        progress.close()
        if not layer.isValid():
            self._warn(
                "Verschilnetwerk gemaakt, maar niet geladen",
                f"Het bestand staat op {result['output_path']}.",
            )
            return

        layer.setCustomProperty(self.SCRIPT_PROPERTY, "difference_network")
        layer.setRenderer(self._renderer({"color": "#154273", "width": 0.55}))
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        group = QgsLayerTreeGroup(f"Verschilnetwerk - {selection_1['label']} min {selection_2['label']}")
        group.setCustomProperty(self.SCRIPT_PROPERTY, "difference_network")
        root.insertChildNode(0, group)
        project.addMapLayer(layer, False)
        group.addLayer(layer).setItemVisibilityChecked(True)
        group.setExpanded(True)
        if hasattr(self.iface, "setActiveLayer"):
            self.iface.setActiveLayer(layer)
        self._zoom_to_layers([layer])
        self.iface.mapCanvas().refresh()

        self._info(
            "Verschilnetwerk gemaakt",
            (
                f"{result['matched']} links gematcht, "
                f"{result['only_1']} alleen in netwerk 1, "
                f"{result['only_2']} alleen in netwerk 2. "
                f"Uitkomst is netwerk 1 min netwerk 2."
            ),
        )

    def _candidate_difference_layers(self):
        layers = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer is None or layer.type() != QgsMapLayer.VectorLayer:
                continue
            if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.LineGeometry:
                continue
            layers.append(layer)
        return sorted(layers, key=lambda item: item.name().casefold())

    def _load_difference_source_layer(self, selection, label):
        if selection["kind"] == "layer":
            layer = QgsProject.instance().mapLayer(selection["layer_id"])
            if layer is None or not layer.isValid():
                self._warn(f"{label} niet gevonden", "De gekozen QGIS-laag bestaat niet meer.")
                return None
            return layer

        path = selection["path"]
        if not path.exists():
            self._warn(f"{label} ontbreekt", f"Bestand niet gevonden: {path}")
            return None
        layer_name = selection.get("layer_name")
        source = f"{path}|layername={layer_name}" if layer_name else str(path)
        layer = QgsVectorLayer(source, selection["label"], "ogr")
        if not layer.isValid():
            self._warn(
                f"{label} niet geladen",
                f"De laag kon niet worden geopend uit {path.name}.",
            )
            return None
        if not layer.crs().isValid() and self._layer_extent_looks_like_rd(layer):
            layer.setCrs(QgsCoordinateReferenceSystem("EPSG:28992"))
        return layer

    def _add_category_layers(
        self,
        project,
        group,
        source_layer,
        field,
        definition,
        visualisation_key,
    ):
        categories = self._matching_categories(source_layer, field, definition)
        if visualisation_key == "ic_ratio":
            categories.sort(key=lambda c: c.get("width", 0), reverse=True)
        elif visualisation_key in self.LOADED_NETWORK_VISUALISATIONS:
            # The first tree layer is drawn last, above all following layers.
            def priority(category):
                color = QColor(category["color"])
                hue = color.hue()
                if color.saturation() < 40:
                    rank = 0
                elif hue < 25 or hue >= 330:
                    rank = 4
                elif hue < 45:
                    rank = 3
                elif hue < 75:
                    rank = 2
                else:
                    rank = 1
                return rank, category.get("width", 0)
            categories.sort(key=priority, reverse=True)
        else:
            # Wide thematic lines precede thin orientation/background layers.
            categories.sort(key=lambda c: (QColor(c["color"]).saturation() >= 40, c.get("width", 0)), reverse=True)
        created = 0
        failed = []

        for category in categories:
            filter_expression = self._combined_subset(
                source_layer,
                self._category_clause(field, category),
            )
            visual_layer = self._category_layer(source_layer, category["label"], filter_expression)
            if not visual_layer.isValid():
                failed.append(category["label"])
                continue

            render_category = {**definition.get("symbol_defaults", {}), **category}
            if visualisation_key.endswith("_delta") and 180 <= QColor(category["color"]).hue() <= 270:
                render_category["opacity"] = min(render_category.get("opacity", 1.0), 0.65)
            visual_layer.setRenderer(self._renderer(render_category))
            visual_layer.setCrs(source_layer.crs())
            visual_layer.setCustomProperty(self.VISUALISATION_PROPERTY, visualisation_key)
            visual_layer.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())

            project.addMapLayer(visual_layer, False)
            layer_node = group.addLayer(visual_layer)
            layer_node.setItemVisibilityChecked(True)
            layer_node.setCustomProperty("showFeatureCount", True)
            visual_layer.countSymbolFeatures()
            created += 1

        return created, failed

    def _category_layer(self, source_layer, layer_name, filter_expression):
        if source_layer.providerType() == "memory":
            return self._memory_category_layer(source_layer, layer_name, filter_expression)

        visual_layer = QgsVectorLayer(
            source_layer.source(),
            layer_name,
            source_layer.providerType(),
        )
        if visual_layer.isValid():
            if not visual_layer.setSubsetString(filter_expression):
                return QgsVectorLayer()
        return visual_layer

    def _memory_category_layer(self, source_layer, layer_name, filter_expression):
        memory_layer = QgsVectorLayer(
            QgsWkbTypes.displayString(source_layer.wkbType()),
            layer_name,
            "memory",
        )
        memory_layer.setCrs(source_layer.crs())
        provider = memory_layer.dataProvider()
        provider.addAttributes(source_layer.fields())
        memory_layer.updateFields()

        request = QgsFeatureRequest().setFilterExpression(filter_expression)
        features = []
        for source_feature in source_layer.getFeatures(request):
            feature = QgsFeature(memory_layer.fields())
            feature.setGeometry(source_feature.geometry())
            feature.setAttributes(source_feature.attributes())
            features.append(feature)

            if len(features) >= 1000:
                provider.addFeatures(features)
                features = []

        if features:
            provider.addFeatures(features)

        memory_layer.updateExtents()
        return memory_layer

    def _shape_key_fields(self, layer):
        a_field = self._find_first_field(layer, ["A"])
        b_field = self._find_first_field(layer, ["B"])
        if a_field is None or b_field is None:
            return None
        return a_field, b_field

    def _cube_net_csv_path(self, net_path):
        return net_path.with_name(f"{net_path.stem}{self.CUBE_CSV_SUFFIX}")

    def _cube_net_schema_path(self, net_path):
        return net_path.with_name(f"{net_path.stem}{self.CUBE_SCHEMA_SUFFIX}")

    def _cube_import_fields(self, metadata):
        net_fields = metadata.get("fields") or []
        available = {field.upper(): field for field in net_fields}
        fields = ["A", "B"]
        for wanted in self.NET_IMPORT_FIELDS:
            field = available.get(wanted.upper())
            if field is not None and field not in fields and self._is_cube_numeric_field(field):
                fields.append(field)
        return fields

    def _cube_net_metadata(self, net_path):
        data = net_path.read_bytes()
        text_head = data[:4096].decode("latin-1", errors="ignore")
        metadata = {
            "links": None,
            "nodes": None,
            "zones": None,
            "noderecs": None,
            "fields": [],
        }

        for key in ("Zones", "Nodes", "Links", "NodeRecs"):
            match = re.search(rf"{key}=([0-9]+)", text_head)
            if match:
                metadata[key.casefold()] = int(match.group(1))

        lvr_index = data.find(b"LVR ")
        nod_index = data.find(b"NOD\x00", lvr_index if lvr_index >= 0 else 0)
        if lvr_index >= 0 and nod_index > lvr_index:
            first_null = data.find(b"\x00", lvr_index)
            names_blob = data[first_null + 1 : max(first_null + 1, nod_index - 4)]
            fields = []
            for raw_name in names_blob.split(b"\x00"):
                if not raw_name:
                    continue
                name = raw_name.decode("latin-1", errors="ignore").strip()
                if name:
                    fields.append(name)
            metadata["fields"] = fields

        return metadata

    def _read_cube_net_links(self, net_path, metadata):
        data = net_path.read_bytes()
        field_names = metadata.get("fields") or []
        if not field_names:
            raise ValueError("geen linkveldnamen gevonden in de .NET-header")

        field_lookup = {field.upper(): index for index, field in enumerate(field_names)}
        if "A" not in field_lookup or "B" not in field_lookup:
            raise ValueError("sleutelvelden A en B ontbreken in de .NET-linktabel")

        import_fields = [
            field
            for field in self._cube_import_fields(metadata)
            if field.upper() not in {"A", "B"}
        ]
        wanted_indexes = {
            field_lookup["A"]: "A",
            field_lookup["B"]: "B",
        }
        for field in import_fields:
            wanted_indexes[field_lookup[field.upper()]] = field
        stop_index = max(wanted_indexes)

        lnk_index = data.find(b"LNK\x00")
        if lnk_index < 0:
            raise ValueError("LNK-sectie ontbreekt in het .NET-bestand")
        position = lnk_index + 4
        link_total = metadata.get("links")
        if link_total is None:
            raise ValueError("aantal links ontbreekt in de .NET-header")

        net_rows = {}
        duplicates = 0
        total = 0

        for _ in range(link_total):
            record_length, record_start = self._cube_record_payload(data, position)
            record_end = record_start + record_length
            if record_end > len(data):
                raise ValueError("linkrecord loopt voorbij het einde van het .NET-bestand")

            values = {}
            cursor = record_start
            for field_index, field_name in enumerate(field_names[: stop_index + 1]):
                value, cursor = self._decode_cube_number(data, cursor)
                if field_index in wanted_indexes:
                    values[wanted_indexes[field_index]] = self._normalise_optional_number(value)

            if cursor > record_end:
                raise ValueError("linkrecord kon niet consistent worden gelezen")

            key = self._net_row_key(values)
            total += 1
            if key is not None:
                if key in net_rows:
                    duplicates += 1
                else:
                    net_rows[key] = {
                        field: values.get(field)
                        for field in import_fields
                    }

            position = record_end

        return net_rows, import_fields, total, duplicates

    def _cube_record_payload(self, data, position):
        prefix = data[position]
        if prefix < 0x80:
            return prefix, position + 1
        if 0x80 <= prefix <= 0x8F:
            return (prefix - 0x80) * 256 + data[position + 1], position + 2
        raise ValueError(f"onbekende recordlengte-code 0x{prefix:02x}")

    def _decode_cube_number(self, data, position):
        code = data[position]
        if code <= 0x3F:
            return code, position + 1
        if 0x48 <= code <= 0x4F:
            return ((code & 0x0F) - 8) * 256 + data[position + 1], position + 2
        if 0x50 <= code <= 0x57:
            return (code & 0x0F) * 65536 + data[position + 1] + data[position + 2] * 256, position + 3
        if code == 0x58:
            return (
                data[position + 1] + data[position + 2] * 256 + data[position + 3] * 65536,
                position + 4,
            )
        if 0x60 <= code <= 0x67:
            return code - 0x80, position + 1
        if 0x68 <= code <= 0x6F:
            return -(((code & 0x07) * 256) + data[position + 1]), position + 2
        if 0x70 <= code <= 0x77:
            return (
                -(((code & 0x07) * 65536) + data[position + 1] + data[position + 2] * 256),
                position + 3,
            )
        if code == 0x78:
            return (
                -(data[position + 1] + data[position + 2] * 256 + data[position + 3] * 65536),
                position + 4,
            )
        if 0x90 <= code <= 0x93:
            byte_count = code - 0x90 + 1
            return (
                int.from_bytes(data[position + 1 : position + 1 + byte_count], "little") / 10.0,
                position + 1 + byte_count,
            )
        if 0x94 <= code <= 0x97:
            byte_count = code - 0x94 + 1
            return (
                int.from_bytes(data[position + 1 : position + 1 + byte_count], "little") / 100.0,
                position + 1 + byte_count,
            )
        if 0x98 <= code <= 0x9B:
            byte_count = code - 0x98 + 1
            return (
                int.from_bytes(data[position + 1 : position + 1 + byte_count], "little") / 1000.0,
                position + 1 + byte_count,
            )
        if 0x9C <= code <= 0x9F:
            byte_count = code - 0x9C + 1
            return (
                int.from_bytes(data[position + 1 : position + 1 + byte_count], "little") / 10000.0,
                position + 1 + byte_count,
            )
        if code == 0x88:
            return struct.unpack("<d", data[position + 1 : position + 9])[0], position + 9
        if code == 0xA4:
            return struct.unpack("<f", data[position + 1 : position + 5])[0], position + 5
        if code == 0xC0:
            return None, position + 1
        raise ValueError(f"onbekende .NET-waarde-code 0x{code:02x}")

    def _net_row_key(self, values):
        a_value = self._optional_int(values.get("A"))
        b_value = self._optional_int(values.get("B"))
        if a_value is None or b_value is None:
            return None
        return a_value, b_value

    def _optional_int(self, value):
        if value is None:
            return None
        return int(value)

    def _normalise_optional_number(self, value):
        if value is None:
            return None
        return self._normalise_number(value)

    def _create_net_link_layer(
        self,
        source_layer,
        key_fields,
        net_path,
        metadata,
        net_rows,
        import_fields,
        net_total,
        duplicates,
    ):
        source_field_names = source_layer.fields().names()
        import_fields = [
            field
            for field in import_fields
            if field.upper() not in {"A", "B"} and field not in source_field_names
        ]

        geometry_name = QgsWkbTypes.displayString(source_layer.wkbType())
        memory_layer = QgsVectorLayer(geometry_name, f"{net_path.stem} gekoppeld", "memory")
        memory_layer.setCrs(source_layer.crs())
        provider = memory_layer.dataProvider()
        provider.addAttributes(source_layer.fields())
        provider.addAttributes([QgsField(field, QVariant.Double) for field in import_fields])
        memory_layer.updateFields()

        output_features = []
        matched = 0
        used_keys = set()

        for source_feature in source_layer.getFeatures():
            key = self._feature_ab_key(source_feature, key_fields)
            net_values = net_rows.get(key)
            feature = QgsFeature(memory_layer.fields())
            feature.setGeometry(source_feature.geometry())
            attributes = list(source_feature.attributes())

            if net_values is not None:
                matched += 1
                used_keys.add(key)
                attributes.extend(net_values.get(field) for field in import_fields)
            else:
                attributes.extend([None] * len(import_fields))

            feature.setAttributes(attributes)
            output_features.append(feature)

            if len(output_features) >= 1000:
                provider.addFeatures(output_features)
                output_features = []

        if output_features:
            provider.addFeatures(output_features)

        memory_layer.updateExtents()
        memory_layer.setCustomProperty(self.SCRIPT_PROPERTY, "cube_net_link")
        memory_layer.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
        memory_layer.setCustomProperty("rws_toolbar/net_path", str(net_path))
        memory_layer.setRenderer(self._renderer({"color": "#154273", "width": 0.45}))

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(source_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)
        project.addMapLayer(memory_layer, False)
        layer_node = parent_node.insertLayer(insert_index, memory_layer)
        layer_node.setItemVisibilityChecked(True)
        if source_node is not None:
            source_node.setItemVisibilityChecked(False)
        if hasattr(self.iface, "setActiveLayer"):
            self.iface.setActiveLayer(memory_layer)

        self.iface.mapCanvas().refresh()

        return {
            "shape_total": source_layer.featureCount(),
            "net_total": net_total,
            "net_header_total": metadata.get("links"),
            "matched": matched,
            "unmatched_shape": source_layer.featureCount() - matched,
            "unused_net": len(set(net_rows) - used_keys),
            "duplicate_net": duplicates,
        }

    def _candidate_network_layers_for_inweva(self):
        layers = []
        seen = set()

        active_layer = self.iface.activeLayer()
        if self._is_inweva_network_candidate(active_layer):
            layers.append(active_layer)
            seen.add(active_layer.id())

        for layer in QgsProject.instance().mapLayers().values():
            if layer.id() in seen or not self._is_inweva_network_candidate(layer):
                continue
            layers.append(layer)
            seen.add(layer.id())

        return layers

    def _is_inweva_network_candidate(self, layer):
        if layer is None or layer.type() != QgsMapLayer.VectorLayer:
            return False
        if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.LineGeometry:
            return False
        if layer.customProperty(self.INWEVA_PROPERTY) or layer.customProperty(self.ZONE_PROPERTY):
            return False
        return True

    def _load_inweva_source_layer(self, inweva_key):
        definition = self.INWEVA_LAYERS[inweva_key]
        if not self.INWEVA_DATA_PATH.exists():
            self._warn(
                "INWEVA-bestand ontbreekt",
                f"Het GeoPackage is niet gevonden: {self.INWEVA_DATA_PATH.name}.",
            )
            return None

        layer = QgsVectorLayer(
            f"{self.INWEVA_DATA_PATH}|layername={definition['layer_name']}",
            f"INWEVA 2025 - {definition['label']}",
            "ogr",
        )
        if not layer.isValid():
            self._warn(
                "INWEVA niet geladen",
                f"De laag '{definition['layer_name']}' kon niet worden geladen uit {self.INWEVA_DATA_PATH.name}.",
            )
            return None
        return layer

    def _create_inweva_link_layer(self, network_layer, network_id_field, inweva_layer, inweva_key):
        inweva_definition = self.INWEVA_LAYERS[inweva_key]
        if network_layer.fields().lookupField(network_id_field) < 0:
            self._warn("ID-veld ontbreekt", f"Het veld '{network_id_field}' bestaat niet in de netwerklaag.")
            return None

        inweva_id_field = self._find_first_field(inweva_layer, ["WVK_IDS", "WVK_ID"])
        if inweva_id_field is None:
            self._warn(
                "WVK_IDS ontbreekt",
                "De gekozen INWEVA-laag heeft geen veld WVK_IDS om op te koppelen.",
            )
            return None

        inweva_total = max(0, inweva_layer.featureCount())
        network_total = max(0, network_layer.featureCount())
        progress_max = inweva_total + network_total
        progress = QProgressDialog(
            "INWEVA-index opbouwen...",
            "Annuleren",
            0,
            progress_max,
            self.iface.mainWindow(),
        )
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.show()
        QCoreApplication.processEvents()

        try:
            inweva_index = build_inweva_index(
                inweva_layer,
                inweva_id_field.name(),
                progress_callback=lambda value: self._set_progress(progress, value),
                cancel_callback=progress.wasCanceled,
            )
            if progress.wasCanceled():
                return None
            if not inweva_index.candidates:
                self._warn(
                    "Geen INWEVA IDs",
                    f"Het veld '{inweva_id_field.name()}' bevat geen bruikbare WVK_ID-verwijzingen.",
                )
                return None

            geometry_name = QgsWkbTypes.displayString(network_layer.wkbType())
            layer_name = f"{network_layer.name()} + INWEVA 2025 {inweva_definition['label']}"
            memory_layer = QgsVectorLayer(geometry_name, layer_name, "memory")
            memory_layer.setCrs(network_layer.crs())
            provider = memory_layer.dataProvider()
            provider.addAttributes(network_layer.fields())
            inweva_output_fields = self._inweva_output_fields(
                network_layer.fields(),
                inweva_layer.fields(),
            )
            provider.addAttributes(inweva_output_fields)
            memory_layer.updateFields()

            output_features = []
            matched = 0
            used_inweva_ids = set()
            processed_network = 0
            directional_matches = 0

            progress.setLabelText("Netwerklinks koppelen...")
            for network_feature in network_layer.getFeatures():
                key, candidate, directional = match_inweva_candidate(
                    network_feature,
                    network_id_field,
                    inweva_index,
                )
                if candidate is None:
                    processed_network += 1
                    if processed_network % 500 == 0:
                        self._set_progress(progress, inweva_total + processed_network)
                        if progress.wasCanceled():
                            return None
                    continue

                feature = QgsFeature(memory_layer.fields())
                feature.setGeometry(network_feature.geometry())
                attributes = list(network_feature.attributes())
                attributes.extend(candidate.attributes)
                feature.setAttributes(attributes)
                output_features.append(feature)
                matched += 1
                directional_matches += int(directional)
                used_inweva_ids.add(key)

                if len(output_features) >= 1000:
                    provider.addFeatures(output_features)
                    output_features = []

                processed_network += 1
                if processed_network % 500 == 0:
                    self._set_progress(progress, inweva_total + processed_network)
                    if progress.wasCanceled():
                        return None

            if output_features:
                provider.addFeatures(output_features)

            memory_layer.updateExtents()
            if matched == 0:
                return {
                    "layer_name": memory_layer.name(),
                    "network_total": network_total,
                    "inweva_feature_total": inweva_total,
                    "inweva_id_total": inweva_index.reference_count,
                    "matched": 0,
                    "unmatched_network": network_total,
                    "unused_inweva_ids": len(inweva_index.candidates),
                    "duplicate_inweva_ids": inweva_index.duplicate_references,
                    "directional_matches": 0,
                    "removed_existing": 0,
                }

            memory_layer.setCustomProperty(self.INWEVA_PROPERTY, True)
            memory_layer.setCustomProperty(self.INWEVA_KEY_PROPERTY, f"linked:{inweva_key}")
            memory_layer.setCustomProperty(self.INWEVA_LINK_PROPERTY, True)
            memory_layer.setCustomProperty(self.SOURCE_PROPERTY, network_layer.id())
            memory_layer.setCustomProperty("rws_toolbar/inweva_source", inweva_definition["layer_name"])
            memory_layer.setRenderer(self._renderer({"color": "#154273", "width": 0.55}))

            removed_existing = self._remove_existing_inweva_link_layers(network_layer, inweva_key)

            project = QgsProject.instance()
            root = project.layerTreeRoot()
            source_node = root.findLayer(network_layer.id())
            parent_node, insert_index = self._target_parent_and_index(root, source_node)
            project.addMapLayer(memory_layer, False)
            layer_node = parent_node.insertLayer(insert_index, memory_layer)
            layer_node.setItemVisibilityChecked(True)
            if source_node is not None:
                source_node.setItemVisibilityChecked(False)
            if hasattr(self.iface, "setActiveLayer"):
                self.iface.setActiveLayer(memory_layer)

            progress.setValue(progress_max)
            self.iface.mapCanvas().refresh()

            return {
                "layer_name": memory_layer.name(),
                "network_total": network_total,
                "inweva_feature_total": inweva_total,
                "inweva_id_total": inweva_index.reference_count,
                "matched": matched,
                "unmatched_network": network_total - matched,
                "unused_inweva_ids": len(set(inweva_index.candidates) - used_inweva_ids),
                "duplicate_inweva_ids": inweva_index.duplicate_references,
                "directional_matches": directional_matches,
                "removed_existing": removed_existing,
            }
        finally:
            progress.close()

    def _inweva_split_network_fields(self, network_layer):
        id_field = self._find_first_field(network_layer, ["WVK_ID"])
        node_a_field = self._find_first_field(network_layer, ["KnoopA", "KNOOPA", "A"])
        node_b_field = self._find_first_field(network_layer, ["KnoopB", "KNOOPB", "B"])
        if id_field is None or node_a_field is None or node_b_field is None:
            return None
        return {
            "WVK_ID": id_field.name(),
            "KnoopA": node_a_field.name(),
            "KnoopB": node_b_field.name(),
        }

    def _create_split_inweva_layer(
        self,
        network_layer,
        network_fields,
        inweva_layer,
        inweva_key,
        inweva_index,
        progress,
        progress_offset,
    ):
        definition = self.INWEVA_LAYERS[inweva_key]
        layer_name = f"INWEVA 2025 - {definition['label']} - gesplitst"
        geometry_name = QgsWkbTypes.displayString(network_layer.wkbType())
        memory_layer = QgsVectorLayer(geometry_name, layer_name, "memory")
        memory_layer.setCrs(network_layer.crs())
        provider = memory_layer.dataProvider()

        identifier_fields = []
        for output_name in ("WVK_ID", "KnoopA", "KnoopB"):
            source_name = network_fields[output_name]
            output_field = QgsField(network_layer.fields().field(source_name))
            output_field.setName(output_name)
            identifier_fields.append(output_field)
        provider.addAttributes(identifier_fields)
        provider.addAttributes(
            self._inweva_output_fields(identifier_fields, inweva_layer.fields())
        )
        memory_layer.updateFields()

        output_features = []
        matched = 0
        directional_matches = 0
        used_inweva_ids = set()
        processed = 0

        for network_feature in network_layer.getFeatures():
            link_id, candidate, directional = match_inweva_candidate(
                network_feature,
                network_fields["WVK_ID"],
                inweva_index,
            )
            if candidate is not None:
                feature = QgsFeature(memory_layer.fields())
                feature.setGeometry(network_feature.geometry())
                feature.setAttributes(
                    [
                        network_feature[network_fields["WVK_ID"]],
                        network_feature[network_fields["KnoopA"]],
                        network_feature[network_fields["KnoopB"]],
                        *candidate.attributes,
                    ]
                )
                output_features.append(feature)
                matched += 1
                directional_matches += int(directional)
                used_inweva_ids.add(link_id)

                if len(output_features) >= 1000:
                    provider.addFeatures(output_features)
                    output_features = []

            processed += 1
            if processed % 500 == 0:
                self._set_progress(progress, progress_offset + processed)
                if progress.wasCanceled():
                    return None

        if output_features:
            provider.addFeatures(output_features)

        memory_layer.updateExtents()
        memory_layer.setCustomProperty(self.INWEVA_PROPERTY, True)
        memory_layer.setCustomProperty(self.INWEVA_KEY_PROPERTY, f"split:{inweva_key}")
        memory_layer.setCustomProperty(self.INWEVA_SPLIT_PROPERTY, True)
        memory_layer.setCustomProperty(self.SOURCE_PROPERTY, network_layer.id())
        memory_layer.setCustomProperty(
            "rws_toolbar/inweva_source",
            definition["layer_name"],
        )
        memory_layer.setRenderer(self._inweva_renderer(inweva_key))
        memory_layer.setDisplayExpression('"WVK_ID"')

        return {
            "key": inweva_key,
            "label": definition["label"],
            "layer": memory_layer,
            "matched": matched,
            "unmatched_network": int(network_layer.featureCount()) - matched,
            "directional_matches": directional_matches,
            "unused_inweva_ids": len(set(inweva_index.candidates) - used_inweva_ids),
        }

    def _add_inweva_split_group(self, network_layer, results):
        removed = self._remove_existing_inweva_split_groups(network_layer)
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(network_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)
        group = QgsLayerTreeGroup(f"INWEVA 2025 gesplitst - {network_layer.name()}")
        group.setCustomProperty(self.INWEVA_SPLIT_PROPERTY, True)
        group.setCustomProperty(self.SOURCE_PROPERTY, network_layer.id())
        parent_node.insertChildNode(insert_index, group)

        loaded_layers = []
        for index, result in enumerate(results):
            layer = result["layer"]
            project.addMapLayer(layer, False)
            layer_node = group.addLayer(layer)
            layer_node.setItemVisibilityChecked(index == 0)
            loaded_layers.append(layer)

        group.setExpanded(True)
        group.setItemVisibilityChecked(True)
        if source_node is not None:
            source_node.setItemVisibilityChecked(False)
        if loaded_layers and hasattr(self.iface, "setActiveLayer"):
            self.iface.setActiveLayer(loaded_layers[0])
        if loaded_layers:
            self._zoom_to_layers([loaded_layers[0]])
        self.iface.mapCanvas().refresh()
        return removed

    def _set_progress(self, progress, value):
        progress.setValue(int(value))
        QCoreApplication.processEvents()

    def _inweva_output_fields(self, network_fields, inweva_fields):
        existing = {field.name().casefold() for field in network_fields}
        output_fields = []

        for inweva_field in inweva_fields:
            original_name = inweva_field.name()
            if original_name.casefold() in existing:
                output_name = f"INW_{original_name}"
            else:
                output_name = original_name
            output_name = self._unique_output_field_name(output_name, existing)
            existing.add(output_name.casefold())

            output_field = QgsField(inweva_field)
            output_field.setName(output_name)
            output_fields.append(output_field)

        return output_fields

    def _unique_output_field_name(self, base_name, existing):
        candidate = base_name
        counter = 2
        while candidate.casefold() in existing:
            candidate = f"{base_name}_{counter}"
            counter += 1
        return candidate

    def _read_net_link_csv(self, csv_path, schema_path=None):
        net_rows = {}
        duplicates = 0
        total = 0

        schema_fields = self._read_net_link_schema(schema_path)
        with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            sample = handle.read(4096)
            handle.seek(0)
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            reader = csv.DictReader(handle, dialect=dialect)
            if reader.fieldnames is None:
                raise ValueError("CSV heeft geen headerregel met veldnamen.")

            field_map = {field.upper(): field for field in reader.fieldnames if field is not None}
            if "A" not in field_map or "B" not in field_map:
                if not schema_fields:
                    raise ValueError("CSV mist de sleutelvelden A en B en er is geen schema naast de CSV.")
                handle.seek(0)
                reader = csv.DictReader(handle, fieldnames=schema_fields, dialect=dialect)
                field_map = {field.upper(): field for field in schema_fields}

            import_fields = self._csv_import_fields(reader.fieldnames)
            for row in reader:
                key = self._row_ab_key(row, field_map)
                if key is None:
                    continue
                total += 1
                if key in net_rows:
                    duplicates += 1
                    continue
                net_rows[key] = {
                    field: self._csv_number(row.get(field))
                    for field in import_fields
                }

        return net_rows, import_fields, total, duplicates

    def _read_net_link_schema(self, schema_path):
        if schema_path is None or not schema_path.exists():
            return []
        try:
            payload = json.loads(schema_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        return [
            field
            for field in payload.get("fields", [])
            if isinstance(field, str) and field.strip()
        ]

    def _csv_import_fields(self, fieldnames):
        available = {field.upper(): field for field in fieldnames if field is not None}
        fields = []
        for wanted in self.NET_IMPORT_FIELDS:
            field = available.get(wanted.upper())
            if field is not None and field.upper() not in {"A", "B"} and field not in fields:
                fields.append(field)
        return fields

    def _row_ab_key(self, row, field_map):
        a_value = self._csv_int(row.get(field_map["A"]))
        b_value = self._csv_int(row.get(field_map["B"]))
        if a_value is None or b_value is None:
            return None
        return a_value, b_value

    def _feature_ab_key(self, feature, key_fields):
        return int(feature[key_fields[0].name()]), int(feature[key_fields[1].name()])

    def _csv_int(self, value):
        number = self._csv_number(value)
        if number is None:
            return None
        return int(number)

    def _csv_number(self, value):
        if value is None:
            return None
        text = str(value).strip()
        if not text:
            return None
        text = text.replace(",", ".")
        try:
            return self._normalise_number(float(text))
        except ValueError:
            return None

    def _is_cube_numeric_field(self, name):
        if "=" in name:
            return False
        return bool(re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name))

    def choose_projects(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        if source_layer is None:
            return

        field = self._find_first_field(source_layer, self.PROJECT_FIELD_NAMES)
        if field is None:
            self._warn(
                "Projectveld niet gevonden",
                "De actieve laag heeft geen veld 'Project' of 'PROJECT'.",
            )
            return

        codes = self._project_codes_in_layer(source_layer, field)
        if not codes:
            self._warn(
                "Geen projecten gevonden",
                "In de actieve laag staan geen projectcodes in het Project-veld.",
            )
            return

        catalog, catalog_meta = self._load_project_catalog()
        project_rows = [self._project_row(code, catalog) for code in codes]
        dialog = ProjectSelectionDialog(project_rows, catalog_meta, self.iface.mainWindow())
        if _exec_dialog(dialog) != DIALOG_ACCEPTED:
            return

        selected_codes = dialog.selected_project_codes()
        if not selected_codes:
            self._warn("Geen projecten geselecteerd", "Selecteer eerst een of meer projectregels.")
            return

        selected_projects = [row for row in project_rows if row["code"] in selected_codes]
        self._create_project_layers(source_layer, field, selected_projects)

    def remove_project_layers(self):
        source_layer = self._selected_source_layer(allow_visual_layer=True)
        removed = self._remove_existing_project_groups(source_layer)
        self.iface.mapCanvas().refresh()

        if removed:
            self._info("Projectlagen verwijderd", f"{removed} projectgroep(en) verwijderd.")
        else:
            self._info(
                "Geen projectlagen",
                "Er zijn geen RWS projectlagen gevonden voor de actieve laag.",
            )

    def _create_project_layers(self, source_layer, field, selected_projects):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_node = root.findLayer(source_layer.id())
        parent_node, insert_index = self._target_parent_and_index(root, source_node)

        removed = self._remove_existing_project_groups(source_layer)
        self._hide_other_visualisation_groups(source_layer, None)

        group = parent_node.insertGroup(insert_index, self.PROJECT_GROUP_NAME)
        group.setCustomProperty(self.PROJECT_PROPERTY, True)
        group.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())
        group.setExpanded(True)
        group.setItemVisibilityChecked(True)

        created = 0
        created_layers = []
        failed = []
        for index, project_row in enumerate(selected_projects):
            style = self._project_style(index)
            layer_name = self._project_layer_name(project_row)
            project_layer = QgsVectorLayer(
                source_layer.source(),
                layer_name,
                source_layer.providerType(),
            )
            if not project_layer.isValid():
                failed.append(layer_name)
                continue

            project_layer.setSubsetString(
                self._combined_subset(source_layer, self._value_clause(field, project_row["code"]))
            )
            project_layer.setRenderer(self._renderer(style))
            project_layer.setCrs(source_layer.crs())
            project_layer.setCustomProperty(self.PROJECT_PROPERTY, True)
            project_layer.setCustomProperty(self.SOURCE_PROPERTY, source_layer.id())

            project.addMapLayer(project_layer, False)
            layer_node = group.addLayer(project_layer)
            layer_node.setItemVisibilityChecked(True)
            layer_node.setCustomProperty("showFeatureCount", True)
            created_layers.append(project_layer)
            created += 1

        if source_node is not None:
            source_node.setItemVisibilityChecked(False)

        zoomed = self._zoom_to_layers(created_layers)

        if failed:
            self._warn(
                "Projectlagen deels aangemaakt",
                f"{created} lagen aangemaakt, {len(failed)} lagen niet. Controleer de databron.",
            )
            return

        suffix = " Oude projectgroep is vervangen." if removed else ""
        self._info(
            "Projectlagen aangemaakt",
            f"{created} projectlaag/lagen staan onder '{self.PROJECT_GROUP_NAME}'. De bronlaag is uitgezet."
            f"{' Ingezoomd op selectie.' if zoomed else ''}{suffix}",
        )

    def _selected_source_layer(self, allow_visual_layer=False):
        layer = self.iface.activeLayer()
        if layer is None:
            self._warn("Geen actieve laag", "Selecteer eerst een netwerkshape in de lagenboom.")
            return None

        if allow_visual_layer and layer.customProperty(self.SOURCE_PROPERTY) and not layer.customProperty(self.SCRIPT_PROPERTY):
            source_layer = QgsProject.instance().mapLayer(layer.customProperty(self.SOURCE_PROPERTY))
            if source_layer is not None:
                return source_layer

        if layer.type() != QgsMapLayer.VectorLayer:
            self._warn("Geen vectorlaag", "Selecteer een lijn-vectorlaag met netwerkvelden.")
            return None

        if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.LineGeometry:
            self._warn("Geen lijnlaag", "Selecteer een netwerkshape met lijngeometrie.")
            return None

        return layer

    def _selected_layers_or_active(self):
        layers = []
        if hasattr(self.iface, "layerTreeView"):
            tree_view = self.iface.layerTreeView()
            if tree_view is not None and hasattr(tree_view, "selectedLayers"):
                layers = [layer for layer in tree_view.selectedLayers() if layer is not None]

        if not layers:
            active_layer = self.iface.activeLayer()
            if active_layer is not None:
                layers = [active_layer]

        unique_layers = []
        seen_ids = set()
        for layer in layers:
            if layer.id() in seen_ids:
                continue
            unique_layers.append(layer)
            seen_ids.add(layer.id())
        return unique_layers

    def _find_openstreetmap_layer(self):
        for layer in QgsProject.instance().mapLayers().values():
            if self._layer_is_openstreetmap(layer):
                return layer
        return None

    def _layer_is_openstreetmap(self, layer):
        name = layer.name().casefold()
        source = layer.source().casefold() if hasattr(layer, "source") else ""
        return (
            "openstreetmap" in name
            or name == "osm"
            or "openstreetmap.org" in source
            or "tile.openstreetmap" in source
        )

    def _openstreetmap_target_crs(self, osm_layer):
        if osm_layer is not None and osm_layer.crs().isValid():
            return osm_layer.crs()
        return QgsCoordinateReferenceSystem("EPSG:3857")

    def _layer_extent_looks_like_rd(self, layer):
        extent = layer.extent()
        center_x = (extent.xMinimum() + extent.xMaximum()) / 2
        center_y = (extent.yMinimum() + extent.yMaximum()) / 2
        return -300000 <= center_x <= 900000 and -300000 <= center_y <= 800000

    def _target_parent_and_index(self, root, source_node):
        if source_node is None:
            return root, 0

        parent_node = source_node.parent() or root
        insert_index = parent_node.children().index(source_node) + 1
        return parent_node, insert_index

    def _remove_existing_visualisation_groups(
        self,
        source_layer,
        visualisation_key=None,
        visualisation_keys=None,
    ):
        if source_layer is None:
            return 0

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_id = source_layer.id()
        matches = []
        key_filter = None
        if visualisation_key is not None:
            key_filter = {visualisation_key}
        elif visualisation_keys is not None:
            key_filter = set(visualisation_keys)

        for group in self._iter_groups(root):
            group_key = group.customProperty(self.VISUALISATION_PROPERTY)
            if key_filter is not None and group_key not in key_filter:
                continue
            if group_key not in self.VISUALISATIONS:
                continue

            group_source_id = group.customProperty(self.SOURCE_PROPERTY)
            if group_source_id == source_id:
                matches.append(group)

        if key_filter is None or "linktypes" in key_filter:
            legacy_name = f"{source_layer.name()} - Linktypes"
            for group in self._iter_groups(root):
                if group in matches:
                    continue
                group_key = group.customProperty(self.VISUALISATION_PROPERTY)
                group_source_id = group.customProperty(self.SOURCE_PROPERTY)
                if key_filter is not None and group_key not in key_filter and group_key:
                    continue
                if group_key == "linktypes" and group_source_id == source_id:
                    matches.append(group)
                elif not group_key and not group_source_id and group.name() == legacy_name:
                    matches.append(group)

        for group in matches:
            parent = group.parent()
            layer_ids = [node.layerId() for node in group.findLayers()]
            for layer_id in layer_ids:
                project.removeMapLayer(layer_id)
            if parent is not None and group in parent.children():
                parent.removeChildNode(group)

        return len(matches)

    def _remove_existing_zone_layers(self, zone_key=None):
        project = QgsProject.instance()
        layer_ids = []

        for layer in project.mapLayers().values():
            if not layer.customProperty(self.ZONE_PROPERTY):
                continue
            if zone_key is not None and layer.customProperty(self.ZONE_KEY_PROPERTY) != zone_key:
                continue
            layer_ids.append(layer.id())

        for layer_id in layer_ids:
            project.removeMapLayer(layer_id)

        return len(layer_ids)

    def _remove_existing_inweva_layers(self, inweva_key=None):
        project = QgsProject.instance()
        layer_ids = []

        for layer in project.mapLayers().values():
            if not layer.customProperty(self.INWEVA_PROPERTY):
                continue
            if inweva_key is not None and layer.customProperty(self.INWEVA_KEY_PROPERTY) != inweva_key:
                continue
            layer_ids.append(layer.id())

        for layer_id in layer_ids:
            project.removeMapLayer(layer_id)

        if inweva_key is None:
            root = project.layerTreeRoot()
            split_groups = [
                group
                for group in self._iter_groups(root)
                if group.customProperty(self.INWEVA_SPLIT_PROPERTY)
            ]
            for group in split_groups:
                parent = group.parent()
                if parent is not None and group in parent.children():
                    parent.removeChildNode(group)

        return len(layer_ids)

    def _remove_existing_inweva_split_groups(self, network_layer):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_id = network_layer.id()
        groups = [
            group
            for group in self._iter_groups(root)
            if group.customProperty(self.INWEVA_SPLIT_PROPERTY)
            and group.customProperty(self.SOURCE_PROPERTY) == source_id
        ]

        for group in groups:
            layer_ids = [node.layerId() for node in group.findLayers()]
            if layer_ids:
                project.removeMapLayers(layer_ids)
            parent = group.parent()
            if parent is not None and group in parent.children():
                parent.removeChildNode(group)
        return len(groups)

    def _remove_existing_inweva_link_layers(self, network_layer, inweva_key):
        project = QgsProject.instance()
        source_id = network_layer.id()
        target_key = f"linked:{inweva_key}"
        layer_ids = []

        for layer in project.mapLayers().values():
            if not layer.customProperty(self.INWEVA_LINK_PROPERTY):
                continue
            if layer.customProperty(self.SOURCE_PROPERTY) != source_id:
                continue
            if layer.customProperty(self.INWEVA_KEY_PROPERTY) != target_key:
                continue
            layer_ids.append(layer.id())

        for layer_id in layer_ids:
            project.removeMapLayer(layer_id)

        return len(layer_ids)

    def _remove_existing_turn_groups(self, source_layer, pen_path=None):
        if source_layer is None:
            return 0

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_id = source_layer.id()
        target_path = str(Path(pen_path).resolve()) if pen_path is not None else None
        matches = []

        for group in self._iter_groups(root):
            if not group.customProperty(self.TURN_PROPERTY):
                continue
            if group.customProperty(self.SOURCE_PROPERTY) != source_id:
                continue
            if (
                target_path is not None
                and group.customProperty(self.TURN_FILE_PROPERTY) != target_path
            ):
                continue
            matches.append(group)

        for group in matches:
            parent = group.parent()
            layer_ids = [node.layerId() for node in group.findLayers()]
            for layer_id in layer_ids:
                project.removeMapLayer(layer_id)
            if parent is not None and group in parent.children():
                parent.removeChildNode(group)

        return len(matches)

    def _remove_existing_roundabout_groups(self, source_layer):
        if source_layer is None:
            return 0

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_id = source_layer.id()
        matches = []

        for group in self._iter_groups(root):
            if not group.customProperty(self.ROUNDABOUT_PROPERTY):
                continue
            if group.customProperty(self.SOURCE_PROPERTY) == source_id:
                matches.append(group)

        for group in matches:
            parent = group.parent()
            layer_ids = [node.layerId() for node in group.findLayers()]
            for layer_id in layer_ids:
                project.removeMapLayer(layer_id)
            if parent is not None and group in parent.children():
                parent.removeChildNode(group)

        return len(matches)

    def _roundabout_layers(self, source_layer):
        source_id = source_layer.id()
        area_layer = None
        link_layer = None

        for layer in QgsProject.instance().mapLayers().values():
            if not layer.customProperty(self.ROUNDABOUT_PROPERTY):
                continue
            if layer.customProperty(self.SOURCE_PROPERTY) != source_id:
                continue
            if layer.fields().indexFromName("rotonde_id") < 0:
                continue

            geometry_type = QgsWkbTypes.geometryType(layer.wkbType())
            if geometry_type == QgsWkbTypes.PolygonGeometry:
                area_layer = layer
            elif geometry_type == QgsWkbTypes.LineGeometry:
                link_layer = layer

        return area_layer, link_layer

    def _ensure_roundabout_control_field(self, layer):
        if layer.fields().indexFromName("controle") >= 0:
            return
        layer.dataProvider().addAttributes([QgsField("controle", QVariant.String)])
        layer.updateFields()

    def _focus_roundabout_candidate(self, area_layer, link_layer, feature, roundabout_id, scale=5.0):
        area_layer.removeSelection()
        area_layer.selectByIds([feature.id()])

        if link_layer is not None:
            link_layer.removeSelection()
            selected_link_ids = [
                link_feature.id()
                for link_feature in link_layer.getFeatures()
                if str(link_feature["rotonde_id"]) == roundabout_id
            ]
            if selected_link_ids:
                link_layer.selectByIds(selected_link_ids)

        extent = feature.geometry().boundingBox()
        extent = self._extent_for_canvas(area_layer, extent)
        if not extent.isNull() and not extent.isEmpty():
            extent.scale(scale)
            canvas = self.iface.mapCanvas()
            canvas.setExtent(extent)
            canvas.refresh()
            QCoreApplication.processEvents()

    def _scale_canvas_extent(self, factor):
        canvas = self.iface.mapCanvas()
        extent = QgsRectangle(canvas.extent())
        if extent.isNull() or extent.isEmpty():
            return
        extent.scale(float(factor))
        canvas.setExtent(extent)
        canvas.refresh()
        QCoreApplication.processEvents()

    def _move_roundabout_dialog_to_top(self, dialog):
        canvas = self.iface.mapCanvas()
        canvas_top_left = canvas.mapToGlobal(canvas.rect().topLeft())
        canvas_width = canvas.width()
        dialog_width = dialog.width()
        x = canvas_top_left.x() + max(20, int((canvas_width - dialog_width) / 2))
        y = canvas_top_left.y() + 18
        dialog.move(x, y)

    def _set_roundabout_control(self, area_layer, link_layer, roundabout_id, value):
        self._set_roundabout_control_for_layer(area_layer, roundabout_id, value)
        if link_layer is not None:
            self._set_roundabout_control_for_layer(link_layer, roundabout_id, value)

    def _set_roundabout_control_for_layer(self, layer, roundabout_id, value):
        control_index = layer.fields().indexFromName("controle")
        id_index = layer.fields().indexFromName("rotonde_id")
        if control_index < 0 or id_index < 0:
            return

        changes = {}
        for feature in layer.getFeatures():
            if str(feature[id_index]) == roundabout_id:
                changes[feature.id()] = {control_index: value}

        if changes:
            layer.dataProvider().changeAttributeValues(changes)
            layer.triggerRepaint()

    def _roundabout_review_sample(self, candidates, limit_per_bucket=10):
        bands = [
            ("<0,4", None, 0.4),
            ("0,4-0,5", 0.4, 0.5),
            ("0,5-0,6", 0.5, 0.6),
            ("0,6-0,7", 0.6, 0.7),
            ("0,7-0,8", 0.7, 0.8),
            ("0,8-0,9", 0.8, 0.9),
            ("0,9-1,0", 0.9, None),
        ]
        advice_ranks = range(7)
        selected = []
        selected_ids = set()
        buckets = []

        for _label, minimum, maximum in bands:
            for advice_rank in advice_ranks:
                bucket = [
                    feature
                    for feature in candidates
                    if self._roundabout_in_compactness_band(feature, minimum, maximum)
                    and self._roundabout_advice_rank(feature) == advice_rank
                ]
                bucket.sort(key=self._roundabout_review_priority)
                if bucket:
                    buckets.append(bucket[:limit_per_bucket])

        for offset in range(limit_per_bucket):
            for bucket in buckets:
                if offset >= len(bucket):
                    continue
                feature = bucket[offset]
                selected.append(feature)
                selected_ids.add(feature.id())

        remainder = [
            feature
            for feature in candidates
            if feature.id() not in selected_ids
        ]
        remainder.sort(key=self._roundabout_review_priority)
        return selected + remainder

    def _roundabout_in_compactness_band(self, feature, minimum, maximum):
        compactness = self._roundabout_feature_number(feature, "compact", None)
        if compactness is None:
            return minimum is None
        if minimum is not None and compactness < minimum:
            return False
        if maximum is not None and compactness >= maximum:
            return False
        return True

    def _roundabout_review_priority(self, feature):
        advice = self._roundabout_feature_text(feature, "advies").casefold()
        score = self._roundabout_feature_number(feature, "score", 1.0)
        compactness = self._roundabout_feature_number(feature, "compact", 1.0)
        bbox_ratio = self._roundabout_feature_number(feature, "bbox_ratio", 1.0)
        attachments = self._roundabout_feature_number(feature, "takknopen", 99)
        shape_score = self._roundabout_feature_number(feature, "vorm", 1.0)
        max_turn = self._roundabout_feature_number(feature, "hoek_max", 0.0)
        sharp_turns = self._roundabout_feature_number(feature, "scherp", 0)
        straight_fraction = self._roundabout_feature_number(feature, "zij_frac", 0.0)
        advice_rank = self._roundabout_advice_rank(feature)

        return (
            advice_rank,
            shape_score,
            -sharp_turns,
            -max_turn,
            -straight_fraction,
            score,
            compactness,
            -bbox_ratio,
            attachments,
            self._roundabout_feature_text(feature, "rotonde_id"),
        )

    def _roundabout_advice_rank(self, feature):
        advice = self._roundabout_feature_text(feature, "advies").casefold()
        if "hoekig" in advice or "scherpe" in advice:
            return 0
        elif "lange zijde" in advice:
            return 1
        elif "compact" in advice:
            return 2
        elif "langwerpig" in advice:
            return 3
        elif "weinig" in advice:
            return 4
        elif "controleer" in advice:
            return 5
        return 6

    def _roundabout_feature_text(self, feature, field_name):
        if feature.fields().indexFromName(field_name) < 0:
            return ""
        value = feature[field_name]
        if value is None:
            return ""
        return str(value)

    def _roundabout_feature_number(self, feature, field_name, default):
        if feature.fields().indexFromName(field_name) < 0:
            return default
        value = feature[field_name]
        if value is None:
            return default
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    def _remove_existing_project_groups(self, source_layer):
        if source_layer is None:
            return 0

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        source_id = source_layer.id()
        matches = []

        for group in self._iter_groups(root):
            if not group.customProperty(self.PROJECT_PROPERTY):
                continue
            if group.customProperty(self.SOURCE_PROPERTY) == source_id:
                matches.append(group)

        for group in matches:
            parent = group.parent()
            layer_ids = [node.layerId() for node in group.findLayers()]
            for layer_id in layer_ids:
                project.removeMapLayer(layer_id)
            if parent is not None and group in parent.children():
                parent.removeChildNode(group)

        return len(matches)

    def _hide_other_visualisation_groups(self, source_layer, active_key):
        root = QgsProject.instance().layerTreeRoot()
        source_id = source_layer.id()
        domain_keys = set(self._visualisation_domain_keys(active_key))
        for group in self._iter_groups(root):
            group_key = group.customProperty(self.VISUALISATION_PROPERTY)
            if group_key not in domain_keys or group_key == active_key:
                continue
            if group.customProperty(self.SOURCE_PROPERTY) == source_id:
                group.setItemVisibilityChecked(False)

    def _visualisation_domain_keys(self, visualisation_key):
        if visualisation_key in self.LOADED_NETWORK_VISUALISATIONS:
            return self.LOADED_NETWORK_VISUALISATIONS
        return self.ATTRIBUTE_VISUALISATIONS

    def _iter_groups(self, group):
        for child in group.children():
            if isinstance(child, QgsLayerTreeGroup):
                yield child
                yield from self._iter_groups(child)

    def _find_first_field(self, layer, wanted_names):
        wanted = {name.casefold() for name in wanted_names}
        for field in layer.fields():
            if field.name().casefold() in wanted:
                return field
        return None

    def _visualisation_field_groups(self, layer, definition):
        configured_groups = definition.get("field_groups", [])
        field_groups = []
        for group_definition in configured_groups:
            field = self._find_first_field(layer, group_definition.get("field_names", []))
            if field is not None:
                field_groups.append(
                    {
                        "daypart": group_definition.get("key", group_definition.get("label")),
                        "label": group_definition["label"],
                        "field": field,
                        "categories": group_definition.get("categories"),
                    }
                )

        if field_groups:
            return field_groups

        daypart_fields = definition.get("daypart_fields", {})
        field_groups = []

        for daypart in ("RD", "OS", "AS"):
            field = self._find_first_field(layer, daypart_fields.get(daypart, []))
            if field is not None:
                field_groups.append(
                    {
                        "daypart": daypart,
                        "label": daypart,
                        "field": field,
                    }
                )

        if field_groups:
            return field_groups

        field = self._find_first_field(layer, definition["field_names"])
        if field is None:
            return []

        return [
            {
                "daypart": None,
                "label": definition["group_name"],
                "field": field,
            }
        ]

    def _project_codes_in_layer(self, layer, field):
        values = self._numeric_unique_values(layer, field)
        return sorted({int(value) for value in values if value != 0})

    def _load_project_catalog(self):
        if self.project_catalog is not None:
            return self.project_catalog, self.project_catalog_meta

        if not self.PROJECT_LIST_PATH.exists():
            self.project_catalog = {}
            self.project_catalog_meta = {"round": "RP2026", "source_file": "geen projectenlijst"}
            return self.project_catalog, self.project_catalog_meta

        with self.PROJECT_LIST_PATH.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)

        self.project_catalog = {
            int(project["code"]): project
            for project in payload.get("projects", [])
            if project.get("code") is not None
        }
        self.project_catalog_meta = {
            "round": payload.get("round", "RP2026"),
            "source_file": payload.get("source_file", self.PROJECT_LIST_PATH.name),
            "source_date": payload.get("source_date", ""),
            "project_count": payload.get("project_count", len(self.project_catalog)),
        }
        return self.project_catalog, self.project_catalog_meta

    def _project_row(self, code, catalog):
        project = catalog.get(code)
        if project is not None:
            return project

        return {
            "code": code,
            "network_type": "",
            "projectnaam": "Onbekend in projectenlijst",
            "projectomschrijving": "Projectcode komt voor in het netwerk, maar niet in de meegeleverde projectenlijst.",
            "wegnummer": "",
            "provincie": "",
            "jaar_nrm": "",
        }

    def _project_style(self, index):
        return {
            "color": self.PROJECT_COLORS[index % len(self.PROJECT_COLORS)],
            "width": 1.35,
            "style": PEN_SOLID_LINE,
        }

    def _project_layer_name(self, project):
        name = str(project.get("projectnaam") or "Onbekend project")
        layer_name = f"{project['code']} {name}"
        if len(layer_name) > 96:
            return layer_name[:93] + "..."
        return layer_name

    def _zoom_to_layers(self, layers):
        combined_extent = QgsRectangle()
        has_extent = False

        for layer in layers:
            extent = self._extent_for_canvas(layer, layer.extent())
            if extent.isNull() or extent.isEmpty():
                continue
            if has_extent:
                combined_extent.combineExtentWith(extent)
            else:
                combined_extent = QgsRectangle(extent)
                has_extent = True

        if not has_extent:
            self.iface.mapCanvas().refresh()
            return False

        combined_extent.scale(1.15)
        canvas = self.iface.mapCanvas()
        canvas.setExtent(combined_extent)
        canvas.refresh()
        return True

    def _extent_for_canvas(self, layer, extent):
        if layer is None or extent is None or extent.isNull() or extent.isEmpty():
            return QgsRectangle()

        canvas = self.iface.mapCanvas()
        target_crs = canvas.mapSettings().destinationCrs()
        source_crs = layer.crs()
        if (
            not source_crs.isValid()
            or not target_crs.isValid()
            or source_crs == target_crs
        ):
            return QgsRectangle(extent)

        try:
            transform = QgsCoordinateTransform(
                source_crs,
                target_crs,
                QgsProject.instance(),
            )
            return transform.transformBoundingBox(QgsRectangle(extent))
        except Exception:
            return QgsRectangle(extent)

    def _matching_categories(self, layer, field, definition):
        values = self._numeric_unique_values(layer, field)
        categories = []
        matched_values = set()

        for category in definition["categories"]:
            if self._category_matches_values(category, values):
                categories.append(category)
                matched_values.update(self._values_matching_category(category, values))

        fallback = definition.get("fallback")
        if fallback is not None:
            for value in sorted(set(values) - matched_values):
                categories.append(
                    {
                        "values": [value],
                        "label": fallback["label_template"].format(value=self._format_value(value)),
                        "color": fallback["color"],
                        "width": fallback["width"],
                        "style": fallback.get("style", PEN_SOLID_LINE),
                    }
                )

        return categories

    def _numeric_unique_values(self, layer, field):
        field_index = layer.fields().indexFromName(field.name())
        values = []
        for raw_value in layer.uniqueValues(field_index):
            value = self._as_number(raw_value)
            if value is not None:
                values.append(value)
        return values

    def _category_matches_values(self, category, values):
        return bool(self._values_matching_category(category, values))

    def _values_matching_category(self, category, values):
        return [value for value in values if self._value_matches_category(value, category)]

    def _value_matches_category(self, value, category):
        if "values" in category:
            return value in {self._normalise_number(item) for item in category["values"]}

        minimum = category.get("min")
        maximum = category.get("max")
        min_inclusive = category.get("min_inclusive", False)
        max_inclusive = category.get("max_inclusive", True)

        if minimum is not None:
            if min_inclusive and value < minimum:
                return False
            if not min_inclusive and value <= minimum:
                return False

        if maximum is not None:
            if max_inclusive and value > maximum:
                return False
            if not max_inclusive and value >= maximum:
                return False

        return True

    def _category_clause(self, field, category):
        field_name = self._quoted_identifier(field.name())
        if "values" in category:
            values = [self._format_value(value) for value in category["values"]]
            if len(values) == 1:
                return f"{field_name} = {values[0]}"
            return "(" + " OR ".join(f"{field_name} = {value}" for value in values) + ")"

        clauses = []
        minimum = category.get("min")
        maximum = category.get("max")
        min_operator = ">=" if category.get("min_inclusive", False) else ">"
        max_operator = "<=" if category.get("max_inclusive", True) else "<"

        if minimum is not None:
            clauses.append(f"{field_name} {min_operator} {self._format_value(minimum)}")
        if maximum is not None:
            clauses.append(f"{field_name} {max_operator} {self._format_value(maximum)}")

        return " AND ".join(clauses)

    def _value_clause(self, field, value):
        field_name = self._quoted_identifier(field.name())
        if self._field_is_numeric(field):
            return f"{field_name} = {self._format_value(value)}"
        escaped = str(value).replace("'", "''")
        return f"{field_name} = '{escaped}'"

    def _field_is_numeric(self, field):
        if hasattr(field, "isNumeric"):
            return field.isNumeric()
        numeric_type_names = {
            "int",
            "integer",
            "long",
            "longlong",
            "real",
            "double",
            "float",
            "numeric",
            "decimal",
        }
        return field.typeName().casefold() in numeric_type_names

    def _combined_subset(self, source_layer, visualisation_filter):
        source_subset = source_layer.subsetString()
        if not source_subset:
            return visualisation_filter
        return f"({source_subset}) AND ({visualisation_filter})"

    def _quoted_identifier(self, name):
        return f'"{name.replace(chr(34), chr(34) + chr(34))}"'

    def _as_number(self, value):
        if value is None:
            return None
        text = str(value).strip()
        if text == "":
            return None
        try:
            return self._normalise_number(float(text))
        except ValueError:
            return None

    def _normalise_number(self, value):
        if float(value).is_integer():
            return int(value)
        return float(value)

    def _format_value(self, value):
        value = self._normalise_number(value)
        if isinstance(value, int):
            return str(value)
        return str(value)

    def _style_roundabout_layers(self, link_layer, area_layer):
        link_symbol = QgsLineSymbol.createSimple(
            {
                "color": "#d000ff",
                "width": "1.1",
                "line_style": "solid",
            }
        )
        link_layer.setRenderer(QgsSingleSymbolRenderer(link_symbol))
        link_layer.setDisplayExpression('"rotonde_id"')

        area_symbol = QgsFillSymbol.createSimple(
            {
                "color": "208,0,255,18",
                "outline_color": "#d000ff",
                "outline_width": "0.45",
                "outline_style": "solid",
            }
        )
        area_layer.setRenderer(QgsSingleSymbolRenderer(area_symbol))
        area_layer.setDisplayExpression('"rotonde_id"')

        text_format = QgsTextFormat()
        text_format.setSize(8)
        text_format.setColor(QColor("#4b0055"))
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(0.8)
        buffer.setColor(QColor("#ffffff"))
        text_format.setBuffer(buffer)

        label_settings = QgsPalLayerSettings()
        label_settings.fieldName = "rotonde_id"
        label_settings.setFormat(text_format)
        area_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
        area_layer.setLabelsEnabled(True)

    def _renderer(self, category):
        symbol = QgsLineSymbol.createSimple({})
        symbol.setColor(QColor(category["color"]))
        symbol.setWidth(category["width"])
        render_unit = self._render_unit(category)
        if render_unit is not None and hasattr(symbol, "setWidthUnit"):
            symbol.setWidthUnit(render_unit)

        symbol_layer = symbol.symbolLayer(0)
        if hasattr(symbol_layer, "setPenStyle"):
            symbol_layer.setPenStyle(category.get("style", PEN_SOLID_LINE))
        if hasattr(symbol_layer, "setWidth"):
            symbol_layer.setWidth(category["width"])
        if render_unit is not None and hasattr(symbol_layer, "setWidthUnit"):
            symbol_layer.setWidthUnit(render_unit)

        width_expression = self._scaled_width_expression(category)
        if width_expression is not None:
            self._set_data_defined_symbol_property(
                symbol_layer,
                "PropertyStrokeWidth",
                width_expression,
            )

        offset = category.get("offset")
        if offset is None and "offset_multiplier" in category:
            offset = category["width"] * category["offset_multiplier"] + category.get("offset_extra", 0)
        if offset is not None:
            if hasattr(symbol, "setOffset"):
                symbol.setOffset(offset)
            if render_unit is not None and hasattr(symbol, "setOffsetUnit"):
                symbol.setOffsetUnit(render_unit)
            if hasattr(symbol_layer, "setOffset"):
                symbol_layer.setOffset(offset)
            if render_unit is not None and hasattr(symbol_layer, "setOffsetUnit"):
                symbol_layer.setOffsetUnit(render_unit)

        offset_expression = self._scaled_offset_expression(category)
        if offset_expression is not None:
            self._set_data_defined_symbol_property(
                symbol_layer,
                "PropertyOffset",
                offset_expression,
            )

        if "opacity" in category and hasattr(symbol, "setOpacity"):
            symbol.setOpacity(category["opacity"])

        return QgsSingleSymbolRenderer(symbol)

    def _zone_renderer(self, layer):
        symbol = QgsFillSymbol.createSimple(
            {
                "color": "255,255,255,0",
                "outline_color": "#154273",
                "outline_width": "0.24",
                "outline_style": "solid",
            }
        )

        if self._find_first_field(layer, ["XCOORD"]) is None or self._find_first_field(layer, ["YCOORD"]) is None:
            return QgsSingleSymbolRenderer(symbol)

        marker = QgsMarkerSymbol.createSimple(
            {
                "name": "circle",
                "color": "#f9e11e",
                "outline_color": "#154273",
                "outline_width": "0.30",
                "size": "2.1",
            }
        )
        geometry_layer = QgsGeometryGeneratorSymbolLayer.create(
            {
                "geometryModifier": 'make_point("XCOORD", "YCOORD")',
                "SymbolType": "Marker",
            }
        )
        if geometry_layer is not None:
            geometry_layer.setSymbolType(SYMBOL_MARKER)
            geometry_layer.setSubSymbol(marker)
            symbol.appendSymbolLayer(geometry_layer)

        return QgsSingleSymbolRenderer(symbol)

    def _inweva_renderer(self, inweva_key):
        is_hours_layer = inweva_key.endswith("_uren")
        symbol = QgsLineSymbol.createSimple(
            {
                "color": "#154273" if is_hours_layer else "#007bc7",
                "line_width": "0.46" if is_hours_layer else "0.34",
                "line_style": "solid",
            }
        )
        if hasattr(symbol, "setOpacity"):
            symbol.setOpacity(0.82 if is_hours_layer else 0.72)
        return QgsSingleSymbolRenderer(symbol)

    def _zone_display_expression(self, layer, definition):
        field = self._find_first_field(layer, [definition["zone_field"], "GEB_CODE"])
        if field is None:
            return ""
        return self._quoted_identifier(field.name())

    def _inweva_display_expression(self, layer):
        field = self._find_first_field(
            layer,
            ["VBNOMSTXT", "VBNOMSBPS", "WEGNRFML_B", "VBN_ID"],
        )
        if field is None:
            return ""
        return self._quoted_identifier(field.name())

    def _render_unit(self, category):
        if category.get("unit") == "map":
            return QgsUnitTypes.RenderMapUnits
        return None

    def _scaled_width_expression(self, category):
        scale_factor_expression = category.get("scale_factor_expression")
        if not scale_factor_expression:
            return None
        return f"({self._format_value(category['width'])}) * ({scale_factor_expression})"

    def _scaled_offset_expression(self, category):
        scale_factor_expression = category.get("scale_factor_expression")
        if not scale_factor_expression or "offset_multiplier" not in category:
            return None
        width = self._format_value(category["width"])
        multiplier = self._format_value(category["offset_multiplier"])
        extra = self._format_value(category.get("offset_extra", 0))
        return (
            f"(({width}) * ({scale_factor_expression}) * ({multiplier}))"
            f" + (({extra}) * ({scale_factor_expression}))"
        )

    def _set_data_defined_symbol_property(self, symbol_layer, property_name, expression):
        property_key = getattr(QgsSymbolLayer, property_name, None)
        if (
            property_key is None
            or not hasattr(symbol_layer, "dataDefinedProperties")
            or not hasattr(symbol_layer, "setDataDefinedProperties")
        ):
            return

        properties = symbol_layer.dataDefinedProperties()
        properties.setProperty(property_key, QgsProperty.fromExpression(expression))
        symbol_layer.setDataDefinedProperties(properties)

    def _info(self, title, message):
        self.iface.messageBar().pushMessage(title, message, level=Qgis.Info, duration=6)

    def _warn(self, title, message):
        self.iface.messageBar().pushMessage(title, message, level=Qgis.Warning, duration=8)
