# LMSNRM Toolbar

## Versie 0.9.0: nieuwe toolbarindeling

Toolbar en plugin heten LMSNRM Toolbar. Zes hoofdmenu’s: Netwerken, Attributen, Afslagverboden, Projecten, Extra data en Kaart.

Netwerken bevat RP 2026 met Noord/Oost/West/Zuid/LMS, Invoernetwerk uit GMZIP halen, geladen netwerk vanuit GMZIP, .NET-attributen koppelen en Verschilnetwerk maken. De regioactie vraagt eenmaal de lokale bibliotheekmap (bijvoorbeeld RP2025 v2), onthoudt die locatie en opent een keuzevenster voor zichtjaar en dagdeel. De lagenstructuur van Netwerkbibliotheek 1.1.0 wordt ondersteund. De leveringnaam en bronmap blijven in het venster zichtbaar.

Een invoernetwerk uit GMZIP wordt als kaal GeoPackage opgeslagen, met alle bronvelden en A/B-aliassen voor .NET-koppeling. Hierbij zijn geen GLD2/ULD2-resultaten nodig. Een geannuleerde of mislukte import vervangt geen bestaande uitvoer.

Attributen bevat Eigenschappen, Resultaten en Verschilnetwerk. Visualisatielagen verwijderen verwijdert deze drie soorten voor de actieve bron samen. Functies zonder passende velden worden grijs gemaakt. Extra data bevat Zones 2022 en INWEVA 2025. Kaart bevat Kaart uitlijnen met OpenStreetMap.

## Versie 0.8.21: rode klassen bovenop

Bij geladen-netwerkresultaten en verschilkaarten staan rood/oranje boven blauw en staat de grijze achtergrond onderaan. Blauwe verschilklassen zijn rustiger weergegeven. Bij IC krijgt de hoogste knelpuntklasse voorrang. Bij attribuutkaarten krijgen brede gekleurde lijnen voorrang op dunne achtergrondlagen. Binnen dezelfde kleur krijgen dikkere klassen voorrang. Kleuren en filtergrenzen zijn behouden. Een geweigerd laagfilter wordt nu als fout gemeld in plaats van een ongefilterde klasselaag toe te voegen. Legenda-aantallen worden opnieuw berekend. Maak bestaande visualisatiegroepen opnieuw via het menu om de tekenvolgorde toe te passen.

## Versie 0.8.20: eenvoudiger menu en herkenbare netwerkkeuze

Onder Geladen netwerk staan **Netwerkresultaten** en **Verschilnetwerk (netwerk 1 − netwerk 2)** apart. Verschilkaarten zijn uitgebreid met gereden snelheid, totale reistijd, wachttijd, snelheidsverlies, extra reistijd, aangeboden belasting, fileduur, vrachtaandeel, motorvoertuigintensiteit, L1/L2/L3 en wachtrij. Motorvoertuigen en pae hebben afzonderlijke kaarten; etmaalintensiteiten hebben een eigen eenheid en klassegrenzen. Vrachtaandeelverschil is in procentpunten.

De kaart **Netwerkveranderingen / koppeling** onderscheidt links die alleen in netwerk 1 of 2 voorkomen en gematchte links met gelijke of gewijzigde numerieke attributen. Bekijk die kaart om verschillen door netwerkveranderingen te herkennen. Verschilwaarden van links die slechts in één netwerk staan gebruiken de bestaande vergelijking met nul; dat zijn geen gematchte voor/na-metingen.

Bij de nieuwe verschilkaarten betekent blauw afname en rood toename, met grijs rond nul. Bij gereden snelheid is een afname rood en een toename groen. Positieve en negatieve waarden betekenen steeds **netwerk 1 − netwerk 2**. Voor verschilkaarten op nieuwe afgeleide velden moeten beide geladen netwerken met de nieuwe GMZIP-import gemaakt zijn en moet het verschilnetwerk opnieuw worden opgebouwd. Kaarten op reeds aanwezige SPEED, TCST, WCST, VTG, NBB en L1/L2/L3 werken ook op bestaande verschilnetwerken.

De publicatiepakketknop onder Kaart en beide rotondeacties onder Scripts zijn verwijderd. Scripts bevat de .NET-koppeling.

In Verschilnetwerk maken kies je expliciet tussen **Geopende laag in dit QGIS-project** en **Bestand vanaf schijf**. De keuzelijst toont bij bestaande lagen ook de groep en de GMZIP-bron, zodat dezelfde dagdeelnamen van verschillende netwerken herkenbaar zijn. Omschakelen naar een geopende laag gebruikt die laag, ook wanneer eerder een bestand gekozen was.

Nieuwe GMZIP-imports krijgen namen met de bronvariant en het dagdeel, bijvoorbeeld `WEST 2040H-S RP25 26 — RD (restdag)`. Bestaande projecten hoeven niet opnieuw geïmporteerd te worden om de uitgebreidere namen in het verschilvenster te zien. Kies voor een vergelijking van alle dagdelen bij beide netwerken **Alle dagdelen**.

## Versie 0.8.19: geladen-netwerkkaarten

`Geladen netwerk` bevat naast IC en verschilkaarten nu intensiteit motorvoertuigen (dagdelen en etmaal), intensiteit pae, gereden snelheid, snelheidsverlies, extra reistijd, wachttijd, absolute VVU100 (HWN), L1/L2/L3-intensiteiten, aangeboden belasting, wachtrij, onafgewikkelde stroom, fileduur en vrachtaandeel exclusief bestelverkeer.

De kleuren en klassegrenzen zijn vast, zodat scenario's onderling vergelijkbaar zijn. Etmaalintensiteiten hebben eigen grenzen en de eenheid mvt/etmaal. Gereden snelheid heeft klassen tot 120 km/u en een open bovenklasse; nul blijft herkenbaar grijs. De nieuwe grenzen zijn analytische keuzes, geen nieuwe officiële RWS-kleurstandaard.

De GMZIP-export bewaart aanvullend FILED (seconden), de oorspronkelijke VVU, QBBV/NBBV, FRGT2/FRGT3, BEST1/BEST2 en COMM/BUSS/OTHR. Nieuwe afgeleide velden per dagdeel:

- `SPEED_LOSS`: max(0, TSVA − SPEED), in km/u.
- `EXTRA_TIME`: max(0, TCST − FCST), in seconden per link.
- `OFFERED_LOAD`: FLOW / FLCPW. Dit is aangeboden belasting, naast bestaande IC = QBB / FLCPW.
- `FREIGHT_SHARE`: 100 × (FRGT2 + FRGT3) / VTG; bestelverkeer zit niet in de teller.

Bij een nulnoemer is aangeboden belasting of vrachtaandeel leeg; die links worden niet als een gemeten nul ingedeeld. L1 omvat personenauto en Bestel L1, L2 omvat Vracht en Bestel L2, L3 omvat Vracht L3. De absolute VVU100 gebruikt dezelfde bestaande HWN-definitie en ophoogfactoren als de verschilkaart; de oorspronkelijke VVU is een afzonderlijk bronresultaat.

`Attributen > Model snelheid` gebruikt H/T_SNEL_MOD, MODSPEED of geladen TSVA-velden (vrije snelheid). Gecongesteerde SPEED-velden horen voortaan bij `Geladen netwerk > Gereden snelheid`. Eindlabels van verschilklassen met exclusieve ondergrenzen zijn gecorrigeerd naar `>`.

**Bestaande GeoPackages:** kaarten op reeds aanwezige VTG, FLOW, SPEED, WCST, VVU100 en L1/L2/L3 werken direct. Maak het geladen netwerk opnieuw vanuit GMZIP voor fileduur, vrachtaandeel en de nieuwe afgeleide velden. Installeren van de plugin vult bestaande GeoPackages niet automatisch aan.

## Versie 0.8.18: RP25v2-invoernetwerken

- Projecten gebruikt nu de complete RP2026-projectenlijst van 15 juni 2026 uit `RP25v2 netwerken.zip` (265 projecten).
- `Invoernetwerken > Lokaal netwerk laden...` opent een shape of een gekozen lijnlaag uit een lokaal GeoPackage.
- `Invoernetwerken > Netwerk uit ZIP laden...` opent een gekozen shape rechtstreeks uit de ZIP, zonder uitpakken. Laat de bron-ZIP op dezelfde plek staan zolang het QGIS-project ernaar verwijst.
- `Effectieve rijstroken` toont `H_Lanes`, naast `Rijstroken` op basis van `H_Stroken`. De effectieve waarde omvat speciale stroken.
- Rijstrookwaarden 0, 7 en 8 hebben eigen klassen. Overige waarden, waaronder de aangetroffen waarde 9, blijven zichtbaar met een controlelabel; de betekenis van 9 is niet vastgelegd in het meegeleverde RP2025-handboek.
- Nachtelijke snelheid 0 zit uitsluitend in de nulklasse. Snelheidslabels beschrijven de werkelijke intervallen van de filters. Bestaande kleuren blijven behouden.
- Capaciteit 99999 is expliciet als onbegrensde modelcapaciteit gelabeld.
- OC/AV-veldaliases worden bij attribuutvisualisaties ook herkend als OS/AS.
- De geëxporteerde CUBE-shapes bevatten geen `H_SEL/T_SEL`. `Rijrichting` blijft beschikbaar voor moederbestanden en legt bij deze exports uit waarom richtingselectie niet beschikbaar is.

Voor dagelijks gebruik is een lokaal GeoPackage met ruimtelijke index aanbevolen. De plugin bevat de netwerkdata niet. Eén bestand kan alle 60 netwerklagen bevatten, maar een GeoPackage per jaar (15 lagen) is praktischer bij beheer en kopiëren. De omzetting kan rechtstreeks vanuit de ZIP plaatsvinden; vooraf alle 20 GB uitpakken is niet nodig. Er zijn met deze update geen volledige netwerken uitgepakt of geconverteerd.

Eerste QGIS-pluginopzet voor netwerkvisualisatie.

De uitgebreide HTML-handleiding staat in `handleiding_lms_nrm.html`.

## Wat zit erin

- Toolbar `LMSNRM Toolbar` met losse menuknoppen: `Attributen`, `Geladen netwerk`, `Afslagverboden`, `Zones 2022`, `INWEVA`, `Kaart`, `Scripts` en `Projecten`.
- `Attributen` bevat bovenaan `Lagen verwijderen`, daarna de RP2025-attribuutvisualisaties uit het handboek, waaronder linktypes, snelheden, rijstroken, capaciteit, speciale stroken, wegsoort, gebiedscode, signalering, HWN, heffingen, beheerder, provincie en rijrichting.
- `Geladen netwerk` bevat bovenaan `Lagen verwijderen`, daarna `IC verhouding`, `Verschil IC verhouding`, `Verschil intensiteit`, `Verschil VVU100`, `Maak geladen netwerk vanuit GMZIP...` en `Verschilnetwerk maken...`.
- `Afslagverboden` bevat `Lagen verwijderen` en `.PEN koppelen aan actieve shape...`.
- `Zones 2022` bevat bovenaan `Lagen verwijderen`, daarna `LMS`, `Noord`, `Oost`, `West` en `Zuid`.
- `Kaart` bevat `CRS afstemmen op OpenStreetMap`.
- `Scripts` bevat `.NET koppelen aan actieve shape...`, `Rotondes opsporen...` en `Rotondes controleren...`.
- `Projecten` bevat een zoekvenster voor projectcodes uit de actieve shape.
- De acties gebruiken de actieve lijnlaag en zoeken de juiste RP25-netwerkvelden hoofdletter-ongevoelig.
- Onder de bronlaag komt per actie een groep, bijvoorbeeld `Linktypes` of `Wettelijke snelheid`.
- In die groep komt per klasse een gefilterde laag met eigen kleur en lijndikte.
- De bronlaag wordt uitgezet, zodat de visualisatielagen direct zichtbaar zijn.
- Omdat dit echte QGIS-lagen zijn, kun je klassen los aan/uit zetten en zie je automatisch de legenda in de lagenboom.
- Zonekaarten werken ook zonder geopende netwerkshape. De plugin laadt de zonepolygonen uit `data/zones_2022.gpkg` en tekent het zwaartepunt in dezelfde QGIS-laag op basis van `XCOORD` en `YCOORD`.

## Installeren in QGIS

De map staat ook klaar als `rws_toolbar.zip`. Die kun je in QGIS laden via `Plugins > Manage and Install Plugins > Install from ZIP`.

Handmatig kan ook:

Kopieer of symlink de map `rws_toolbar` naar je QGIS pluginmap en herstart QGIS.

Op macOS is dat meestal:

```bash
~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/
```

Daarna in QGIS:

1. Ga naar `Plugins > Manage and Install Plugins`.
2. Zet `LMSNRM Toolbar` aan.
3. Selecteer een netwerkshape in de lagenboom.
4. Klik op `Attributen > Linktypes`.

## Attributen

- `Linktypes`: veld `linktype`, met fallback naar `NRM_TYPE` in geladen Qblok-netwerken
- `Wettelijke snelheid`: velden `H_SNEL_WET/T_SNEL_WET`, met fallback naar `RD/OS/AS_SNEL_WET` en `RD/OS/AS_SNELW`
- `Nachtelijke snelheid`: veld `NCHT_SN`
- `Rijstroken`: velden `H_STROKEN/T_STROKEN` of `H_LANES/T_LANES`, met fallback naar `RD/OS/AS_LANES`
- `Capaciteit`: velden `H_CAP/T_CAP`, met fallback naar `RD/OS/AS_CAP`
- `Model snelheid`: velden `H_SNEL_MOD/T_SNEL_MOD` of `MODSPEED`, met fallback naar `RD/OS/AS_SPEED` en `RD/OS/AS_SNELM`
- `Speciale stroken`: veld `EX_STROOK`, `EX_STROKEN` of `Ex_Stroken`
- `Weefvak`: veld `WEEFVAK`, `WEEFVAKKEN`, `Weefvakken` of `WEEF`
- `Wegsoort`: veld `WEGSOORT`
- `Gebiedscode`: velden `GEB_LMS`, `GEB_NOORD`, `GEB_OOST`, `GEB_WEST`, `GEB_ZUID`, `GEB_NL`, met fallback naar `GEB_CODE` of `GEB_C`
- `Signalering`, `Hoofdwegennet`, `Doelgroepstrook`, `Wegbeheerder`, `Tol`, `Vrachtwagenheffing`, `Kilometerheffing`, `Autoluw`, `Grensovergang`, `Openstellingsjaar`, `Provincie` en `Rijrichting`: gebruikt de gelijknamige RP2025-velden en gangbare exportvarianten.

## Geladen Netwerk

- `IC verhouding`: velden `RD_IC`, `OS_IC`, `AS_IC`; op verschilnetwerken ook `N1_RD_IC`, `N1_OS_IC`, `N1_AS_IC`, `N2_RD_IC`, `N2_OS_IC`, `N2_AS_IC`
- `Verschil IC verhouding`: velden `D_RD_IC`, `D_OS_IC`, `D_AS_IC`
- `Verschil intensiteit`: velden `D_RD_FLOW`, `D_OS_FLOW`, `D_AS_FLOW`, `D_ET_L123` of `D_ET_VTG`
- `Verschil VVU100`: velden `D_RD_VVU100`, `D_OS_VVU100`, `D_AS_VVU100`, `D_ET_VVU100`
- `Maak geladen netwerk vanuit GMZIP...`: leest de netwerkshape en de zes QBlok-resultaatbestanden direct uit een Groeimodel-ZIP. De ZIP wordt niet uitgepakt en CUBE is niet nodig.
- De uitvoer is een GeoPackage met één gecombineerde laag met alle `OS_`, `RD_`, `AS_` en `ET_`-velden, plus lichte views voor ochtendspits, restdag en avondspits.
- De GMZIP-koppeling gebruikt `KnoopA/KnoopB` of `A/B`. Na afloop meldt de plugin hoeveel shape-links en modelregels zijn gekoppeld.
- `Verschilnetwerk maken...`: maakt `netwerk 1 - netwerk 2` als GeoPackage. Gematchte links krijgen delta-attributen; links die alleen in een van beide netwerken voorkomen blijven met hun eigen geometrie zichtbaar. De CUBE-compare-semantiek uit de RP25/RP26-scripts wordt gevolgd met `CMPFLAG`, `MATCHSTAT`, `N1_*`, `N2_*` en `D_*`; snelheidsaliases zoals `OS_SNELW`/`OS_SNEL_WET` worden gelijkgetrokken.

Voor geladen Qblok-netwerken splitst de plugin dagdeelvelden waar mogelijk uit naar `RD`, `OS` en `AS`. Als een laag maar een van deze velden heeft, gebruikt de plugin de beschikbare variant.

Dagdelen: `RD` = restdag, `OS` = ochtendspits, `AS` = avondspits.

Als een geladen netwerk dagdeelvelden heeft, worden deze gesplitst in subgroepen. Bijvoorbeeld:

- `Rijstroken`
- `RD`
- `OS`
- `AS`

Binnen elke dagdeelgroep staan weer de gewone klasselagen. `RD` staat standaard aan; `OS` en `AS` staan klaar om aan te zetten.

`IC verhouding` gebruikt verkeerskundige bandbreedtes: de kleur geeft de IC-klasse aan en de lijndikte loopt op naarmate de verhouding hoger wordt. De banden krijgen een zijdelingse offset ten opzichte van de hartlijn, zodat tegengestelde richtingen niet bovenop elkaar worden getekend. De IC-banden gebruiken kaart-eenheden en een zoomafhankelijke schaalfactor op basis van `@map_scale`. `IC 0,00` blijft zichtbaar als grijze wegstructuur. Klassen onder `0,70` blijven rustig zichtbaar als orientatie, terwijl klassen vanaf `0,70` sterker en dekkender zijn voor knelpuntenanalyse.

Bij het aanmaken van een nieuwe attribuutlaag blijven bestaande groepen staan, maar andere attribuutlagen voor dezelfde bronlaag worden uitgezet. Geladen-netwerklagen blijven los daarvan staan. Met `Lagen verwijderen` onder `Attributen` of `Geladen netwerk` verwijder je alleen de lagen uit dat menu.

## Afslagverboden

- `.PEN koppelen aan actieve shape...` leest CUBE-turnpenalties als gerichte knoopreeksen `van-via-naar`.
- De plugin ondersteunt `KNOOPA/KNOOPB`, `KnoopA/KnoopB` en `A/B`.
- Bij een moederbestand worden `H_SEL` en `T_SEL` gebruikt om de rijrichting te bepalen.
- Het resultaat bevat rode afslagbewegingen met pijl, draaipunten en bij gedeeltelijke koppeling een tabel `Niet gekoppeld`.
- De bijbehorende CUBE-netwerkexport geeft de betrouwbaarste koppeling. Een moederbestand kan afwijken doordat Netbeheer tijdens export knopen wijzigt.

## Projecten

- `Projecten kiezen...`: toont de projectcodes die in het `Project`/`PROJECT`-veld van de actieve shape voorkomen.
- De projectcodes worden verrijkt met `rws_toolbar/data/projects_rp2026.json`, een compacte lijst die uit `RP2026_Projectenlijst_20260615.xlsx` uit `RP25v2 netwerken.zip` is gegenereerd.
- Na selectie maakt de plugin een groep `Projecten` met een gefilterde laag per gekozen project.
- Codes die wel in de shape staan maar niet in de RP2026-projectenlijst krijgen de naam `Onbekend in projectenlijst`.

## Zones 2022

- `Zones 2022 > LMS`, `Noord`, `Oost`, `West` of `Zuid`: voegt een zonekaart toe uit `data/zones_2022.gpkg`.
- Per keuze ontstaat een enkele laag, bijvoorbeeld `Zones 2022 - LMS`.
- De zonegrenzen en zwaartepunten zitten in dezelfde laag. Het zwaartepunt wordt getekend met een geometry-generator op `XCOORD` en `YCOORD`.
- De meegeleverde GeoPackage bevat de officiele perceel-zoneringen en de oorspronkelijke puntlagen. De plugin gebruikt voor de kaartweergave de polygonlaag, zodat de lagenboom schoon blijft.
- `Zones 2022 > Lagen verwijderen` verwijdert alleen zonelagen die door de plugin zijn toegevoegd.

## INWEVA 2025

- `Koppelen met netwerk...` koppelt een gekozen INWEVA-variant via `WVK_IDS` aan een geladen netwerklaag. Alleen netwerklinks met een match worden opgenomen; links met uitsluitend lege INWEVA-attributen worden weggelaten.
- `Alle 5 splitsen op actieve netwerklaag...` maakt in een keer vijf lagen met de geometrie van de actieve netwerklaag.
- Elke gesplitste laag bevat `WVK_ID`, `KnoopA`, `KnoopB` en alle attributen van de betreffende INWEVA-variant.
- Lange INWEVA-links worden opgesplitst doordat iedere waarde uit `WVK_IDS` afzonderlijk aan `WVK_ID` wordt gekoppeld.
- Als een `WVK_ID` voor beide rijrichtingen in INWEVA voorkomt, kiest de plugin de richting die overeenkomt met de geometrie van `KnoopA` naar `KnoopB`.
- Voor splitsen zijn `WVK_ID` en `KnoopA/KnoopB` nodig. De knoopvelden mogen ook `KNOOPA/KNOOPB` of `A/B` heten.

## Scripts

- `.NET koppelen aan actieve shape...`: leest een CUBE `.NET`-bestand direct en koppelt de linkattributen op `A,B` aan de actieve lijnshape.
- De bronshape wordt niet aangepast. De plugin maakt een nieuwe tijdelijke laag met dezelfde geometrie en aangevulde `.NET`-attributen.
- Hiervoor is geen CUBE/Voyager-installatie nodig. De plugin decodeert de binaire linktabel zelf.
- Na koppelen meldt de plugin hoeveel links gekoppeld zijn, bijvoorbeeld `143439 van 143439 shape-links gekoppeld`, en hoeveel `.NET`-links niet gebruikt zijn.
- `Rotondes opsporen...`: zoekt in de actieve netwerkshape naar kleine gesloten lussen die qua vloeiende vorm, omvang en aansluitende takken op rotondes of ovondes lijken. Hoekige lussen met scherpe knikken of lange rechte zijden worden zwaarder afgekeurd; een lage vormscore in combinatie met een lange rechte zijde valt af.
- De uitvoer bestaat uit tijdelijke controlelagen `Rotonde kandidaatlinks` en `Rotonde kandidaatvlakken`. De bronshape wordt niet aangepast.
- Alle links van dezelfde kandidaat krijgen een `rotonde_id`, een score, een advies en controlekenmerken zoals compactheid, langwerpigheid en vormscore. Dit is bedoeld als voorselectie voor visuele controle voordat een definitief `rotonde`-attribuut in het moederbestand wordt gezet.
- `Rotondes controleren...`: loopt de kandidaatvlakken een voor een langs, zoomt in op de kandidaat en laat met een popup `Ja`, `Nee`, `Twijfel` of `Overslaan` kiezen. De controlelijst mengt compactheidsklassen en adviestypen, zodat bij kalibratie niet steeds dezelfde foutvorm terugkomt. De keuze wordt opgeslagen in het veld `controle` van de tijdelijke kandidaatlagen.
Het maken van een GeoPackage met moederbestand, knopen en afslagverboden staat in de aparte plugin `Netbeheer`.

## Kaart

- `CRS afstemmen op OpenStreetMap`: zet het project op de CRS van de OpenStreetMap XYZ-laag, meestal `EPSG:3857`.
- Geselecteerde LMS/NRM-lagen met RD-coördinaten krijgen `EPSG:28992` als laag-CRS als die ontbreekt of verkeerd staat.
- De geometrie wordt niet aangepast; dit is bedoeld om lagen correct boven OSM te laten vallen.
- `Publicatiepakket voor RWS Viewer maken...`: maakt lokaal een map met `network.pmtiles`, `manifest.json` en compacte attribuutblokken. Kies een werkelijk uniek bronveld als object-ID, of `rws_fid` voor een tijdelijke, per publicatie gegenereerde ID. De actie uploadt niets en bevat geen Cloudflare-token.

## Linktypekleuren

- `1 Autosnelweg`: rood, dik
- `2 Autoweg`: oranje
- `3 Gebiedsontsluitingsweg gesloten`: blauw
- `4 Gebiedsontsluitingsweg gemengd`: licht cyaan
- `5 Erftoegangsweg`: zwart, dun
- `6 Stadsontsluitingsweg`: groen
- `7 Wijkontsluitingsweg`: lichtgroen/cyaan, dun
- `8 Veerpont`: grijs gestippeld
- `99 Voedingslink`: grijs gestippeld
