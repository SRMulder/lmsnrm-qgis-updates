"""Select a loaded model and an INWEVA reference with explicit periods."""
from pathlib import Path
import re
from qgis.PyQt.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QComboBox,QPushButton,QLabel,QLineEdit,QDialogButtonBox,QFileDialog,QProgressDialog)
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject,QgsVectorLayer,QgsProviderRegistry,QgsWkbTypes
from ..utils.qgis_compat import DIALOG_OK,DIALOG_CANCEL
from ..services.inweva_comparison import create_comparison,mappings,PERIOD_NAMES


def run_comparison(plugin):
 dialog=QDialog(plugin.iface.mainWindow());dialog.setWindowTitle('Geladen netwerk vergelijken met INWEVA');dialog.resize(760,400)
 layout=QVBoxLayout(dialog);form=QFormLayout();layout.addLayout(form)
 models={};model=QComboBox();form.addRow('Geladen netwerk',model)
 def eligible(layer):
  names={f.name().upper() for f in layer.fields()}
  return layer.isValid() and QgsWkbTypes.geometryType(layer.wkbType())==QgsWkbTypes.LineGeometry and 'WVK_ID' in names and 'IW_TYPE' not in names and bool({'ET_L123','OS_VTG','AS_VTG'}&names)
 active=plugin.iface.activeLayer()
 layers=list(QgsProject.instance().mapLayers().values())
 if active in layers:layers.remove(active);layers.insert(0,active)
 for layer in layers:
  if eligible(layer):models[layer.id()]=layer;model.addItem(layer.name(),layer.id())
 browse=QPushButton('Geladen netwerk vanaf schijf openen…');layout.addWidget(browse)
 def open_file():
  path,_=QFileDialog.getOpenFileName(dialog,'Kies geladen netwerk','','GeoPackage (*.gpkg)')
  if not path:return
  found=[]
  for detail in QgsProviderRegistry.instance().querySublayers(path):
   layer=QgsVectorLayer(detail.uri(),Path(path).stem+' — '+detail.name(),'ogr')
   if eligible(layer):models[layer.id()]=layer;model.addItem(layer.name(),layer.id());found.append(layer)
  if found:model.setCurrentIndex(model.findData(found[0].id()))
  else:plugin._warn('Geen geladen netwerk','Een lijnlaag met WVK_ID en verkeersresultaten is nodig.')
 browse.clicked.connect(open_file)
 year=QComboBox();year.addItem('INWEVA 2025',2025);form.addRow('Referentielevering',year)
 variant=QComboBox()
 for key,definition in plugin.INWEVA_LAYERS.items():variant.addItem('INWEVA 2025 — '+definition['label'],key)
 variant.setCurrentIndex(variant.findData('werkdag'));form.addRow('Dagsoort',variant)
 period=QComboBox();form.addRow('Periode',period)
 model_year=QLineEdit();model_year.setPlaceholderText('Basisjaar/scenario van het model, bijvoorbeeld 2022 of 2040H');form.addRow('Modeljaar/scenario',model_year)
 label=QLabel('Uitkomst = model − INWEVA. Bij OS en AS worden de modelwaarden per uur verdubbeld. De uitvoer bevat alle modelwegen en een koppelstatus. Alleen voldoende gedekte, eenduidige en geldige matches krijgen een verschilwaarde.');label.setWordWrap(True);layout.addWidget(label)
 buttons=QDialogButtonBox(DIALOG_OK|DIALOG_CANCEL);buttons.button(DIALOG_OK).setText('Maak INWEVA-verschilnetwerk');buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
 references={}
 def refresh(*args):
  chosen=period.currentData();period.clear();layer=models.get(model.currentData());key=variant.currentData()
  if layer is not None and key:
   if key not in references:
    references[key]=QgsVectorLayer(f'{plugin.INWEVA_DATA_PATH}|layername={plugin.INWEVA_LAYERS[key]["layer_name"]}','INWEVA','ogr')
   iw=references[key]
   if iw.isValid():
    for p,title in PERIOD_NAMES.items():
     try:mappings(layer,iw,key,p)
     except ValueError:continue
     period.addItem(title+' — '+('mvt/etmaal' if p=='ET' else 'mvt per 2 uur'),p)
   if chosen is not None and period.findData(chosen)>=0:period.setCurrentIndex(period.findData(chosen))
   if not model_year.text():
    match=re.search(r'20\d{2}',layer.name()+' '+layer.source())
    if match:model_year.setText(match.group())
  buttons.button(DIALOG_OK).setEnabled(period.count()>0)
 def changed_model(*args):
  model_year.clear();refresh()
 model.currentIndexChanged.connect(changed_model);variant.currentIndexChanged.connect(refresh);refresh()
 if (dialog.exec() if hasattr(dialog,'exec') else dialog.exec_())!=1:return
 if not model_year.text().strip():plugin._warn('Modeljaar ontbreekt','Vul het modeljaar of scenario in, zodat de vergelijking herkenbaar is.');return
 layer=models[model.currentData()];key=variant.currentData();p=period.currentData();output,_=QFileDialog.getSaveFileName(plugin.iface.mainWindow(),'Sla INWEVA-verschilnetwerk op','','GeoPackage (*.gpkg)')
 if not output:return
 progress=QProgressDialog('INWEVA vergelijken…','Annuleren',0,0,plugin.iface.mainWindow());progress.show()
 def update(text):progress.setLabelText(text);QCoreApplication.processEvents()
 try:
  path=Path(output).with_suffix('.gpkg');result=create_comparison(layer,references[key],key,p,path,model_year.text().strip(),progress.wasCanceled,update)
  title=f'{layer.name()} ({model_year.text().strip()}) − INWEVA 2025 {plugin.INWEVA_LAYERS[key]["label"]} — {PERIOD_NAMES[p]}'
  output_layer=QgsVectorLayer(f'{path}|layername=inweva_vergelijking',title,'ogr')
  if not output_layer.isValid():raise ValueError('Uitvoerlaag niet leesbaar.')
  output_layer.setCustomProperty('lmsnrm/inweva_comparison',True)
  QgsProject.instance().addMapLayer(output_layer);plugin.iface.setActiveLayer(output_layer)
  plugin.create_visualisation_layers('iw_match')
  plugin._info('INWEVA-vergelijking gemaakt',f"{result['counts'].get(1,0)} geldige matches. Alle modelwegen zijn bewaard. Kies een geschikte kaart onder Netwerkattributen → Verschilnetwerk. De koppelcontrole staat alvast klaar.")
 except InterruptedError:plugin._info('Geannuleerd','Geen vergelijking opgeslagen.')
 except Exception as error:plugin._warn('INWEVA-vergelijking niet gemaakt',str(error))
 finally:progress.close()
