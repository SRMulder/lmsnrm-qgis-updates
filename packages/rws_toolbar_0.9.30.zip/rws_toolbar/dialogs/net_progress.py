"""Read NET/CSV in a QGIS worker task while a cancellable dialog stays responsive."""
from qgis.core import QgsTask, QgsApplication
from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QLabel,QProgressBar,QPushButton


class NetReadTask(QgsTask):
    def __init__(self, plugin, path, extra_fields=(), completed=None):
        super().__init__('CUBE NET lezen', QgsTask.CanCancel)
        self.plugin = plugin
        self.path = path
        self.extra_fields = list(extra_fields)
        self.completed = completed
        self.result_data = None
        self.error = None
        self.snapshot = ('NET-bestand openen…', 0, 0)

    def report(self, current, total):
        self.snapshot = ('NET-linkregels lezen', current, total)

    def run(self):
        try:
            if self.isCanceled():
                return False
            metadata = self.plugin._cube_net_metadata(self.path)
            metadata['vpr_fields'] = self.extra_fields
            if self.isCanceled():
                return False
            try:
                values = self.plugin._read_cube_net_links(self.path, metadata, self.isCanceled, self.report)
            except InterruptedError:
                raise
            except Exception as error:
                csv_path = self.plugin._cube_net_csv_path(self.path)
                if not csv_path.exists():
                    raise error
                self.snapshot = ('CSV-fallback lezen', 0, 0)
                values = self.plugin._read_net_link_csv(csv_path,
                    self.plugin._cube_net_schema_path(self.path), self.extra_fields,
                    self.isCanceled, self.report)
            if self.isCanceled():
                return False
            self.result_data = (metadata, *values)
            return True
        except InterruptedError:
            return False
        except Exception as error:
            self.error = str(error)
            return False

    def finished(self, success):
        if self.completed:
            self.completed(success)


class NetProgressDialog(QDialog):
    def closeEvent(self, event):
        event.ignore()
        self.reject()

    def reject(self):
        if hasattr(self, 'request_cancel'):
            self.request_cancel()
        else:
            super().reject()


def read_net_with_progress(plugin, path, extra_fields=()):
    dialog = NetProgressDialog(plugin.iface.mainWindow())
    dialog.setWindowTitle('NET-attributen lezen')
    dialog.resize(560,150)
    layout = QVBoxLayout(dialog)
    label = QLabel('NET-bestand openen…')
    layout.addWidget(label)
    bar = QProgressBar()
    bar.setRange(0,0)
    layout.addWidget(bar)
    cancel = QPushButton('Annuleren')
    layout.addWidget(cancel)
    task = NetReadTask(plugin, path, extra_fields)
    cancelling = [False]
    def request_cancel():
        cancelling[0] = True
        task.cancel()
        cancel.setEnabled(False)
        label.setText('Bezig met annuleren…')
    # Escape and window close also request cancellation. Keep the task/dialog
    # alive until the worker ends, so no background result can appear later.
    dialog.request_cancel = request_cancel
    cancel.clicked.connect(request_cancel)
    timer = QTimer(dialog)
    def update():
        if cancelling[0]:
            return
        phase, current, total = task.snapshot
        label.setText(f'{phase}: {current:,} van {total:,} links' if total else f'{phase}: {current:,} links')
        bar.setRange(0,1000 if total else 0)
        if total:
            bar.setValue(min(1000, int(1000*current/max(total,1))))
    timer.timeout.connect(update)
    timer.start(100)
    def completed(success):
        timer.stop()
        dialog.done(1 if success else 0)
    task.completed = completed
    QgsApplication.taskManager().addTask(task)
    dialog.exec()
    task.completed = None
    if task.error:
        raise RuntimeError(task.error)
    return None if cancelling[0] else task.result_data
