"""Choose a CUBE network and optional visual project file together."""
from pathlib import Path
from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QFormLayout,QHBoxLayout,QLineEdit,QPushButton,QDialogButtonBox,QFileDialog,QLabel,QMessageBox
from ..utils.qgis_compat import DIALOG_OK,DIALOG_CANCEL


def choose_net_and_vpr(parent):
    dialog=QDialog(parent)
    dialog.setWindowTitle('.NET-attributen en optionele VPR koppelen')
    dialog.resize(700,230)
    layout=QVBoxLayout(dialog)
    note=QLabel('Koppel de NET-attributen aan de actieve netwerklaag. Voeg desgewenst een VPR toe om ook de CUBE-linkkleuren en selectievoorwaarden over te nemen. VPR-omzetting is bèta. Animaties, knoopsymbolen en afdrukopmaak worden niet overgenomen.')
    note.setWordWrap(True)
    layout.addWidget(note)
    form=QFormLayout()
    layout.addLayout(form)
    net=QLineEdit();vpr=QLineEdit()
    vpr.setPlaceholderText('Optioneel. Leeg laten voor alleen NET-attributen.')
    for label,field,filter_text in [('NET-bestand',net,'CUBE netwerk (*.net *.NET)'),('VPR-bestand (optioneel)',vpr,'CUBE visualisatie (*.vpr *.VPR)')]:
        row=QHBoxLayout();row.addWidget(field)
        button=QPushButton('Bladeren…');row.addWidget(button)
        def browse(checked=False,field=field,filter_text=filter_text):
            path,_=QFileDialog.getOpenFileName(dialog,'Kies '+('NET' if field is net else 'VPR'),str(Path(net.text()).parent) if net.text() else '',filter_text)
            if path:field.setText(path)
        button.clicked.connect(browse)
        form.addRow(label,row)
    buttons=QDialogButtonBox(DIALOG_OK|DIALOG_CANCEL)
    buttons.button(DIALOG_OK).setText('Koppelen')
    def accept():
        if not Path(net.text()).is_file() or (vpr.text().strip() and not Path(vpr.text()).is_file()):
            QMessageBox.warning(dialog,'Bestand niet gevonden','Kies een bestaand NET-bestand en eventueel een bestaand VPR-bestand.')
            return
        dialog.accept()
    buttons.accepted.connect(accept);buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    if dialog.exec()!=1:return None
    return Path(net.text()),Path(vpr.text()) if vpr.text().strip() else None
