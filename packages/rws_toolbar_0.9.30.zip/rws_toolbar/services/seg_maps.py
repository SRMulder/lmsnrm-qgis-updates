"""SEG maps on the existing LMS/NRM zoning; basisjaar 2023, May 2026 delivery."""
from pathlib import Path
import json
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QFileDialog
from qgis.core import QgsVectorLayer, QgsProject, QgsFillSymbol, QgsRuleBasedRenderer, QgsField, QgsFeature, QgsVectorFileWriter, QgsWkbTypes, QgsExpression, QgsExpressionContext, QgsExpressionContextUtils

# Fixed SEG data are read from the shared PluginData folder.
# Fixed thresholds allow visual comparison between the five model regions.
THEMES = {
    'Inwoners per km²': ('INW_KM2', [100,500,1000,2500,5000,10000], 'inwoners/km²'),
    'Banen per km²': ('BANEN_KM2', [100,500,1000,2500,5000,10000], 'banen/km²'),
    'Aandeel 65 jaar en ouder': ('AANDEEL_65', [10,15,20,25,30,40], '%'),
    'Personenauto’s per huishouden': ('AUTO_HH', [.5,.75,1,1.25,1.5,2], 'auto/huishouden'),
    'Gemiddeld besteedbaar huishoudinkomen': ('SEG_INK_GEM', [25000,35000,45000,55000,65000,80000], 'euro/jaar'),
    'Parkeertarief kort parkeren': ('PARK_EUR', [1,2,3,4,6,8], 'euro/uur'),
    'Inwoners — aantal per zone': ('SEG_INWONERS', [500,1000,2500,5000,10000,25000], 'personen/zone'),
    'Huishoudens — aantal per zone': ('SEG_HUISH', [250,500,1000,2500,5000,10000], 'huishoudens/zone'),
    'Woningen — aantal per zone': ('SEG_WONING', [250,500,1000,2500,5000,10000], 'woningen/zone'),
    'Banen — aantal per zone': ('SEG_BANENTOT', [500,1000,2500,5000,10000,25000], 'banen/zone'),
}
COUNT_LIMITS=[100,500,1000,2500,5000,10000]
for sex,label in [('M','Mannen'),('V','Vrouwen')]:
    for suffix,age in [('00_05','0–5'),('06_11','6–11'),('12_14','12–14'),('15_17','15–17'),('18_34','18–34'),('35_54','35–54'),('55_64','55–64'),('65_74','65–74'),('75_EO','75+')]:
        THEMES[f'Leeftijdsopbouw / {label} {age} jaar']=('SEG_'+sex+'_'+suffix,COUNT_LIMITS,'personen/zone')
for family,entries,unit in [
    ('Bevolking',[('INST_BEV','Institutionele bevolking')],'personen/zone'),
    ('Studenten-OV',[('HOWEEK','Hoger onderwijs — weekkaart'),('HOWKND','Hoger onderwijs — weekendkaart'),('MBOWEEK','MBO — weekkaart'),('MBOWKND','MBO — weekendkaart')],'studenten/zone'),
    ('Banen per sector',[('LANDBOUW','Landbouw'),('INDUSTRIE','Industrie'),('DETAIL','Detailhandel'),('CONSDNST','Consumentendiensten'),('DIENSTEN','Dienstensector'),('OVERHEID','Overheid'),('ZORG','Zorg'),('OVERIG','Overige sectoren'),('ZELFST','Banen in eenmanszaken'),('BANENTOT2','Banen exclusief eenmanszaken')],'banen/zone'),
    ('Bedrijvigheid',[('VESTIGING','Vestigingen')],'vestigingen/zone'),
    ('Autobezit',[('ACT_WAG','Actief personenautopark')],'auto’s/zone'),
    ('Onderwijsplaatsen',[('BASIS_OW','Basisonderwijs'),('SPEC_OW','Speciaal onderwijs'),('VOORTG_OW','Voortgezet onderwijs'),('MBO','MBO'),('HBO_WO','HBO en WO')],'leerlingenplaatsen/zone'),
    ('Beroepsbevolking',[('BBV_MAN','Beroepsbevolking mannen'),('BBV_VROUW','Beroepsbevolking vrouwen'),('WERKZ_M','Werkzame mannen'),('WERKZ_V','Werkzame vrouwen'),('PT_MAN','Parttime werkzame mannen'),('PT_VROUW','Parttime werkzame vrouwen')],'personen/zone'),
]:
    for field,label in entries:THEMES[f'{family} / {label}']=('SEG_'+field,COUNT_LIMITS,unit)
THEMES['Bedrijvigheid / Distributieoppervlak']=('SEG_DISTRIBUTI',[1000,5000,10000,25000,50000,100000],'m²/zone')
THEMES['Inkomen / Som besteedbaar inkomen']=('SEG_INK_SOM',[1e6,5e6,1e7,2.5e7,5e7,1e8],'euro/zone')
COLORS=['#d9eaf7','#a6cbe3','#73a7cb','#d6c0cf','#e995a0','#cf5360','#9e1830']
ZONE_FIELDS={'LMS_2022':'LMS','N_2022':'Noord','O_2022':'Oost','W_2022':'West','Z_2022':'Zuid'}
DERIVED={'INW_KM2':'100.0*{INWONERS}/{OPP}','BANEN_KM2':'100.0*{BANENTOT}/{OPP}',
         'AUTO_HH':'1.0*{ACT_WAG}/{HUISH}','AANDEEL_65':'100.0*({M_65_74}+{M_75_EO}+{V_65_74}+{V_75_EO})/{INWONERS}',
         'PARK_EUR':'{PT_KP}/100.0'}

def find_field(layer,name):
    names={f.name().upper():f.name() for f in layer.fields()}
    return names.get(name.upper()) or names.get(name.removeprefix('SEG_').upper()) or names.get('SEG_'+name.upper())

def zone_field(layer):
    fields=[find_field(layer,k) for k in ZONE_FIELDS if find_field(layer,k)]
    if len(fields)!=1:raise ValueError('Kies een perceellaag met precies één LMS/NRM-zonecode; een moederzonering moet eerst per model worden geaggregeerd.')
    return fields[0]

def prepare_source(source):
    if not source or not source.isValid() or QgsWkbTypes.geometryType(source.wkbType())!=QgsWkbTypes.PolygonGeometry:
        raise ValueError('Selecteer een geldige SEG-polygonlaag.')
    zone_field(source)
    layer=source.clone()
    for name,formula in DERIVED.items():
        if find_field(layer,name):continue
        import re
        needed=re.findall(r'\{([^}]+)\}',formula)
        mapping={key:find_field(layer,key) for key in needed}
        if all(mapping.values()):
            expression=formula.format(**{k:'"'+v+'"' for k,v in mapping.items()})
            layer.addExpressionField(expression,QgsField(name,QVariant.Double))
    if not any(find_field(layer,field) for field,limits,unit in THEMES.values()):
        raise ValueError('Geen herkenbare SEG-themavelden aanwezig.')
    return layer

def renderer(field,limits,unit,difference=False,zero_field=None):
    root=QgsRuleBasedRenderer.Rule(None)
    def add(expr,label,color):
        symbol=QgsFillSymbol.createSimple({'color':color,'outline_color':'#666666','outline_width':'0.10'})
        root.appendChild(QgsRuleBasedRenderer.Rule(symbol,filterExp=expr,label=label))
    missing=f'"{field}" IS NULL'
    if zero_field:
        missing+=f' AND COALESCE("{zero_field}",0)=0'
        add(f'"{zero_field}"=1','Nieuw ten opzichte van nul','#7b3294')
    add(missing,'Geen betrouwbare waarde','#bdbdbd')
    add(f'"{field}"=0','Geen verschil' if difference else '0 '+unit,'#ffffbf' if difference else '#f7f7f7')
    if difference:
        edges=[-limits[2],-limits[1],-limits[0],0,limits[0],limits[1],limits[2]]
        colors=['#006837','#31a354','#78c679','#d9ef8b','#fee08b','#fdae61','#f46d43','#a50026']
        for i in range(len(edges)+1):
            lower=edges[i-1] if i else None;upper=edges[i] if i<len(edges) else None
            expr=(f'"{field}">{lower}' if lower is not None else 'TRUE')+' AND '+(f'"{field}"<={upper}' if upper is not None else 'TRUE')+f' AND "{field}"!=0'
            label=(f'> {lower:g}' if upper is None else f'≤ {upper:g}' if lower is None else f'> {lower:g} – {upper:g}')+' '+unit
            add(expr,label,colors[i])
    else:
        add(f'"{field}"<0','Negatieve bronwaarde','#542788')
        lower=0
        for upper,color in zip(limits,COLORS):
            add(f'"{field}">{lower} AND "{field}"<={upper}',f'> {lower:g} – {upper:g} {unit}',color);lower=upper
        add(f'"{field}">{lower}',f'> {lower:g} {unit}',COLORS[-1])
    return QgsRuleBasedRenderer(root)

def _theme_layer(plugin,source,theme,field,limits,unit):
    # Cloning all editor settings repeatedly is costly for wide SEG schemas.
    # Plain OGR sources can be reopened cheaply; keep custom joins via clone.
    if source.providerType()=='ogr' and not source.vectorJoins():
        layer=QgsVectorLayer(source.source(),theme,'ogr')
        layer.setCrs(source.crs());layer.setSubsetString(source.subsetString())
        for i,f in enumerate(source.fields()):
            expression=source.expressionField(i)
            if expression and layer.fields().indexFromName(f.name())<0:
                layer.addExpressionField(expression,QgsField(f))
    else:
        layer=source.clone();layer.setName(theme)
    layer.setRenderer(renderer(field,limits,unit))
    layer.setCustomProperty(plugin.ZONE_PROPERTY,True)
    layer.setCustomProperty('rws_toolbar/seg_source',source.source())
    layer.setCustomProperty('rws_toolbar/seg_theme',field)
    return layer

def load_lazy_group(plugin,group):
    descriptor=group.customProperty('rws_toolbar/seg_lazy','')
    if not descriptor or group.customProperty('rws_toolbar/seg_loaded',False):return 0
    data=json.loads(descriptor);project=QgsProject.instance();source=project.mapLayer(data['source_id'])
    if source is None or not source.isValid():raise ValueError('De SEG-bronlaag is verwijderd of niet bereikbaar. Open de SEG opnieuw.')
    prepared=[_theme_layer(plugin,source,*theme) for theme in data['themes']]
    for layer in prepared:
        if not layer.isValid():raise ValueError('Een detailthema kon niet worden geladen.')
    for child in list(group.children()):
        if child.customProperty('rws_toolbar/seg_placeholder',False):group.removeChildNode(child)
    for layer in prepared:
        project.addMapLayer(layer,False);node=group.addLayer(layer)
        node.setItemVisibilityChecked(False);node.setExpanded(False)
    group.setItemVisibilityChecked(False)
    group.setCustomProperty('rws_toolbar/seg_loaded',True)
    return len(prepared)

def _bind_lazy(plugin,group):
    def expanded(node,is_expanded):
        # QGIS propagates child-node signals to ancestors as well.
        if node != group or not is_expanded:return
        try:load_lazy_group(plugin,group)
        except Exception as error:plugin._warn('SEG-detailgroep niet geladen',str(error))
    group.expandedChanged.connect(expanded)
    if not hasattr(plugin,'_seg_lazy_slots'):plugin._seg_lazy_slots=[]
    plugin._seg_lazy_slots.append((group,expanded))

def disconnect_lazy(plugin):
    for group,slot in getattr(plugin,'_seg_lazy_slots',[]):
        try:group.expandedChanged.disconnect(slot)
        except (RuntimeError,TypeError):pass
    plugin._seg_lazy_slots=[]
    slot=getattr(plugin,'_seg_lazy_read',None)
    if slot is not None:
        try:QgsProject.instance().readProject.disconnect(slot)
        except (RuntimeError,TypeError):pass
        plugin._seg_lazy_read=None

def setup_lazy(plugin):
    disconnect_lazy(plugin)
    def restore(*args):
        for group,slot in getattr(plugin,'_seg_lazy_slots',[]):
            try:group.expandedChanged.disconnect(slot)
            except (RuntimeError,TypeError):pass
        plugin._seg_lazy_slots=[]
        for group in QgsProject.instance().layerTreeRoot().findGroups(True):
            if group.customProperty('rws_toolbar/seg_lazy','') and not group.customProperty('rws_toolbar/seg_loaded',False):
                _bind_lazy(plugin,group)
    plugin._seg_lazy_read=restore;QgsProject.instance().readProject.connect(restore);restore()

def add_group(plugin,source,label=None):
    prepared=prepare_source(source);project=QgsProject.instance()
    group=project.layerTreeRoot().addGroup(label or f'SEG — {source.name()}')
    group.setCustomProperty('rws_toolbar/seg_group',True)
    families={};anchor=None
    for theme,(field,limits,unit) in THEMES.items():
        actual=find_field(prepared,field)
        if not actual:continue
        family,sep,detail=theme.partition(' / ')
        if sep:
            families.setdefault(family,[]).append((detail,actual,limits,unit));continue
        layer=_theme_layer(plugin,prepared,theme,actual,limits,unit)
        project.addMapLayer(layer,False);node=group.addLayer(layer);node.setItemVisibilityChecked(False);node.setExpanded(False)
        if anchor is None:anchor=layer
    if anchor is None and families:
        anchor=prepared.clone();anchor.setName('SEG-bron (uitgeschakeld)');anchor.setCustomProperty(plugin.ZONE_PROPERTY,True)
        project.addMapLayer(anchor,False);group.addLayer(anchor).setItemVisibilityChecked(False)
    for family,themes in families.items():
        subgroup=group.addGroup(family);subgroup.setExpanded(False);subgroup.setItemVisibilityChecked(False)
        subgroup.setCustomProperty('rws_toolbar/seg_lazy',json.dumps({'source_id':anchor.id(),'themes':themes}))
        subgroup.setCustomProperty('rws_toolbar/seg_loaded',False)
        placeholder=subgroup.addGroup('Klap deze groep open om thema’s klaar te zetten')
        placeholder.setCustomProperty('rws_toolbar/seg_placeholder',True);placeholder.setItemVisibilityChecked(False)
        _bind_lazy(plugin,subgroup)
    group.setExpanded(True)
    return group

def open_fixed(plugin,region):
    definition=plugin.ZONES_2022[region]
    source=QgsVectorLayer(f'{plugin._preset_root() / "zones_seg2023_20260518.gpkg"}|layername={definition["layer_name"]}',f'{definition["label"]}','ogr')
    try:
        if find_field(source,'LAND'):source.setSubsetString(f'"{find_field(source,"LAND")}"=1')
        group=add_group(plugin,source,f'SEG 2023 — levering mei 2026 — {definition["label"]}')
        plugin._info('SEG geopend',f'{len(group.findLayers())} hoofdthema’s klaargezet; detailthema’s laden bij uitklappen. Alle lagen staan uit.')
        return group
    except Exception as error:plugin._warn('SEG niet geopend',str(error))

def active_group(plugin):
    try:add_group(plugin,plugin.iface.activeLayer())
    except Exception as error:plugin._warn('SEG niet herkend',str(error))

def create_difference(old,new,path):
    """Fail closed on incompatible zoning; persist one shared polygon dataset."""
    old=prepare_source(old);new=prepare_source(new)
    key_old,key_new=zone_field(old),zone_field(new)
    if key_old.upper()!=key_new.upper() or old.crs()!=new.crs():raise ValueError('Model of CRS verschilt tussen beide SEG-lagen.')
    if Path(path).exists():raise ValueError('Kies een nieuwe bestandsnaam; bestaande bestanden worden niet overschreven.')
    def index(layer,key):
        from decimal import Decimal,InvalidOperation
        result={}
        for feature in layer.getFeatures():
            value=feature[key]
            if QgsVariantUtils.isNull(value):raise ValueError('Ontbrekende zonecode.')
            try:
                numeric=Decimal(str(value).strip())
                if not numeric.is_finite() or numeric!=numeric.to_integral_value():raise InvalidOperation
                code=str(int(numeric))
            except (InvalidOperation,ValueError):raise ValueError('Ongeldige zonecode; verwacht een geheel zonenummer.')
            if code in result:raise ValueError('Ontbrekende of dubbele zonecode.')
            result[code]=feature
        if not result:raise ValueError('De SEG-laag is leeg.')
        return result
    from qgis.core import QgsVariantUtils
    a,b=index(old,key_old),index(new,key_new)
    if a.keys()!=b.keys():raise ValueError('Zonecodes verschillen. Harmoniseer de zonering vóór vergelijking.')
    themes=[(theme,field,find_field(old,field),find_field(new,field)) for theme,(field,_,_) in THEMES.items() if find_field(old,field) and find_field(new,field)]
    if not themes:raise ValueError('Geen gemeenschappelijke SEG-thema’s.')
    output=QgsVectorLayer(f'MultiPolygon?crs={new.crs().authid()}','SEG vergelijking','memory');provider=output.dataProvider()
    fields=[QgsField(key_new,QVariant.String),QgsField('OUDE_BRON',QVariant.String),QgsField('NIEUWE_BRON',QVariant.String)]
    for _,field,_,_ in themes:fields.extend([QgsField('OLD_'+field,QVariant.Double),QgsField('NEW_'+field,QVariant.Double),QgsField('D_'+field,QVariant.Double),QgsField('P_'+field,QVariant.Double),QgsField('Z_'+field,QVariant.Int)])
    provider.addAttributes(fields);output.updateFields()
    features=[]
    for key,n in b.items():
        o=a[key]
        if o.geometry().isNull() or n.geometry().isNull() or not o.geometry().isGeosEqual(n.geometry()):
            raise ValueError(f'Zonegeometrie verschilt bij {key}; geen betrouwbare vergelijking.')
        values=[key,old.name(),new.name()]
        for _,field,of,nf in themes:
            ov,nv=o[of],n[nf]
            if QgsVariantUtils.isNull(ov) or QgsVariantUtils.isNull(nv):
                values.extend([None if QgsVariantUtils.isNull(ov) else float(ov),None if QgsVariantUtils.isNull(nv) else float(nv),None,None,0]);continue
            ov,nv=float(ov),float(nv);d=nv-ov
            values.extend([ov,nv,d,100*d/ov if ov!=0 else 0 if nv==0 else None,1 if ov==0 and nv!=0 else 0])
        feature=QgsFeature(output.fields());feature.setGeometry(n.geometry());feature.setAttributes(values);features.append(feature)
    provider.addFeatures(features);output.updateExtents()
    options=QgsVectorFileWriter.SaveVectorOptions();options.driverName='GPKG';options.layerName='seg_verschil'
    result=QgsVectorFileWriter.writeAsVectorFormatV3(output,str(path),QgsProject.instance().transformContext(),options)
    if result[0]!=QgsVectorFileWriter.NoError:raise ValueError(str(result))
    return themes

def difference_group(plugin,old,new,path):
    themes=create_difference(old,new,path);project=QgsProject.instance()
    group=project.layerTreeRoot().addGroup(f'SEG-verschillen — {new.name()} − {old.name()}')
    group.setCustomProperty('rws_toolbar/seg_group',True)
    for theme,field,_,_ in themes:
        unit=THEMES[theme][2]
        for prefix,label in [('D_','Verschil'),('P_','Procentueel verschil')]:
            if prefix=='P_' and field=='AANDEEL_65':continue
            layer=QgsVectorLayer(f'{path}|layername=seg_verschil',f'{label} — {theme}','ogr')
            diff_unit='%' if prefix=='P_' else 'procentpunten' if field=='AANDEEL_65' else unit
            limits=[2.5,10,25] if prefix=='P_' or field=='AANDEEL_65' else [THEMES[theme][1][0],THEMES[theme][1][2],THEMES[theme][1][4]]
            layer.setRenderer(renderer(prefix+field,limits,diff_unit,True,'Z_'+field if prefix=='P_' else None))
            layer.setCustomProperty(plugin.ZONE_PROPERTY,True)
            project.addMapLayer(layer,False);node=group.addLayer(layer);node.setItemVisibilityChecked(False);node.setExpanded(False)
    return group

def compare_dialog(plugin):
    from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QFormLayout,QComboBox,QPushButton,QLabel,QDialogButtonBox
    from ..utils.qgis_compat import DIALOG_OK,DIALOG_CANCEL
    from .seg_import import import_dialog
    dialog=QDialog(plugin.iface.mainWindow());dialog.setWindowTitle('SEG’s vergelijken');dialog.resize(700,300)
    layout=QVBoxLayout(dialog)
    label=QLabel('Kies twee geopende SEG-lagen van hetzelfde model. Nog geen lagen geopend? Importeer een DBF-levering (losse DBF’s of ZIP) of open een bestaand SEG-GeoPackage. De vergelijking is nieuw min oud.');label.setWordWrap(True);layout.addWidget(label)
    form=QFormLayout();old=QComboBox();new=QComboBox();form.addRow('Oude levering',old);form.addRow('Nieuwe levering',new);layout.addLayout(form)
    def refresh(preferred=None):
        old_id,new_id=old.currentData(),new.currentData();old.clear();new.clear()
        for layer in QgsProject.instance().mapLayers().values():
            try:prepare_source(layer)
            except (ValueError,AttributeError):continue
            text=layer.name()+' — '+zone_field(layer)
            old.addItem(text,layer.id());new.addItem(text,layer.id())
        for combo,selected in [(old,old_id),(new,preferred or new_id)]:
            index=combo.findData(selected)
            if index>=0:combo.setCurrentIndex(index)
        if new.currentData()==old.currentData() and new.count()>1:new.setCurrentIndex(1)
    def import_tables():
        layers=import_dialog(plugin)
        refresh(layers[0].id() if layers else None)
    def open_file():
        from qgis.core import QgsProviderRegistry
        path,_=QFileDialog.getOpenFileName(dialog,'Open SEG-GeoPackage','','GeoPackage (*.gpkg)')
        if not path:return
        loaded=[]
        for detail in QgsProviderRegistry.instance().querySublayers(path):
            layer=QgsVectorLayer(detail.uri(),detail.name(),'ogr')
            try:prepare_source(layer)
            except (ValueError,AttributeError):continue
            layer.setName(Path(path).stem+' — '+detail.name());QgsProject.instance().addMapLayer(layer);QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False);loaded.append(layer)
        if not loaded:plugin._warn('Geen SEG-laag','Dit bestand bevat geen herkenbare SEG-zonevlakken.')
        refresh(loaded[0].id() if loaded else None)
    button=QPushButton('SEG importeren (DBF of ZIP)…');button.clicked.connect(import_tables);layout.addWidget(button)
    button=QPushButton('SEG-GeoPackage openen…');button.clicked.connect(open_file);layout.addWidget(button)
    buttons=QDialogButtonBox(DIALOG_OK|DIALOG_CANCEL);buttons.button(DIALOG_OK).setText('Vergelijk lagen');buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons);refresh()
    result=dialog.exec() if hasattr(dialog,'exec') else dialog.exec_()
    if result!=1:return
    if not old.currentData() or not new.currentData():plugin._warn('Twee lagen nodig','Importeer of open eerst twee SEG-lagen.');return
    old_layer=QgsProject.instance().mapLayer(old.currentData());new_layer=QgsProject.instance().mapLayer(new.currentData())
    if old_layer is None or new_layer is None or old_layer.id()==new_layer.id():plugin._warn('Twee lagen nodig','Kies twee verschillende SEG-lagen van hetzelfde model.');return
    path,_=QFileDialog.getSaveFileName(plugin.iface.mainWindow(),'Verschil-GeoPackage opslaan','','GeoPackage (*.gpkg)')
    if not path:return
    try:
        group=difference_group(plugin,old_layer,new_layer,Path(path).with_suffix('.gpkg'))
        plugin._info('SEG-vergelijking gemaakt',f'{len(group.findLayers())} verschilkaarten klaargezet. Groen is afname, rood toename.')
    except Exception as error:plugin._warn('Vergelijking niet gemaakt',str(error))

def add_seg_menu(plugin,menu):
    fixed=menu.addMenu('SEG 2026')
    plugin.seg_data_menu = fixed
    for region,definition in plugin.ZONES_2022.items():
        action=QAction(definition['label'],plugin.iface.mainWindow());action.triggered.connect(lambda checked=False,key=region:open_fixed(plugin,key));fixed.addAction(action)
