"""Import user-supplied regional SEG tables onto existing model polygons."""
from pathlib import Path
from decimal import Decimal, InvalidOperation
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import shutil,uuid
from qgis.core import (QgsVectorLayer,QgsFeature,QgsField,QgsFields,QgsVectorFileWriter,
                       QgsProject,QgsVariantUtils,QgsWkbTypes)
from qgis.PyQt.QtCore import QVariant

MODELS={'LMS_2022':'lms','N_2022':'noord','O_2022':'oost','W_2022':'west','Z_2022':'zuid'}

def zone_code(value):
    if QgsVariantUtils.isNull(value):raise ValueError('Ontbrekende zonecode in SEG of zonering.')
    try:
        number=Decimal(str(value).strip())
        if not number.is_finite() or number != number.to_integral_value():raise InvalidOperation
        return int(number)
    except (InvalidOperation,ValueError):raise ValueError('Ongeldige zonecode. Een geheel zonenummer is nodig.')


def import_seg(files,zoning,output,cancelled=lambda:False,progress=lambda text:None):
    """Strict full-zone join. Never aggregate a mother table or modify presets."""
    output=Path(output);zoning=Path(zoning)
    if output.exists():raise ValueError('Kies een nieuw uitvoerbestand. Bestaande bestanden worden niet overschreven.')
    if not zoning.is_file():raise ValueError('De bestaande zonering is niet bereikbaar. Maak verbinding met de P-schijf.')
    stage=output.with_name('.'+output.stem+'-'+uuid.uuid4().hex+'.gpkg')
    reports=[];seen=set()
    try:
        with TemporaryDirectory(prefix='lmsnrm-seg-import-') as temporary:
            tables=[]
            for source in map(Path,files):
                if source.suffix.lower()=='.zip':
                    with ZipFile(source) as archive:
                        for i,member in enumerate(archive.namelist()):
                            if not member.lower().endswith('.dbf'):continue
                            if cancelled():raise InterruptedError('Import geannuleerd.')
                            folder=Path(temporary)/uuid.uuid4().hex;folder.mkdir()
                            target=folder/Path(member.replace('\\','/')).name
                            with archive.open(member) as incoming,target.open('wb') as outgoing:shutil.copyfileobj(incoming,outgoing)
                            tables.append((target,str(source)+' / '+member))
                elif source.suffix.lower()=='.dbf':tables.append((source,str(source)))
                else:raise ValueError('Kies losse DBF-bestanden of een ZIP met SEG-tabellen.')
            for path,label in tables:
                progress('SEG herkennen: '+path.name)
                table=QgsVectorLayer(str(path),path.stem,'ogr')
                if not table.isValid():raise ValueError('DBF niet leesbaar: '+path.name)
                names={f.name().upper():f.name() for f in table.fields()}
                keys=[key for key in MODELS if key in names]
                if len(keys)>1:
                    # Official mother tables contain all model codes and cannot
                    # be treated as a regional table without aggregation rules.
                    reports.append({'source':label,'skipped':'moederbestand'});continue
                if len(keys)!=1:raise ValueError('Geen herkenbare modelzonecode in '+path.name)
                key=keys[0];region=MODELS[key]
                if region in seen:raise ValueError('Meerdere SEG-tabellen voor '+region+'. Importeer één levering per keer.')
                seen.add(region)
                index={}
                for feature in table.getFeatures():
                    code=zone_code(feature[names[key]])
                    if code in index:raise ValueError('Dubbele zonecode in '+path.name+': '+str(code))
                    index[code]=feature.attributes()
                zones=QgsVectorLayer(f'{zoning}|layername={region}_zones',region,'ogr')
                if not zones.isValid():raise ValueError('Zonering ontbreekt voor '+region)
                zone_field=next((f.name() for f in zones.fields() if f.name().upper()==key),None)
                if not zone_field:raise ValueError('Modelcode ontbreekt in de zonering voor '+region)
                features=list(zones.getFeatures());codes=[zone_code(f[zone_field]) for f in features]
                if len(set(codes))!=len(codes):raise ValueError('Dubbele zonecode in de zonering.')
                missing=set(codes)-set(index);extra=set(index)-set(codes)
                if missing or extra:raise ValueError(f'{region}: {len(missing)} zones zonder SEG en {len(extra)} SEG-zones zonder vlak. Controleer model en zonering. Er is niets opgeslagen.')
                fields=QgsFields();fields.append(QgsField(key,QVariant.LongLong))
                columns=[]
                for i,field in enumerate(table.fields()):
                    if field.name().upper()==key:continue
                    copied=QgsField(field);copied.setName('SEG_'+field.name().upper());fields.append(copied);columns.append(i)
                fields.append(QgsField('SEG_BRON',QVariant.String))
                options=QgsVectorFileWriter.SaveVectorOptions();options.driverName='GPKG';options.layerName=region+'_zones';options.layerOptions=['SPATIAL_INDEX=YES']
                if stage.exists():options.actionOnExistingFile=QgsVectorFileWriter.CreateOrOverwriteLayer
                writer=QgsVectorFileWriter.create(str(stage),fields,zones.wkbType(),zones.crs(),QgsProject.instance().transformContext(),options)
                try:
                    if writer.hasError()!=QgsVectorFileWriter.NoError:raise ValueError(writer.errorMessage())
                    for number,(code,original) in enumerate(zip(codes,features)):
                        if number%200==0:
                            progress(f'{region}: {number} / {len(features)} zones koppelen')
                            if cancelled():raise InterruptedError('Import geannuleerd.')
                        feature=QgsFeature(fields);feature.setGeometry(original.geometry());feature.setAttributes([code]+[index[code][i] for i in columns]+[label])
                        if not writer.addFeature(feature):raise ValueError(writer.lastError())
                    if not writer.flushBuffer():raise ValueError(writer.lastError())
                finally:del writer
                reports.append({'source':label,'model':region,'zones':len(features),'layer':region+'_zones'})
            if not seen:raise ValueError('Geen modeltabellen gevonden. Kies LMS/Noord/Oost/West/Zuid DBF’s. Een moederbestand alleen wordt niet automatisch geaggregeerd.')
            if cancelled():raise InterruptedError('Import geannuleerd.')
            if output.exists():raise ValueError('Uitvoerbestand bestaat inmiddels al. Kies een nieuw bestand.')
            stage.rename(output)
        return reports
    finally:
        if stage.exists():stage.unlink()


def import_dialog(plugin):
    from qgis.PyQt.QtWidgets import QFileDialog,QProgressDialog,QInputDialog
    from qgis.PyQt.QtCore import QCoreApplication
    files,_=QFileDialog.getOpenFileNames(plugin.iface.mainWindow(),'SEG importeren: kies één levering','','SEG-tabellen (*.zip *.dbf)')
    if not files:return None
    output,_=QFileDialog.getSaveFileName(plugin.iface.mainWindow(),'Sla SEG met zonevlakken op','','GeoPackage (*.gpkg)')
    if not output:return None
    progress=QProgressDialog('SEG koppelen aan zonering…','Annuleren',0,0,plugin.iface.mainWindow());progress.show()
    def update(text):progress.setLabelText(text);QCoreApplication.processEvents()
    try:
        reports=import_seg(files,plugin.ZONE_DATA_PATH,Path(output).with_suffix('.gpkg'),progress.wasCanceled,update)
        layers=[]
        for report in reports:
            if 'layer' not in report:continue
            layer=QgsVectorLayer(f'{Path(output).with_suffix(".gpkg")}|layername={report["layer"]}',f'{Path(output).stem} — {report["model"].capitalize()}','ogr')
            QgsProject.instance().addMapLayer(layer);QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False);layers.append(layer)
        plugin._info('SEG geïmporteerd',f'{len(layers)} model(len) gekoppeld en opgeslagen. Selecteer een laag om thema’s te maken of te vergelijken. Moederbestanden worden overgeslagen.')
        return layers
    except InterruptedError:return None
    except Exception as error:plugin._warn('SEG niet geïmporteerd',str(error));return None
    finally:progress.close()
