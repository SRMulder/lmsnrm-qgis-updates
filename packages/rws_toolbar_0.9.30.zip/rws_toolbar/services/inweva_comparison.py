"""Directional model versus INWEVA comparison with explicit units and quality."""
from pathlib import Path
from collections import Counter
import math,uuid
from qgis.core import (QgsFeature,QgsField,QgsFields,QgsCoordinateReferenceSystem,
 QgsCoordinateTransform,QgsProject,QgsVectorFileWriter,QgsVariantUtils)
from qgis.PyQt.QtCore import QVariant
from .inweva import build_inweva_index,match_inweva_candidate,match_quality,_direction_score

CLASSES=('TOTAL','L1','L2','L3','L23')
SHARES=('L1','L2','L3','L23')
PERIOD_NAMES={'ET':'Etmaal','OS':'Ochtendspits 07–09','AS':'Avondspits 16–18'}

def numeric(value):
 if QgsVariantUtils.isNull(value):return None
 try:
  result=float(value)
  return result if math.isfinite(result) and result>=0 else None
 except (ValueError,TypeError):return None

def mappings(model,inweva,variant,period):
 suffix={'werkdag':'WR','werkdag_uren':'WR','weekdag':'WK','weekdag_uren':'WK','weekenddag':'WN'}[variant]
 mn={f.name().upper():f.name() for f in model.fields()};iw={f.name().upper():f.name() for f in inweva.fields()}
 if period=='ET' and variant.endswith('_uren'):raise ValueError('Gebruik voor etmaal de gewone Werkdag, Weekdag of Weekenddag. Etmaalklassen in de urenbestanden zijn niet altijd consistent.')
 if period!='ET' and variant not in ('werkdag','werkdag_uren','weekdag_uren'):raise ValueError('Deze INWEVA-variant bevat geen geschikte spitswaarden. Kies Werkdag of een urenbestand.')
 out={}
 for cls in ('TOTAL','L1','L2','L3'):
  mf=('ET_L123' if cls=='TOTAL' else 'ET_'+cls) if period=='ET' else period+('_VTG' if cls=='TOTAL' else '_'+cls)
  prefix='AL' if cls=='TOTAL' else cls
  fields=([f'{prefix}_E_{suffix}'] if period=='ET' else [f'{prefix}_{h:02d}_{suffix}' for h in ([7,8] if period=='OS' else [16,17])] if variant.endswith('_uren') else [f'{prefix}_{period}_{suffix}'])
  if mf in mn and all(f in iw for f in fields):out[cls]=(mn[mf],[iw[f] for f in fields])
 if 'TOTAL' not in out:raise ValueError('De gekozen model- of INWEVA-laag mist de totale intensiteit voor deze periode.')
 return out

def compare_values(model_values,observed_values,status=1):
 result={}
 for cls in CLASSES:
  a,b=model_values.get(cls),observed_values.get(cls)
  valid=status==1 and a is not None and b is not None
  result['M_'+cls]=a;result['O_'+cls]=b
  result['D_'+cls]=a-b if valid else None
  result['P_'+cls]=100*(a-b)/b if valid and b>0 else None
  result['R_'+cls]=a/b if valid and b>0 else None
 for cls in SHARES:
  a,t=model_values.get(cls),model_values.get('TOTAL');b,u=observed_values.get(cls),observed_values.get('TOTAL')
  ma=100*a/t if a is not None and t and a<=t else None
  ob=100*b/u if b is not None and u and b<=u else None
  result['MA_'+cls]=ma;result['OA_'+cls]=ob
  result['DA_'+cls]=ma-ob if status==1 and ma is not None and ob is not None else None
 return result

def create_comparison(model,inweva,variant,period,output,model_year='',cancelled=lambda:False,progress=lambda text:None):
 output=Path(output)
 if output.exists():raise ValueError('Kies een nieuw GeoPackage. Bestaande bestanden worden niet overschreven.')
 if model.fields().lookupField('IW_TYPE')>=0:raise ValueError('Kies het oorspronkelijke geladen netwerk, geen bestaande INWEVA-vergelijking.')
 key=next((f.name() for f in model.fields() if f.name().upper()=='WVK_ID'),None)
 if key is None:raise ValueError('WVK_ID ontbreekt in het geladen netwerk.')
 mapping=mappings(model,inweva,variant,period)
 rd=QgsCoordinateReferenceSystem('EPSG:28992')
 if not model.crs().isValid() or not inweva.crs().isValid():raise ValueError('Beide lagen moeten een geldig coördinatenstelsel hebben.')
 transform=QgsCoordinateTransform(model.crs(),rd,QgsProject.instance()) if model.crs()!=rd else None
 progress('INWEVA-index opbouwen…')
 index=build_inweva_index(inweva,'WVK_IDS',progress_callback=lambda n:progress(f'INWEVA-index: {n}'),cancel_callback=cancelled,target_crs=rd)
 if cancelled():raise InterruptedError()
 iw_fields={f.name():i for i,f in enumerate(inweva.fields())}
 template=compare_values({},{});available=set(mapping)
 if 'L2' in available and 'L3' in available:available.add('L23')
 # Only write metric fields supported by both datasets. Missing per-link values
 # remain NULL rather than being silently converted to observed zeros.
 metrics=[f for f in template if f.split('_',1)[1] in available]
 fields=QgsFields(model.fields())
 controls=[('TYPE',QVariant.String),('PERIOD',QVariant.String),('UNIT',QVariant.String),('YEAR',QVariant.Int),('VARIANT',QVariant.String),('MODEL_YEAR',QVariant.String),('STATUS',QVariant.Int),('COVER',QVariant.Double),('CANDIDATES',QVariant.Int),('VBN',QVariant.String),('SOURCE_PC',QVariant.Double),('PC_CHECK',QVariant.Int)]
 for name,kind in controls:
  if not fields.append(QgsField('IW_'+name,kind)):raise ValueError('De modelbron heeft al gereserveerde IW-velden. Kies de oorspronkelijke netwerklaag.')
 for name in metrics:
  if not fields.append(QgsField('IW_'+name,QVariant.Double)):raise ValueError('Dubbele IW-velden in de modelbron.')
 stage=output.with_name('.'+output.stem+'-'+uuid.uuid4().hex+'.gpkg');counts=Counter();writer=None
 try:
  options=QgsVectorFileWriter.SaveVectorOptions();options.driverName='GPKG';options.layerName='inweva_vergelijking';options.layerOptions=['SPATIAL_INDEX=YES']
  writer=QgsVectorFileWriter.create(str(stage),fields,model.wkbType(),model.crs(),QgsProject.instance().transformContext(),options)
  if writer.hasError()!=QgsVectorFileWriter.NoError:raise ValueError(writer.errorMessage())
  for n,original in enumerate(model.getFeatures()):
   if n%250==0:
    progress(f'Modelwegen vergelijken: {n} / {model.featureCount()}')
    if cancelled():raise InterruptedError()
   feature=QgsFeature(original)
   if transform:
    geom=feature.geometry();geom.transform(transform);feature.setGeometry(geom)
   id_value,candidate,_=match_inweva_candidate(feature,key,index)
   status=0;coverage=None;forward=0;mv={};ov={};vbn=None;source_pct=None;pc_check=None
   if candidate:
    _,coverage=match_quality(feature.geometry(),candidate,10)
    for possible in index.candidates.get(id_value,()):
     if _direction_score(feature.geometry(),possible)[0] and possible.geometry.distance(feature.geometry())<=max(feature.geometry().length(),possible.geometry.length())*.02:forward+=1
    status=3 if forward>1 else 2 if coverage<.9 else 1
    for cls,(mf,ifs) in mapping.items():
     value=numeric(original[mf]);mv[cls]=value*(1 if period=='ET' else 2) if value is not None else None
     values=[numeric(candidate.attributes[iw_fields[f]]) for f in ifs];ov[cls]=sum(values) if all(v is not None for v in values) else None
    for target in (mv,ov):
     if target.get('L2') is not None and target.get('L3') is not None:target['L23']=target['L2']+target['L3']
    for target in (mv,ov):
     if target.get('TOTAL') is None:status=4
     elif any(target.get(k) is not None and target[k]>target['TOTAL']+max(3,target['TOTAL']*.01) for k in ('L1','L2','L3','L23')):status=4
     if all(target.get(k) is not None for k in ('TOTAL','L1','L2','L3')) and abs(target['TOTAL']-sum(target[k] for k in ('L1','L2','L3')))>max(3,target['TOTAL']*.01):status=4
    vbn=str(candidate.attributes[iw_fields['VBN_ID']]) if 'VBN_ID' in iw_fields else None
    suffix={'werkdag':'WR','werkdag_uren':'WR','weekdag':'WK','weekdag_uren':'WK','weekenddag':'WN'}[variant]
    pct=f'VRPC_{"E" if period=="ET" else period}_{suffix}'
    if pct in iw_fields:
     source_pct=numeric(candidate.attributes[iw_fields[pct]])
     if source_pct is not None and ov.get('TOTAL') and ov.get('L23') is not None:pc_check=int(source_pct>100 or abs(source_pct-100*ov['L23']/ov['TOTAL'])>1)
   counts[status]+=1;values=compare_values(mv,ov,status)
   out=QgsFeature(fields);out.setGeometry(original.geometry())
   out.setAttributes(original.attributes()+['INWEVA',period,'mvt/etmaal' if period=='ET' else 'mvt/spits (2 uur)',2025,variant,model_year,status,round(coverage*100,1) if coverage is not None else None,forward,vbn,source_pct,pc_check]+[values[k] for k in metrics])
   if not writer.addFeature(out):raise ValueError(writer.lastError())
  if cancelled():raise InterruptedError()
  if not writer.flushBuffer():raise ValueError(writer.lastError())
  del writer;writer=None
  if output.exists():raise ValueError('Het uitvoerbestand bestaat inmiddels al.')
  stage.rename(output)
  return {'counts':dict(counts),'metrics':sorted(available),'period':period,'variant':variant}
 finally:
  if writer is not None:del writer
  if stage.exists():stage.unlink()
