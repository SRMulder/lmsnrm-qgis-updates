"""Read CUBE link-colour rules without executing expressions or following file paths."""
import configparser
import re
from pathlib import Path
from qgis.core import QgsExpression, QgsRuleBasedRenderer, QgsLineSymbol, QgsUnitTypes


def translate_expression(text):
    tokens = re.findall(r'\s+|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[A-Za-z_][A-Za-z_0-9]*|<=|>=|<>|!=|[=<>+*/()&|~-]', text)
    if ''.join(tokens) != text:
        raise ValueError('Niet ondersteunde VPR-voorwaarde: ' + text)
    result = []
    fields = set()
    for token in tokens:
        if re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', token):
            if token.upper() in ('AND', 'OR', 'NOT'):
                result.append(' ' + token.upper() + ' ')
            else:
                fields.add(token)
                result.append('"' + token + '"')
        else:
            result.append({'&': ' AND ', '|': ' OR ', '~': ' NOT '}.get(token, token))
    expression = ''.join(result)
    check = QgsExpression(expression)
    if check.hasParserError():
        raise ValueError('Ongeldige VPR-voorwaarde: ' + text)
    return expression, fields


def read_vpr(path):
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    raw = Path(path).read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = raw.decode('cp1252')
    parser.read_string(text)
    if 'HWYLAYER' not in parser:
        raise ValueError('Deze VPR bevat geen HWYLAYER-netwerkstijl.')
    section = parser['HWYLAYER']
    active = int(section.get('ActiveLinkColorGroup', '0'))
    if active < 1:
        raise ValueError('Deze VPR heeft geen actieve linkkleurgroep.')
    rules = []
    fields = set()
    for key, value in section.items():
        match = re.fullmatch(r'linkcolor' + str(active) + r'_(\d+)', key)
        if not match:
            continue
        parts = value.split(',', 3)
        if len(parts) != 4:
            raise ValueError('Onbekende VPR-linkregel: ' + value)
        color, pen, width = map(int, parts[:3])
        if pen != 0 or width <= 0 or not 0 <= color <= 0xffffff:
            raise ValueError('Niet ondersteunde lijnstijl in VPR: ' + value)
        expression, referenced = translate_expression(parts[3]) if parts[3].strip() else ('TRUE', set())
        fields.update(referenced)
        # Windows COLORREF stores red in the least significant byte.
        rgb = '#%02x%02x%02x' % (color & 255, (color >> 8) & 255, (color >> 16) & 255)
        rules.append({'index': int(match.group(1)), 'color': rgb, 'width': width,
                      'expression': expression, 'label': parts[3].strip() or 'Basisnetwerk'})
    if not rules:
        raise ValueError('Geen ondersteunde linkregels in de actieve VPR-kleurgroep.')
    rules.sort(key=lambda rule: rule['index'])
    return {'rules': rules, 'fields': sorted(fields),
            'offset': float(section.get('LinkDrawOffset' + str(active), '0')),
            'visible': section.get('Visible', '1') != '0'}


def renderer_for_vpr(style, layer):
    available = {field.name().casefold(): field.name() for field in layer.fields()}
    missing = [name for name in style['fields'] if name.casefold() not in available]
    if missing:
        raise ValueError('VPR-velden ontbreken in de gekoppelde laag: ' + ', '.join(missing))
    root = QgsRuleBasedRenderer.Rule(None)
    expressions = []
    for rule in style['rules']:
        expression = rule['expression']
        for field in style['fields']:
            expression = expression.replace('"' + field + '"', '"' + available[field.casefold()] + '"')
        expressions.append(expression)
    for i, rule in enumerate(style['rules']):
        # Make rules mutually exclusive: a later matching colour overrides an earlier one.
        exclusion = ' OR '.join('coalesce((' + e + '), FALSE)' for e in expressions[i+1:])
        expression = 'coalesce((' + expressions[i] + '), FALSE)'
        if exclusion:
            expression += ' AND NOT (' + exclusion + ')'
        symbol = QgsLineSymbol.createSimple({'line_color': rule['color'], 'line_width': str(rule['width'])})
        symbol.setWidthUnit(QgsUnitTypes.RenderPixels)
        symbol.symbolLayer(0).setOffset(style['offset'])
        symbol.symbolLayer(0).setOffsetUnit(QgsUnitTypes.RenderPixels)
        root.appendChild(QgsRuleBasedRenderer.Rule(symbol, 0, 0, expression, rule['label']))
    return QgsRuleBasedRenderer(root)
