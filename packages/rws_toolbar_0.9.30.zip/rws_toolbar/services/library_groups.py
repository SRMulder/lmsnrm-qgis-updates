"""Direct library loading without copying network geometry."""
import re
from pathlib import Path
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes, QgsProviderRegistry

PERIODS={'OC':('Ochtendspits','OC'),'OS':('Ochtendspits','OC'),'RD':('Restdag','RD'),'AV':('Avondspits','AV'),'AS':('Avondspits','AV')}

def load_library_group(plugin,path,region):
    # Use the same OGR provider as the layers. Do not resolve mapped drives
    # into file://server SQLite URIs, which reject Windows UNC authorities.
    tables = [detail.name() for detail in QgsProviderRegistry.instance().querySublayers(str(path)) if detail.providerKey() == 'ogr']
    prepared=[]; keys=set()
    for table in tables:
        match=re.fullmatch(r'netwerk_(\d{4})_(RD|OC|AV|OS|AS)',table,re.I)
        if not match:continue
        year,period=match.groups();label,canonical=PERIODS[period.upper()]
        if (year,canonical) in keys:raise ValueError('Dubbele laag voor hetzelfde zichtjaar en dagdeel.')
        keys.add((year,canonical))
        layer=QgsVectorLayer(f'{path}|layername={table}',f'{label} ({period.upper()})','ogr')
        if not layer.isValid() or QgsWkbTypes.geometryType(layer.wkbType())!=QgsWkbTypes.LineGeometry:
            raise ValueError(f'Ongeldige netwerklaag: {table}')
        prepared.append((year,canonical,layer))
    if not prepared:raise ValueError('Geen netwerk_<zichtjaar>_<dagdeel>-lagen in de bibliotheek.')
    project=QgsProject.instance();group=project.layerTreeRoot().addGroup(f'RP2025 v2026 — {region}')
    selected=None
    for year in sorted({y for y,p,l in prepared}):
        sub=group.addGroup(year)
        for _,period,layer in sorted((x for x in prepared if x[0]==year),key=lambda x:('OC','RD','AV').index(x[1])):
            project.addMapLayer(layer,False);node=sub.addLayer(layer)
            active=year=='2040' and period=='OC';node.setItemVisibilityChecked(active)
            if active:selected=layer
        sub.setItemVisibilityChecked(year=='2040')
        sub.setExpanded(year=='2040')
    if selected:
        plugin.iface.setActiveLayer(selected);plugin._zoom_to_layers([selected])
    plugin._info('Autonetwerken geopend',f'{region}: {len(prepared)} lagen. Alleen 2040 ochtendspits is ingeschakeld, indien aanwezig.')
    return group
