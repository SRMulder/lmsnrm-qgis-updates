"""Fixed visualisations dedicated to validated INWEVA comparison fields."""
from .loaded_visualisations import delta_bands,bands

def comparison_bands(edges,unit):
 categories=delta_bands(edges,unit)
 middle=len(categories)//2
 for i,category in enumerate(categories):
  distance=abs(i-middle)
  category['width']=.3 if distance == 0 else .4 + 1.1 * distance / middle
  category['offset']=.9
 return categories

def automatic_edges(values, neutral):
 """Rounded symmetric scale using the 98th percentile, leaving outliers in the top band."""
 import math
 magnitudes=sorted(abs(v) for v in values if math.isfinite(v) and abs(v)>neutral)
 if not magnitudes:
  return [neutral, neutral*2, neutral*5, neutral*10]
 ceiling=magnitudes[int((len(magnitudes)-1)*.98)]
 def rounded(value):
  step=10**math.floor(math.log10(max(value,1)))
  return math.ceil(value/step)*step
 return sorted(set([neutral]+[rounded(max(neutral*2,ceiling*f)) for f in (.05,.1,.25,.5,1)]))

def definitions():
 out={}
 names={'TOTAL':'motorvoertuigen','L1':'L1 (personenauto en Bestel L1)','L2':'L2 (vracht en Bestel L2)','L3':'L3 (vracht L3)','L23':'L2 + L3'}
 def definition(title,field,kind,category_factory):
  return {'group_name':title,'field_names':['IW_'+field],'inweva_result':True,'difference_result':True,'field_groups':[{'label':label,'field_names':['IW_'+field],'inweva_period':p,'categories':category_factory(p)} for p,label in [('ET','Etmaal'),('OS','Ochtendspits (2 uur)'),('AS','Avondspits (2 uur)')]],'categories':category_factory('ET'),'empty_message':'Geen geldige waarden voor deze INWEVA-vergelijking. Bekijk de koppelcontrole.'}
 for cls,label in names.items():
  out['iw_d_'+cls.lower()]=definition('INWEVA — verschil intensiteit '+label,'D_'+cls,'count',lambda p:comparison_bands([100,1000,2500,10000,25000,50000,100000] if p=='ET' else [20,200,500,2000,5000,10000,20000],'mvt/etmaal' if p=='ET' else 'mvt/spits'))
  out['iw_p_'+cls.lower()]=definition('INWEVA — procentuele afwijking '+label,'P_'+cls,'pct',lambda p:comparison_bands([1,5,10,25],'%'))
  out['iw_r_'+cls.lower()]=definition('INWEVA — verhouding model/INWEVA '+label,'R_'+cls,'ratio',lambda p:[{'min':a,**({'max':b} if b is not None else {}),'min_inclusive':i==0,'label':label,'color':color,'width':.8,'offset':.9} for i,(a,b,label,color) in enumerate([(0,.8,'0 t/m 0,8','#007bc7'),(.8,.95,'>0,8 t/m 0,95','#73a7cb'),(.95,1.05,'>0,95 t/m 1,05','#bdbdbd'),(1.05,1.2,'>1,05 t/m 1,2','#e17000'),(1.2,None,'>1,2','#d52b1e')])])
 for cls in ('L1','L2','L3','L23'):
  out['iw_share_'+cls.lower()]=definition('INWEVA — verschil aandeel '+names[cls],'DA_'+cls,'share',lambda p:comparison_bands([.1,1,5,10],'procentpunt'))
 categories=[{'values':[code],'label':title,'color':color,'width':width} for code,title,color,width in [(0,'Geen passende ID/richting-match','#bdbdbd',.4),(1,'Gekoppeld: voldoende dekking en geldige totalen','#39870c',.8),(2,'Gedeeltelijke dekking: geen verschilwaarde','#e17000',1),(3,'Meerdere richtinggeschikte kandidaten: geen verschilwaarde','#6a3d9a',1),(4,'Ongeldige totale intensiteit of klasseverdeling','#d52b1e',1.2)]]
 out['iw_match']={'group_name':'INWEVA — koppeling en bronkwaliteit','field_names':['IW_STATUS'],'categories':categories,'inweva_result':True,'difference_result':True,'empty_message':'Geen koppelstatus gevonden.'}
 out['iw_source_pct']={'group_name':'INWEVA — controle bronpercentage','field_names':['IW_PC_CHECK'],'categories':[{'values':[0],'label':'Bronpercentage sluit aan binnen 1 procentpunt','color':'#39870c','width':.65},{'values':[1],'label':'Bronpercentage wijkt af of ligt boven 100%','color':'#d52b1e','width':1}], 'inweva_result':True,'difference_result':True,'empty_message':'Geen bronpercentages om te controleren. Bij urenbestanden worden aandelen uit de aantallen berekend.'}
 return out
