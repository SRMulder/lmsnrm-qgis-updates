# LMSNRM Toolbar — handleiding

LMSNRM Toolbar is een QGIS-plugin voor het laden, verrijken, vergelijken en visualiseren van LMS- en NRM-wegennetwerken. Je werkt met lagen in je QGIS-project. De plugin maakt onder meer GeoPackages, attribuutkaarten, resultaatkaarten en verschilnetwerken.

## Installeren en starten

Gebruik QGIS 3.28 of hoger binnen de ondersteunde versiereeks 3.28–4.99. Open **Plugins → Plugins beheren en installeren → Installeren vanuit ZIP**, kies de installatie-ZIP en installeer de plugin. Schakel **LMSNRM Toolbar** in. Is de toolbar verborgen, zet hem aan via **Beeld → Werkbalken → LMSNRM Toolbar**. Herstart QGIS als de toolbar na installatie niet verschijnt.

De gedeelde installatie-ZIP staat in `P:\wvl\Toepassingen_NRM_En_LMS\Diverse scripts\LMSNRM toolbar plugin QGIS`. Voor downloaden en controleren op updates is geen login nodig.

## Beginnen met een netwerk

Open een eigen shapefile of GeoPackage met de normale QGIS-functies, of gebruik een importactie onder **Netwerken**. Klik daarna op de gewenste netwerklaag in het lagenpaneel. Deze actieve laag bepaalt op welk netwerk een actie wordt uitgevoerd. Selecteer de bronlaag, niet een losse kleurklasse.

Een invoernetwerk bevat de wegen en modelkenmerken. Een geladen netwerk bevat daarnaast verkeersresultaten. Een verschilnetwerk bevat de vergelijking tussen twee netwerken. Een visualisatie is een groep gefilterde lagen die dezelfde brongegevens tonen. De bronwaarden worden hierdoor niet aangepast.

## Menu’s

- **Autonetwerken:** bibliotheeknetwerken laden, invoer- of geladen netwerken uit GMZIP halen, .NET-attributen koppelen, verschilnetwerken maken, Afslagverboden en Wegenprojecten.
- **Netwerkattributen:** Eigenschappen, Resultaten, Verschilnetwerk en Visualisatielagen verwijderen.
- **Zonering en SEG:** vaste zonering en SEG openen, de beschikbare vaste SEG-kaarten openen.
- **INWEVA:** INWEVA 2025 bekijken en koppelen aan een netwerk.
- **Algemeen:** kaart uitlijnen met OpenStreetMap, updates controleren en deze handleiding openen.

**Gegevens op de P-schijf**

De volgende onderdelen zijn alleen zichtbaar als de bijbehorende gegevens op de P-schijf bereikbaar zijn:

- De invoernetwerken onder RP2025 v2026.
- Wegenprojecten.
- Zonering 2022 en de vaste SEG 2026-kaarten.
- INWEVA 2025.

Zonder verbinding met de P-schijf kun je nog steeds eigen netwerken importeren, bestanden koppelen, netwerken vergelijken en kaarten maken.


## Autonetwerken: RP2025 v2026

Kies **Autonetwerken → RP2025 v2026 → landsdeel**. De plugin opent het landsdeel als groep, met daaronder de beschikbare zichtjaren en dagdelen. Alleen 2040/ochtendspits staat aan. Als die laag niet aanwezig is, blijven alle lagen uit. Schakel de laag in die je wilt bekijken.

RD is restdag, OC of OS is ochtendspits en AV of AS is avondspits. De bibliotheeklagen blijven verbonden met het GeoPackage op de netwerkschijf. Kies daarna zelf een kaart onder Netwerkattributen.

## Autonetwerken: invoernetwerk uit GMZIP

Kies **Autonetwerken → Invoernetwerk uit GMZIP halen…**, selecteer de GMZIP en kies de locatie van het uitvoer-GeoPackage. De plugin zoekt naar een `.shp` in de map `Input`, ongeacht de netwerknaam. De bijbehorende `.dbf` en `.shx` zijn vereist. Een aanwezige `.prj` en `.cpg` worden meegenomen. Bij meerdere shapes in Input is de keuze niet eenduidig en wordt de import gestopt met een melding.

Alleen de bestanden van deze shape worden tijdelijk gekopieerd. De volledige GMZIP wordt niet uitgepakt. De uitvoer bevat de laag `invoernetwerk`, de bronattributen, A/B-knoopvelden en een ruimtelijke index. Deze import heeft geen toedelingsresultaten nodig. Bij annuleren of een fout wordt het uitvoerbestand niet vervangen.

## Autonetwerken: geladen netwerk uit GMZIP

Kies **Autonetwerken → Maak geladen netwerk vanuit GMZIP…**. Kies de bron-ZIP en het uitvoerbestand in het importvenster. De plugin leest de netwerkshape en de bijbehorende QBlok-resultaten en maakt een GeoPackage met verkeersgegevens per dagdeel. De bronvariant en het dagdeel zijn herkenbaar in de laagnamen.

Gebruik een laag met alle dagdelen voor een vergelijking van alle dagdelen. Voor een kaart van één periode kun je de overeenkomstige dagdeellaag gebruiken. Ontbrekende of niet-eenduidige benodigde bestanden geven een melding. Het installeren van de plugin voegt geen verkeersresultaten toe aan een bestaand GeoPackage. Importeer de GMZIP wanneer die gegevens nodig zijn.

## Autonetwerken: .NET-attributen koppelen

Selecteer de gewenste netwerklaag en kies **Autonetwerken → .NET-attributen / VPR koppelen…**. Kies in het venster een CUBE NET-bestand. Daaronder kun je optioneel een VPR-bestand kiezen. Laat dit leeg als je alleen attributen wilt koppelen. De koppeling gebruikt het gerichte knooppaar A → B, met A/B of KnoopA/KnoopB uit het netwerk. Gebruik bestanden van hetzelfde landsdeel, zichtjaar en dagdeel.

Tijdens het lezen verschijnt een voortgangsvenster met het aantal gelezen NET-links. Het lezen gebeurt op de achtergrond. Daarna zie je hoeveel netwerklinks verwerkt zijn en hoeveel daarvan gekoppeld zijn. QGIS kan tijdens de verwerking blijven reageren. Met Annuleren stop je de bewerking. Er wordt dan geen gedeeltelijk gekoppelde laag toegevoegd. Bij het openen van een bestand vanaf de netwerkschijf kan de eerste stap wat langer duren.

De A/B-volgorde is van belang: B → A is een andere gerichte link. WVK_ID is niet de sleutel voor deze koppeling. Controleer het gemelde aantal matches en de velden in de uitvoerlaag. Een bestand van een andere variant kan afwijkende of ontbrekende knoopparen bevatten.

Met een VPR neemt de plugin de actieve linkkleurgroep over als een QGIS-regelstijl. De regelvoorwaarden, Windows-kleuren, lijndiktes en lijnverschuiving worden omgezet. Dikte en verschuiving gebruiken schermpixels. Ook NET-velden die de VPR nodig heeft worden ingelezen. Bij dezelfde veldnaam gebruikt de gekoppelde laag de NET-waarde. De oorspronkelijke netwerklaag blijft behouden.

De ondersteunde voorwaarden bevatten veldnamen, getallen, vergelijkingen, haakjes, rekenoperatoren en AND/OR/NOT of &/|/~. De omzetting behandelt een later passende kleurregel als voorrang op een eerdere. Deze volgorde is nog niet tegen een CUBE-scherm gecontroleerd. Ontbrekende velden of niet ondersteunde linkregels geven een melding. De NET en VPR die je zelf kiest worden gebruikt. Oude bestandspaden in de VPR worden niet geopend.

De VPR-omzetting is een bèta voor linkkleuren. CUBE-animaties, knoopsymbolen, achtergrondlagen, afdrukinstellingen en losse legendateksten worden niet overgenomen. Een volledige CUBE-weergave is daarom niet gegarandeerd identiek. In QGIS kun je de overgenomen regels bekijken via Laageigenschappen → Symbologie. De gekoppelde laag staat tijdelijk in het project. Exporteer naar GeoPackage voor blijvende opslag van attributen en sla de stijl apart of met het QGIS-project op.

## Autonetwerken: verschilnetwerk maken

Kies **Autonetwerken → Verschilnetwerken → Verschilnetwerk maken…**. Kies bij beide netwerken een geopende laag in het QGIS-project of een bestand vanaf schijf. Bij een bestand met meerdere lagen kies je ook de laag. De keuzelijst vermeldt de laag, groep en bron om varianten met dezelfde dagdeelnamen te onderscheiden.

**Netwerk 1 is de variant/nieuwe situatie. Netwerk 2 is de referentie/oude situatie. Uitkomst = netwerk 1 − netwerk 2.** Kies de uitvoerlocatie en maak het verschilnetwerk. Vergelijk dezelfde eenheden en dagdelen. Voor alle dagdelen kies je bij beide netwerken de volledige laag.

Links die alleen in één netwerk voorkomen behouden hun eigen geometrie. Hun verschilwaarden worden vergeleken met nul en zijn geen meting van dezelfde link voor en na. Bekijk daarom ook **Netwerkattributen → Verschilnetwerk → Netwerkveranderingen / koppeling**. `D_`-velden bevatten verschillen. `N1_` en `N2_` de oorspronkelijke waarden.

## Autonetwerken: vergelijken met INWEVA

Kies **Autonetwerken → Verschilnetwerken → Geladen netwerk vergelijken met INWEVA…**. Selecteer een geopende geladen netwerklaag of open een geladen GeoPackage vanaf schijf. De actieve laag staat standaard bovenaan. Een invoernetwerk zonder verkeersresultaten is niet voldoende.

Kies de INWEVA-levering en dagsoort. **INWEVA 2025 — Werkdag** is de standaard. Daarna kies je Etmaal, Ochtendspits of Avondspits. Alleen periodes die bij beide bronnen beschikbaar zijn worden aangeboden. Vul het modeljaar of scenario in. Kies een nieuw GeoPackage voor de uitvoer.

De uitkomst is **model minus INWEVA**. In het geladen netwerk zijn spitsintensiteiten per uur. De plugin verdubbelt die voor een vergelijking met INWEVA 07–09 of 16–18. De uitvoer toont voertuigen per spitsperiode van twee uur. Etmaalwaarden worden niet verdubbeld. Zij gebruiken de etmaalophoging uit het model. Aandelen worden ook niet verdubbeld.

Je kunt totale motorvoertuigen, L1, L2, L3 en L2 + L3 vergelijken. L1 in het model omvat personenauto’s en Bestel L1. L2 omvat vracht en Bestel L2. L3 omvat vracht L3. Dit zijn voertuigklassevergelijkingen. Het aandeel L2 + L3 is niet hetzelfde als vracht exclusief bestelverkeer. De plugin berekent aandelen aan beide kanten uit de aantallen. Het bestaande INWEVA-bronpercentage blijft apart bewaard.

Na het opslaan verschijnt de koppelcontrole. De groene laag met voldoende gekoppelde wegen wordt automatisch geselecteerd. Je kunt daarna direct een INWEVA-kaart kiezen onder Netwerkattributen → Verschilnetwerk. Alle modelwegen blijven in de uitvoer aanwezig. Alleen een voldoende gedekte, richtinggeschikte en eenduidige koppeling met geldige totalen krijgt een verschilwaarde. De koppelcontrole toont geen match, gekoppeld, gedeeltelijke dekking, meerdere kandidaten of ongeldige brongegevens. De grens voor voldoende dekking is 90% van de modellengte binnen ongeveer 10 meter van het INWEVA-segment. Dit is een praktische controlegrens, geen garantie dat beide links inhoudelijk identiek zijn.

Lange modellinks met meerdere korte INWEVA-segmenten worden niet automatisch gemiddeld of bij elkaar opgeteld. Gedeeltelijke en onbeslisbare koppelingen hebben geen verschilwaarde. Wegen zonder match worden niet met nul vergeleken. Als de som van L1, L2 en L3 meer dan drie voertuigen of 1% van het totaal afwijkt, gebruikt de controle de grootste van deze twee grenzen en wordt de bron als ongeldig gemarkeerd.

Onder **Netwerkattributen → Verschilnetwerk** staan de INWEVA-kaarten. Alleen kaarten die bij de actieve vergelijking passen zijn klikbaar. Kies een absoluut verschil, procentuele afwijking, verhouding model/INWEVA of een verschil in voertuigklasseaandeel. De naam van de laag vermeldt de modelvariant, INWEVA-levering, dagsoort en periode.

- Absoluut verschil is model min INWEVA, in voertuigen per etmaal of per spitsperiode.
- Procentuele afwijking is het absolute verschil gedeeld door INWEVA, maal 100.
- Verhouding is model gedeeld door INWEVA. Eén betekent gelijk.
- Aandeelverschillen worden getoond in procentpunten.
- Bij een INWEVA-waarde nul is de procentuele afwijking en verhouding leeg. Het absolute verschil kan wel worden berekend.
- Bij ontbrekende of ongeldige waarden wordt geen verschil verzonnen.

Bij een absoluut INWEVA-intensiteitsverschil kies je de standaardverdeling of **Verdeling aanpassen aan deze laag**. De vaste spitsgrenzen zijn 20, 200, 500, 2.000, 5.000, 10.000 en 20.000 voertuigen. Voor etmaal zijn dat 100, 1.000, 2.500, 10.000, 25.000, 50.000 en 100.000. Elke grens geldt voor zowel afname als toename.

De automatische verdeling gebruikt de absolute verschillen van de gekozen laag. De bovengrens wordt gebaseerd op het 98e percentiel en naar boven afgerond. De grootste uitschieters blijven zichtbaar in de hoogste klasse, zonder de hele schaal te bepalen. De tussenstappen liggen op ongeveer 5%, 10%, 25%, 50% en 100% van deze grens. Rond nul blijft 20 voertuigen per spits of 100 per etmaal grijs. De legenda toont de gebruikte grenzen. Automatische kaarten kunnen verschillende grenzen hebben. Gebruik de standaardverdeling als je kaarten onderling wilt vergelijken.

Voor INWEVA betekent rood hoger in het model en blauw lager in het model. Bij de INWEVA-verschilkaarten bepaalt de grootte van het verschil de tekenvolgorde. Rood krijgt niet automatisch voorrang op blauw. Grotere afwijkingen hebben dikkere lijnen. De lijnen zijn voor de leesbaarheid iets verschoven ten opzichte van de rijrichting, zodat tegengestelde richtingen naast elkaar zichtbaar zijn. De brongeometrie en waarden blijven ongewijzigd. De aantallen achter de INWEVA-kleurklassen zijn uit de echte klassewaarden berekend. Een verschil tussen modeljaar 2022 of scenario 2040 en INWEVA 2025 is geen zuivere voor-en-na-meting of kalibratietoets. Lees daarom de bronjaren en dagsoort bij de kaart.

Werkdag heeft geschikte spitstotalen. Bij Werkdag uren en Weekdag uren worden de spitsen opgebouwd uit uur 07 + 08 of 16 + 17. Voor etmaal gebruik je de gewone Werkdag, Weekdag of Weekenddag. De etmaalwaarden in de urenbestanden zijn niet altijd intern consistent. Een werkdagmodel en een weekend- of weekdagreferentie zijn niet automatisch inhoudelijk gelijkwaardig.

De restdag van het model is niet hetzelfde als de dag-, avond- of nachtperiode van INWEVA. Restdag wordt daarom niet aangeboden. IC, pae-intensiteit, snelheid, capaciteit, reistijd, wachttijd, fileduur en VVU100 hebben geen gelijkwaardige gegevens in deze INWEVA-tabellen. Hun verschilkaarten blijven grijs.

In de attributentabel staan de modelwaarde (`IW_M_`), INWEVA-waarde (`IW_O_`), verschil (`IW_D_`), procentuele afwijking (`IW_P_`) en verhouding (`IW_R_`). Aandelen staan onder `IW_MA_` en `IW_OA_`, met het verschil in procentpunten onder `IW_DA_`. `IW_STATUS` bevat de koppelstatus en `IW_COVER` de geometrische dekking. `IW_SOURCE_PC` bewaart het oorspronkelijke INWEVA-percentage en `IW_PC_CHECK` markeert een afwijking van meer dan één procentpunt of een percentage boven 100. Bij urenbestanden kan dat bronpercentage ontbreken. De kaart **INWEVA — controle bronpercentage** maakt de beschikbare controles zichtbaar.

De vergelijking verandert geen bronbestanden. De uitvoer is een eigen GeoPackage. Gebruik een nieuw uitvoerbestand. De koppeling blijft bèta en moet op de kaart worden beoordeeld.

## Netwerkattributen: Eigenschappen

Selecteer een invoer- of geladen netwerk en kies een eigenschap. De plugin maakt een groep met kleurklassen onder de bronlaag. Een keuze is grijs wanneer de geselecteerde laag de benodigde velden niet heeft.

De kaarten omvatten linktypes, wettelijke en nachtelijke snelheid, rijstroken en effectieve rijstroken, capaciteit, modelsnelheid, speciale stroken, weefvakken, wegsoort, gebiedscode, signalering, hoofdwegennet, doelgroepstrook, wegbeheerder, tol, vrachtwagenheffing, kilometerheffing, autoluw, grensovergang, openstellingsjaar, provincie en rijrichting. Beschikbaarheid hangt af van de bronvelden.

Rijstroken en effectieve rijstroken gebruiken verschillende modelvelden. Capaciteit 99999 wordt als onbegrensde modelcapaciteit weergegeven. Modelsnelheid is de vrije/modelmatige snelheid. Gereden snelheid bij congestie staat onder Resultaten.

Bij moederbestanden zijn H/T de heen- en terugattributen ten opzichte van de vastgelegde linkrichting. De kaart Rijrichting gebruikt H_SEL/T_SEL. Gerichte CUBE-exports kunnen deze selectievelden missen. De plugin meldt dat. Leid H/T niet af uit noord, zuid, links of rechts op de kaart.

## Netwerkattributen: Resultaten

Selecteer een geladen netwerk. Beschikbare kaarten omvatten intensiteit motorvoertuigen en pae, IC-verhouding, gereden snelheid, snelheidsverlies, extra reistijd, wachttijd, VVU100, aangeboden belasting, wachtrij, onafgewikkelde stroom, fileduur, vrachtaandeel en L1/L2/L3-intensiteiten. Gebruik de dagdeel- of etmaallaag passend bij de vraag.

IC gebruikt QBB / FLCPW. Aangeboden belasting gebruikt FLOW / FLCPW. Snelheidsverlies is max(0, vrije snelheid − gereden snelheid). Extra reistijd is max(0, totale reistijd − vrije reistijd), in seconden per link. Vrachtaandeel gebruikt (FRGT2 + FRGT3) / VTG × 100 en sluit bestelverkeer uit. Bij een nulnoemer ontbreekt de afgeleide waarde. Dat is geen gemeten nul.

Bekijk de legenda voor de eenheid en klassegrenzen. Etmaalintensiteiten hebben andere grenzen dan dagdeelwaarden. De hoogste IC-knelpuntklassen worden boven de lagere klassen getekend. De kaartstijl is een hulpmiddel voor analyse. De legenda bepaalt de interpretatie.

## Netwerkattributen: Verschilnetwerk

Selecteer een gemaakt verschilnetwerk en kies de gewenste verschilkaart. Naast intensiteit, IC en VVU100 zijn onder meer snelheid, reistijd, wachttijd, snelheidsverlies, aangeboden belasting, fileduur, vrachtaandeel, L1/L2/L3 en wachtrij beschikbaar wanneer de benodigde velden aanwezig zijn.

Blauw betekent bij de meeste verschilkaarten afname, rood toename en grijs rond nul. Rode/oranje klassen worden boven blauwe klassen getekend. Bij gereden snelheid is een afname rood en een toename groen. Een verschil in vrachtaandeel wordt weergegeven in procentpunten. Positief en negatief betekenen altijd netwerk 1 − netwerk 2. De betekenis van de kleur hangt af van de gekozen indicator.

Met **Netwerkattributen → Visualisatielagen verwijderen…** verwijder je de gemaakte attribuut- en resultaatvisualisaties van de actieve bron. De brongegevens blijven behouden.

## Afslagverboden

Selecteer de netwerklaag en kies **Autonetwerken → Afslagverboden → .PEN koppelen aan actieve shape…**. Kies het bijbehorende CUBE .PEN-bestand. De koppeling gebruikt drie opeenvolgende knopen om de afslag in het netwerk te vinden. Gebruik het netwerk waarvoor het PEN-bestand is gemaakt en controleer het gemelde aantal gekoppelde afslagbewegingen.

De gemaakte lagen tonen de afslagbewegingen en bijbehorende beperkingen/penalties. Gebruik de legenda en attributen om de betekenis van een penalty te beoordelen. **Lagen verwijderen** verwijdert de afslagverbodlagen van de plugin.

## Wegenprojecten

Selecteer een netwerk met een projectveld en kies **Autonetwerken → Wegenprojecten → Projecten kiezen…**. De projectenlijst geeft namen en informatie bij de projectcodes. Kies de gewenste projecten om gefilterde projectlagen te maken. **Projectlagen verwijderen** verwijdert deze lagen.

Niet elk netwerk bevat projectcodes. Controleer de bronlaag wanneer de selectie leeg is.

## Zonering en SEG: Zonering 2022

Kies het gewenste landsdeel onder **Zonering en SEG → Zonering 2022** om de gewenste zonekaart toe te voegen. De optie **Zonerings- en SEG-lagen verwijderen** staat onderaan het menu. Daarmee verwijder je de zonekaarten die de plugin heeft toegevoegd.

## Zonering en SEG: SEG 2026

Kies **Zonering en SEG → SEG 2026 → model**. SEG 2026 is de levering van mei 2026 met basisjaar 2023. De kaart gebruikt de zonering van het gekozen model en de bijbehorende sociaal-economische gegevens. Tien hoofdthema’s worden direct klaargezet. Alle lagen staan eerst uit.

De thema’s omvatten inwonersdichtheid, banendichtheid, aandeel 65+, auto’s per huishouden, huishoudinkomen, parkeertarief en aantallen inwoners, huishoudens, woningen en banen. Blauw betekent een lage waarde en rood een hoge waarde. Nul en ontbrekende waarden hebben een afzonderlijke kleur. Dichtheden en aantallen zijn apart benoemd.

Klap een detailgroep uit om kaarten over leeftijd, banen per sector, onderwijs, beroepsbevolking of studenten-OV te laden. Die lagen staan ook eerst uit. De plugin maakt ze pas aan wanneer je de groep uitklapt. Dit houdt het openen van de kaart snel.



## INWEVA: INWEVA 2025

Kies een beschikbare INWEVA-kaart onder **INWEVA → INWEVA 2025**. De kaarten tonen de INWEVA-verkeersgegevens voor de aangeboden periodes.

**INWEVA → Koppelen met netwerk (bèta)…** koppelt een gekozen invoer- of geladen netwerk aan een INWEVA-laag. Gebruik bij voorkeur WVK_ID. Dat ID wordt gezocht in alle IDs van WVK_IDS, niet alleen het eerste. VBN_ID, LINK_ID, SEGMENT_ID en knoopnummers zijn andere sleutels. De plugin controleert de geometrische richting en afstand en verwerkt verschillen in coördinatenstelsel.

De koppellaag behoudt de modellinkgeometrie en krijgt de gegevens van één gekozen INWEVA-segment. Links zonder passende match worden niet opgenomen. Korte INWEVA-segmenten worden niet automatisch tot een volledige modellinkketen samengevoegd. Intensiteiten worden niet opgeteld of gemiddeld.

- `INW_koppeling`: `segment` bij minder dan 90% geometrische dekking, anders `dekking_geometrie`.
- `INW_dekking_pct`: het percentage modellengte binnen ongeveer 10 meter van het gekozen INWEVA-segment. Dit is geen betrouwbaarheidspercentage voor verkeerswaarden.
- `INW_kandidaten`: het aantal INWEVA-features dat hetzelfde ID vermeldt. Bij meerdere kandidaten kiest de plugin op geometrische richting, span en afstand.

Een volledige geometrische dekking bewijst niet dat de verkeerswaarden representatief zijn voor de hele modellink. Controleer gedeeltelijke en meervoudige matches op de kaart en in de attributentabel. De koppeling blijft bèta.

**Alle 5 splitsen op actieve netwerklaag…** maakt de vijf beschikbare INWEVA-uitvoerlagen op basis van de overeenkomende IDs van het actieve netwerk, met netwerkgeometrie, WVK_ID, KnoopA/KnoopB en de INWEVA-attributen. Ook deze uitvoer is geen automatische ketensamenvoeging. **Lagen verwijderen** verwijdert de INWEVA-lagen van de plugin.

## Algemeen en opslaan

**Algemeen → Kaart uitlijnen met OpenStreetMap** stemt de projectweergave af op de OpenStreetMap-achtergrond en herstelt geselecteerde RD-lagen waar van toepassing. De actie vervangt geen netwerkbestand. Gebruik hem wanneer de achtergrond en netwerklaag niet goed over elkaar liggen. Controleer ook het broncoördinatenstelsel.

Sla je QGIS-project op als `.qgz`. GeoPackage-uitvoer staat op de gekozen schijflocatie. Geheugenlagen, zoals koppellagen, zijn tijdelijk: exporteer ze via **Rechtsklik op de laag → Exporteren → Objecten opslaan als…**, bijvoorbeeld naar GeoPackage, als je de gegevens wilt bewaren. Een opgeslagen project alleen bewaart niet de objecten van een geheugenlaag.

## Updates

Open **Algemeen → Updates instellen / controleren…** en klik op **Nu controleren en updaten**. Dit controleert direct, ook als automatisch controleren uitstaat. Met de automatische optie controleert de plugin dagelijks op een nieuwere ondersteunde versie. Daarvoor is internet nodig, geen login of token.

De plugin downloadt de update en controleert het installatiebestand. De nieuwe versie wordt bij de volgende QGIS-start geïnstalleerd. Sla je werk op en sluit QGIS om de update toe te passen. De interne netwerk- en presetdata worden niet met de plugin bijgewerkt.

## Veelvoorkomende vragen

**Een menu ontbreekt.** Controleer de verbinding met de P-schijf. Wacht kort op de bereikbaarheidscontrole of open Netwerken opnieuw. De interne opties zijn beschikbaar zodra de verbinding met de netwerkschijf werkt.

**Een attribuutkaart is grijs.** Selecteer de juiste netwerkbronlaag. Controleer of het benodigde veld bestaat en of je een invoer-, geladen of verschilnetwerk gebruikt.

**Een koppeling vindt weinig matches.** Controleer landsdeel, variant, zichtjaar, dagdeel en de juiste sleutel. .NET gebruikt A/B, INWEVA gebruikt WVK_ID/WVK_IDS en .PEN gebruikt drie knopen. Verschillende netwerkindelingen kunnen onvolledige koppelingen geven.

**Een GMZIP-import stopt.** Lees de melding over ontbrekende of meerdere bestanden. Zorg dat SHP, DBF en SHX samen in Input staan en kies voor een geladen netwerk een ZIP met de benodigde verkeersresultaten.

**De kaart ligt verkeerd.** Controleer het coördinatenstelsel van de bronlaag en gebruik Kaart uitlijnen met OpenStreetMap. Ken een ontbrekend coördinatenstelsel alleen toe wanneer je de werkelijke broncoördinaten kent.

**Updates zijn niet bereikbaar.** Controleer de internetverbinding en probeer Nu controleren en updaten opnieuw. De geïnstalleerde plugin blijft bruikbaar als de updatecontrole niet lukt.
